// Fast Synchronous Cache Application (Prevents Layout Shift & FOUC without violating CSP)
(function() {
  try {
    const defaultWp = 'wallpapers/galaxy.jpg';
    const raw = localStorage.getItem('safari_speeddial_settings_cache');
    const s = raw ? JSON.parse(raw) : null;
    const app = document.getElementById('app');
    if (app) {
      const theme = (s && s.theme) || 'dark';
      let cls = 'safari-theme-' + theme + ' is-loading';
      if (s) {
        if (s.theme === 'custom' && s.customBgColor) {
          const c = s.customBgColor;
          if (c && c.startsWith('#') && c.length >= 7) {
            const r = parseInt(c.slice(1,3), 16), g = parseInt(c.slice(3,5), 16), b = parseInt(c.slice(5,7), 16);
            if ((0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.65) {
              cls += ' safari-theme-light';
            }
          }
        }
        if (s.viewMode === 'tile') cls += ' view-tile';
        if (s.viewMode === 'thumb') cls += ' view-thumb';
        if (s.searchBarCenter) cls += ' search-centered';
        if (s.showSearchBar === false) cls += ' hide-search-bar';
        if (s.expandScreen) cls += ' expand-screen';
        if (s.panelLabelSize && s.panelLabelSize !== 'normal') cls += ' panel-labels-' + s.panelLabelSize;
      }
      app.className = cls;
    }
    if (s && s.customBgColor) {
      document.documentElement.style.setProperty('--custom-bg-color', s.customBgColor);
    }
    const wp = document.getElementById('wallpaper-bg');
    if (wp) {
      const wpSrc = (s && s.customWallpaper !== undefined) ? s.customWallpaper : (s && s.wallpaperInitialized ? null : defaultWp);
      if (wpSrc && wpSrc !== 'none') {
        wp.style.backgroundImage = 'url(' + wpSrc + ')';
        wp.classList.add('has-wallpaper');
      }
    }
    if (s) {
      const root = document.documentElement.style;
      if (s.cardSize) root.setProperty('--card-size', s.cardSize + 'px');
      if (s.thumbWidth) root.setProperty('--thumb-width', s.thumbWidth + 'px');
      if (s.thumbHeight) root.setProperty('--thumb-height', s.thumbHeight + 'px');
      if (s.cardGap) {
        root.setProperty('--card-gap-x', s.cardGap + 'px');
        root.setProperty('--card-gap-y', (s.cardGap + 6) + 'px');
      }
      const isThemeLight = (s.theme === 'light');
      const defaultFolderColor = isThemeLight ? 'rgba(246, 246, 248, 0.94)' : '#3a3a3e';
      const isFolderLiquid = (s.folderColor === 'liquid-glass');
      const folderColor = (s.folderColor && s.folderColor !== '#3a3a3e') ? s.folderColor : (isThemeLight ? defaultFolderColor : '#3a3a3e');
      root.setProperty('--folder-bg', isFolderLiquid ? 'rgba(255, 255, 255, 0.04)' : folderColor);

      const isFolderLight = (function(c, isLight) {
        if (!c) return isLight;
        let r = 0, g = 0, b = 0, a = 1;
        if (c.startsWith('#')) {
          let hex = c.slice(1);
          if (hex.length === 3) hex = hex.split('').map(x => x + x).join('');
          if (hex.length >= 6) {
            r = parseInt(hex.slice(0, 2), 16);
            g = parseInt(hex.slice(2, 4), 16);
            b = parseInt(hex.slice(4, 6), 16);
          }
          if (hex.length === 8) a = parseInt(hex.slice(6, 8), 16) / 255;
        } else if (c.startsWith('rgb')) {
          const parts = c.match(/[\d.]+/g);
          if (parts && parts.length >= 3) {
            r = parseFloat(parts[0]);
            g = parseFloat(parts[1]);
            b = parseFloat(parts[2]);
            if (parts.length >= 4) a = parseFloat(parts[3]);
          }
        }
        const bg = isLight ? 245 : 30;
        const effR = r * a + bg * (1 - a);
        const effG = g * a + bg * (1 - a);
        const effB = b * a + bg * (1 - a);
        return ((0.299 * effR + 0.587 * effG + 0.114 * effB) / 255) > 0.6;
      })(folderColor, isThemeLight);

      root.setProperty('--folder-fg', isFolderLight ? '#1c1c1e' : '#ffffff');
      root.setProperty('--folder-sub-fg', isFolderLight ? 'rgba(60, 60, 67, 0.78)' : 'rgba(255, 255, 255, 0.78)');
      root.setProperty('--folder-border', isFolderLight ? 'rgba(0, 0, 0, 0.14)' : 'rgba(255, 255, 255, 0.16)');
      root.setProperty('--folder-btn-bg', isFolderLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.18)');
      root.setProperty('--folder-btn-border', isFolderLight ? 'rgba(0, 0, 0, 0.14)' : 'rgba(255, 255, 255, 0.22)');
      root.setProperty('--folder-btn-hover', isFolderLight ? 'rgba(0, 0, 0, 0.16)' : 'rgba(255, 255, 255, 0.32)');

      const sameColor = !!s.bookmarkSameColorAsFolder;
      const defaultCardColor = isThemeLight ? '#ffffff' : '#2a2a2d';
      let effectiveColor;
      if (sameColor) {
        effectiveColor = folderColor;
      } else if (s.bookmarkColor && s.bookmarkColor !== 'default') {
        effectiveColor = s.bookmarkColor;
      } else if (isFolderLiquid) {
        effectiveColor = 'liquid-glass';
      } else {
        effectiveColor = defaultCardColor;
      }
      root.setProperty('--card-bg', effectiveColor === 'liquid-glass' ? 'rgba(255, 255, 255, 0.04)' : effectiveColor);
      const isCardLight = (function(c) {
        if (!c || !c.startsWith('#') || c.length < 7) return false;
        const r = parseInt(c.slice(1,3), 16), g = parseInt(c.slice(3,5), 16), b = parseInt(c.slice(5,7), 16);
        return ((0.299 * r + 0.587 * g + 0.114 * b) / 255) > 0.65;
      })(effectiveColor);
      root.setProperty('--card-fg', isCardLight ? '#1d1d1f' : '#ffffff');
      root.setProperty('--card-border', isCardLight ? 'rgba(0, 0, 0, 0.12)' : 'rgba(255, 255, 255, 0.1)');
    }
  } catch(e) {}
})();
