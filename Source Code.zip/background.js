/**
 * Safari Speed Dial - Background Event Worker
 * Real Screenshot & Open Graph Hybrid Engine
 * - Silent Open Graph metadata extraction for fast initial queues
 * - Native background tab capture for right-click "Actualizar captura"
 * - Passive live capture while browsing bookmarks
 * NO popup windows, NO bot challenges.
 */

const IDB_NAME = 'SafariSpeedDialDB';
const IDB_VERSION = 1;
const IDB_STORE_NAME = 'thumbnails';
let idbInstance = null;

function openThumbnailDB() {
  if (idbInstance) return Promise.resolve(idbInstance);
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(IDB_NAME, IDB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(IDB_STORE_NAME)) {
        db.createObjectStore(IDB_STORE_NAME, { keyPath: 'url' });
      }
    };
    request.onsuccess = (e) => {
      idbInstance = e.target.result;
      resolve(idbInstance);
    };
    request.onerror = (e) => reject(e.target.error);
  });
}

function getThumbKey(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase().replace(/^www\./, '');
    let p = (u.pathname || '').replace(/\/+$/, '').toLowerCase();
    let search = '';
    if (u.search) {
      const sp = new URLSearchParams(u.search);
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'ref', 'ref_', 'rdt', 'fbclid', 'gclid'].forEach(k => sp.delete(k));
      const str = sp.toString();
      if (str) search = '?' + str.toLowerCase();
    }
    return `${host}${p}${search}`;
  } catch {
    return String(url).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/+$/, '');
  }
}

function isMatchingTab(tabUrl, targetUrl) {
  if (!tabUrl || !targetUrl) return false;
  const k1 = getThumbKey(tabUrl);
  const k2 = getThumbKey(targetUrl);
  if (k1 === k2) return true;

  try {
    const u1 = new URL(tabUrl);
    const u2 = new URL(targetUrl);
    let h1 = u1.hostname.toLowerCase().replace(/^www\./, '');
    let h2 = u2.hostname.toLowerCase().replace(/^www\./, '');
    if (h1 === 'twitter.com') h1 = 'x.com';
    if (h2 === 'twitter.com') h2 = 'x.com';
    if (h1 !== h2) return false;

    const p1 = (u1.pathname || '').replace(/\/+$/, '').toLowerCase();
    const p2 = (u2.pathname || '').replace(/\/+$/, '').toLowerCase();

    if (p1 === p2) return true;
    if (p2 && p1.startsWith(p2)) return true;
    if (!p2 || p2 === '/') return true;

    return false;
  } catch {
    return false;
  }
}

async function getStorageData(keys) {
  try {
    if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
      const res = await browser.storage.local.get(keys);
      if (res && typeof res === 'object') return res;
    }
  } catch (e) {}
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(keys, (res) => resolve(res || {}));
      });
    }
  } catch (e) {}
  return {};
}

async function saveThumbnail(url, dataUrl, isFallback = false) {
  const key = getThumbKey(url);
  if (!key || !dataUrl) return;
  try {
    const db = await openThumbnailDB();
    const tx = db.transaction(IDB_STORE_NAME, 'readwrite');
    const store = tx.objectStore(IDB_STORE_NAME);

    let blob = null;
    try {
      const parts = dataUrl.split(',');
      if (parts.length === 2) {
        const mime = parts[0].match(/:(.*?);/)[1];
        const bstr = atob(parts[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        blob = new Blob([u8arr], { type: mime });
      }
    } catch (e) {}

    store.put({
      url: key,
      dataUrl: dataUrl,
      blob: blob,
      originalUrl: url,
      timestamp: Date.now(),
      isFallback: !!isFallback
    });

    return new Promise((resolve) => {
      tx.oncomplete = () => {
        if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
          browser.runtime.sendMessage({ action: 'thumbnailUpdated', url: url, dataUrl: dataUrl }).catch(() => {});
        }
        resolve();
      };
      tx.onerror = () => resolve();
    });
  } catch (err) {
    console.warn('[Background] Failed to save thumbnail to IDB:', err);
  }
}

async function hasThumbnailInDB(url) {
  const key = getThumbKey(url);
  if (!key) return false;
  try {
    const db = await openThumbnailDB();
    const tx = db.transaction(IDB_STORE_NAME, 'readonly');
    const store = tx.objectStore(IDB_STORE_NAME);
    const req = store.get(key);
    return new Promise((resolve) => {
      req.onsuccess = () => {
        const item = req.result;
        resolve(!!(item && item.dataUrl && !item.isFallback));
      };
      req.onerror = () => resolve(false);
    });
  } catch (e) {
    return false;
  }
}

function convertUrlToAbsolute(origin, path) {
  if (!path) return '';
  if (path.indexOf('://') > 0) return path;
  if (path.indexOf('//') === 0) return 'https:' + path;
  try {
    return new URL(path, origin).href;
  } catch (e) {
    return path;
  }
}

function cleanCandidateUrl(rawUrl, baseUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') return '';
  const cleaned = rawUrl
    .replace(/&amp;/g, '&')
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .trim();
  return convertUrlToAbsolute(baseUrl, cleaned);
}

function downscaleRawScreenshot(raw) {
  return new Promise((resolve) => {
    if (!raw) return resolve(null);
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 640;
        canvas.height = 384;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        const scale = Math.max(640 / img.width, 384 / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        ctx.drawImage(img, (640 - w) / 2, 0, w, h);

        const opt = canvas.toDataURL('image/webp', 0.85);
        resolve(opt);
      } catch (e) {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = raw;
  });
}

function isImageBlank(dataUrl) {
  return new Promise((resolve) => {
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) {
      return resolve(true);
    }
    const img = new Image();
    const timer = setTimeout(() => {
      img.src = '';
      resolve(true);
    }, 2500);

    img.onload = () => {
      clearTimeout(timer);
      try {
        const w = 32;
        const h = 32;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(false);
        ctx.drawImage(img, 0, 0, w, h);
        const imgData = ctx.getImageData(0, 0, w, h).data;

        const r0 = imgData[0];
        const g0 = imgData[1];
        const b0 = imgData[2];
        const a0 = imgData[3];

        let hasVariation = false;
        for (let i = 4; i < imgData.length; i += 4) {
          if (
            Math.abs(imgData[i] - r0) > 4 ||
            Math.abs(imgData[i + 1] - g0) > 4 ||
            Math.abs(imgData[i + 2] - b0) > 4 ||
            Math.abs(imgData[i + 3] - a0) > 4
          ) {
            hasVariation = true;
            break;
          }
        }
        resolve(!hasVariation);
      } catch (e) {
        resolve(false);
      }
    };

    img.onerror = () => {
      clearTimeout(timer);
      resolve(true);
    };

    img.src = dataUrl;
  });
}

// In-flight screenshot capture promises to avoid duplicate simultaneous executions
const inFlightScreenshots = new Map();

/**
 * Capture real screenshot or Open Graph thumbnail of a URL link with ZERO new tabs:
 * 1. If tab is already open in Firefox, capture it directly (0 new tabs!).
 * 2. If tab is closed, do NOT open any new tab in the tab bar.
 *    Instead, use silent background Open Graph & Site Imagery scraping (0 new tabs!).
 */
async function captureUrlScreenshotLive(url, title = '') {
  let targetUrl = (url || '').trim();
  if (!targetUrl || targetUrl.startsWith('about:') || targetUrl.startsWith('chrome:') || targetUrl.startsWith('moz-extension:')) {
    return null;
  }
  if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
    targetUrl = 'https://' + targetUrl;
  }
  try {
    new URL(targetUrl);
  } catch (e) {
    return null;
  }

  const key = getThumbKey(targetUrl);
  if (inFlightScreenshots.has(key)) {
    return inFlightScreenshots.get(key);
  }

  const promise = (async () => {
    // Case 1: Check if this URL is already open in an existing tab in Firefox
    try {
      if (browser && browser.tabs && browser.tabs.query && browser.tabs.captureTab) {
        const allTabs = await browser.tabs.query({});
        const matchingTab = allTabs.find(t => isMatchingTab(t.url, targetUrl));
        if (matchingTab && matchingTab.id) {
          let raw = await browser.tabs.captureTab(matchingTab.id, {
            format: 'jpeg',
            quality: 85
          }).catch(() => null);

          if (raw) {
            const blank = await isImageBlank(raw);
            if (!blank) {
              const opt = await downscaleRawScreenshot(raw);
              if (opt) {
                await saveThumbnail(targetUrl, opt, false);
                return opt;
              }
            }
          }
        }
      }
    } catch (err) {
      console.warn('[Background] Error checking open tabs:', err);
    }

    // Case 2: Tab is closed. DO NOT open any new tab in the tab bar!
    // Silently fetch Open Graph & site branding in the background (0 new tabs!)
    const ogResult = await generateOpenGraphThumbnail(targetUrl, title);
    if (ogResult) {
      return ogResult;
    }

    return null;
  })();

  inFlightScreenshots.set(key, promise);
  promise.finally(() => inFlightScreenshots.delete(key));
  return promise;
}

/**
 * Open Graph & Site Image Extraction (Pure Background Fetch - 0 Tabs)
 */
async function fetchOpenGraphImages(url) {
  let target = url.trim();
  if (!/^https?:\/\//i.test(target)) target = 'https://' + target;
  target = target.replace(/#.*$/, '');

  let urlObj;
  try {
    urlObj = new URL(target);
  } catch (e) {
    return { banners: [], icons: [] };
  }
  const origin = urlObj.origin;
  const hostname = urlObj.hostname.toLowerCase();
  const pathname = urlObj.pathname;

  const banners = [];
  const icons = [];

  // 1. YouTube video / shorts / playlist
  if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
    let videoId = null;
    if (hostname.includes('youtu.be')) {
      videoId = pathname.replace(/^\/+/, '').split('/')[0];
    } else if (urlObj.searchParams && urlObj.searchParams.get('v')) {
      videoId = urlObj.searchParams.get('v');
    } else if (pathname.includes('/shorts/')) {
      const match = pathname.match(/\/shorts\/([a-zA-Z0-9_-]+)/);
      if (match) videoId = match[1];
    }
    if (videoId) {
      banners.push(`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`);
      banners.push(`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`);
    }
  }

  // 2. Google Drive / Docs / Sheets thumbnail
  if (hostname.includes('docs.google.com') || hostname.includes('drive.google.com')) {
    const fileMatch = target.match(/\/d\/([a-zA-Z0-9_-]+)/);
    if (fileMatch && fileMatch[1]) {
      banners.push(`https://drive.google.com/thumbnail?id=${fileMatch[1]}&sz=w1280`);
      banners.push(`https://drive.google.com/thumbnail?id=${fileMatch[1]}&sz=w640`);
    }
  }

  // 3. GitHub repository OpenGraph banner
  if (hostname === 'github.com') {
    const ghMatch = pathname.match(/^\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)/);
    if (ghMatch && ghMatch[1] && ghMatch[2] && !['features', 'topics', 'trending', 'settings', 'orgs', 'marketplace'].includes(ghMatch[1])) {
      banners.push(`https://opengraph.githubassets.com/1/${ghMatch[1]}/${ghMatch[2]}`);
    }
  }

  // 4. Reddit: Prioritize official high-res Snoo icon, avoid scraping random user post memes
  if (hostname.includes('reddit.com')) {
    icons.push(`https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://www.reddit.com&size=256`);
  }

  // 5. Fetch page HTML silently in background
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(target, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const html = await res.text();
      const finalUrl = res.url || target;

      // 5a. Open Graph og:image (ignore for Reddit home/feed where og:image is a random post meme)
      const isRedditFeed = hostname.includes('reddit.com') && (!pathname || !pathname.includes('/comments/'));
      if (!isRedditFeed) {
        const ogMatches = [
          ...html.matchAll(/<meta(?=[^>]*?(?:property|name)=["']og:image(?::url|:secure_url)?["'])[^>]*?content=["']([^"']+)["']/gi),
          ...html.matchAll(/<meta(?=[^>]*?content=["']([^"']+)["'])[^>]*?(?:property|name)=["']og:image(?::url|:secure_url)?["']/gi)
        ];
        for (const m of ogMatches) {
          if (m[1]) banners.push(cleanCandidateUrl(m[1], finalUrl));
        }
      }

      // 5b. Twitter Cards twitter:image
      const twitterMatches = [
        ...html.matchAll(/<meta(?=[^>]*?(?:property|name)=["']twitter:image(?::src)?["'])[^>]*?content=["']([^"']+)["']/gi),
        ...html.matchAll(/<meta(?=[^>]*?content=["']([^"']+)["'])[^>]*?(?:property|name)=["']twitter:image(?::src)?["']/gi)
      ];
      for (const m of twitterMatches) {
        if (m[1]) banners.push(cleanCandidateUrl(m[1], finalUrl));
      }

      // 5c. Schema.org Microdata (<meta itemprop="image">)
      const schemaMatches = [
        ...html.matchAll(/<meta(?=[^>]*?itemprop=["']image["'])[^>]*?content=["']([^"']+)["']/gi),
        ...html.matchAll(/<meta(?=[^>]*?content=["']([^"']+)["'])[^>]*?itemprop=["']image["']/gi)
      ];
      for (const m of schemaMatches) {
        if (m[1]) banners.push(cleanCandidateUrl(m[1], finalUrl));
      }

      // 5d. Prominent page images (article / main / amazon)
      const articleImgMatches = [
        ...html.matchAll(/<(?:article|main)[^>]*>[\s\S]*?<img[^>]+src=["']([^"']+)["']/gi),
        ...html.matchAll(/id=["'](?:main-image-container|landingImage)["'][^>]*>[\s\S]*?<img[^>]+src=["']([^"']+)["']/gi)
      ];
      for (const m of articleImgMatches) {
        if (m[1] && !m[1].includes('sprite') && !m[1].includes('pixel') && !m[1].includes('badge')) {
          banners.push(cleanCandidateUrl(m[1], finalUrl));
        }
      }

      // 5e. Apple Touch Icons
      const appleIcons = [
        ...html.matchAll(/<link(?=[^>]*?rel=["'][^"']*?apple-touch-icon(?:-precomposed)?[^"']*?["'])[^>]*?href=["']([^"']+)["']/gi),
        ...html.matchAll(/<link(?=[^>]*?href=["']([^"']+)["'])[^>]*?rel=["'][^"']*?apple-touch-icon(?:-precomposed)?[^"']*?["']/gi)
      ];
      for (const m of appleIcons) {
        if (m[1]) icons.push(cleanCandidateUrl(m[1], finalUrl));
      }

      // 5f. Web App Manifest
      const manifestMatch = html.match(/<link(?=[^>]*?rel=["']manifest["'])[^>]*?href=["']([^"']+)["']/i);
      if (manifestMatch && manifestMatch[1]) {
        try {
          const manifestUrl = cleanCandidateUrl(manifestMatch[1], finalUrl);
          const mfController = new AbortController();
          const mfTimeout = setTimeout(() => mfController.abort(), 2500);
          const mfRes = await fetch(manifestUrl, { signal: mfController.signal });
          clearTimeout(mfTimeout);
          if (mfRes.ok) {
            const mfData = await mfRes.json();
            if (mfData && Array.isArray(mfData.icons) && mfData.icons.length > 0) {
              const sorted = mfData.icons
                .filter(ic => ic.src)
                .sort((a, b) => {
                  const szA = parseInt(a.sizes || '0');
                  const szB = parseInt(b.sizes || '0');
                  return szB - szA;
                });
              if (sorted.length > 0) {
                icons.push(cleanCandidateUrl(sorted[0].src, manifestUrl));
              }
            }
          }
        } catch (e) {}
      }

      // 5g. Icons / Favicons
      const linkIcons = [
        ...html.matchAll(/<link(?=[^>]*?rel=["'][^"']*?(?:icon|shortcut icon)[^"']*?["'])[^>]*?href=["']([^"']+)["']/gi),
        ...html.matchAll(/<link(?=[^>]*?href=["']([^"']+)["'])[^>]*?(?:icon|shortcut icon)[^"']*?["']/gi)
      ];
      for (const m of linkIcons) {
        if (m[1]) icons.push(cleanCandidateUrl(m[1], finalUrl));
      }
    }
  } catch (e) {}

  // 6. High-res Google Social Favicon 256px and DuckDuckGo (up to 512px)
  icons.push(`https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=${encodeURIComponent(origin)}&size=256`);
  icons.push(`https://icons.duckduckgo.com/ip3/${hostname}.ico`);
  icons.push(`${origin}/favicon.ico`);

  function dedupe(arr) {
    const seen = new Set();
    const out = [];
    for (const item of arr) {
      if (item && !seen.has(item)) {
        seen.add(item);
        out.push(item);
      }
    }
    return out;
  }

  return {
    banners: dedupe(banners),
    icons: dedupe(icons)
  };
}

/**
 * Fetch candidate images and render high-res thumbnail card (0 Tabs!)
 */
async function generateOpenGraphThumbnail(url, title = '') {
  const cleanUrl = (url || '').trim();
  if (!cleanUrl || cleanUrl.startsWith('about:') || cleanUrl.startsWith('chrome:') || cleanUrl.startsWith('moz-extension:')) {
    return null;
  }

  let domain = '';
  try {
    domain = new URL(cleanUrl).hostname.replace(/^www\./, '');
  } catch (e) {}

  const { banners, icons } = await fetchOpenGraphImages(cleanUrl);

  const targetWidth = 640;
  const targetHeight = 384;

  async function loadImage(imgUrl) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(imgUrl, {
        signal: controller.signal,
        headers: {
          'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
        }
      });
      clearTimeout(timeoutId);
      if (!res.ok) return null;
      const blob = await res.blob();
      if (!blob || blob.size < 80) return null;
      const blobUrl = URL.createObjectURL(blob);

      return await new Promise((resolve) => {
        const img = new Image();
        const timer = setTimeout(() => {
          img.src = '';
          try { URL.revokeObjectURL(blobUrl); } catch (e) {}
          resolve(null);
        }, 5000);

        img.onload = () => {
          clearTimeout(timer);
          resolve({ img, blobUrl });
        };
        img.onerror = () => {
          clearTimeout(timer);
          try { URL.revokeObjectURL(blobUrl); } catch (e) {}
          resolve(null);
        };
        img.src = blobUrl;
      });
    } catch (e) {
      return null;
    }
  }

  // 1. Try BANNERS & Social Previews first!
  for (const bUrl of banners) {
    const loaded = await loadImage(bUrl);
    if (!loaded) continue;
    const { img, blobUrl } = loaded;

    try {
      if (img.width >= 160 && img.height >= 80) {
        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        const imgRatio = img.width / img.height;

        if (imgRatio >= 1.15) {
          // Wide banner: Crop and fill whole card
          const scale = Math.max(targetWidth / img.width, targetHeight / img.height);
          const w = img.width * scale;
          const h = img.height * scale;
          const x = (targetWidth - w) / 2;
          const y = (targetHeight - h) / 2;
          ctx.drawImage(img, x, y, w, h);
        } else {
          // Square or portrait photo: Ambient blurred background + centered crisp photo
          ctx.save();
          ctx.filter = 'blur(20px) brightness(0.7)';
          const bgScale = Math.max(targetWidth / img.width, targetHeight / img.height);
          const bgW = img.width * bgScale * 1.25;
          const bgH = img.height * bgScale * 1.25;
          ctx.drawImage(img, (targetWidth - bgW) / 2, (targetHeight - bgH) / 2, bgW, bgH);
          ctx.restore();

          ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
          ctx.fillRect(0, 0, targetWidth, targetHeight);

          const maxH = targetHeight * 0.85;
          const maxW = targetWidth * 0.85;
          const fitScale = Math.min(maxW / img.width, maxH / img.height);
          const fw = img.width * fitScale;
          const fh = img.height * fitScale;
          const fx = (targetWidth - fw) / 2;
          const fy = (targetHeight - fh) / 2;

          ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
          ctx.shadowBlur = 18;
          ctx.shadowOffsetY = 6;
          ctx.drawImage(img, fx, fy, fw, fh);
        }

        try { URL.revokeObjectURL(blobUrl); } catch (e) {}
        const opt = canvas.toDataURL('image/webp', 0.86);
        await saveThumbnail(cleanUrl, opt, false);
        return opt;
      }
    } catch (e) {}
    try { URL.revokeObjectURL(blobUrl); } catch (e) {}
  }

  // 2. If no banners succeeded, try ICONS & High-Res Logos
  for (const iUrl of icons) {
    const loaded = await loadImage(iUrl);
    if (!loaded) continue;
    const { img, blobUrl } = loaded;

    try {
      if (img.width >= 16 && img.height >= 16) {
        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // Dark luxury gradient card
        const grad = ctx.createLinearGradient(0, 0, targetWidth, targetHeight);
        grad.addColorStop(0, '#24252a');
        grad.addColorStop(1, '#16171a');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, targetWidth, targetHeight);

        const boxSize = 108;
        const boxX = (targetWidth - boxSize) / 2;
        const boxY = (targetHeight - boxSize) / 2 - 14;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
        ctx.lineWidth = 1;
        if (ctx.roundRect) {
          ctx.beginPath();
          ctx.roundRect(boxX, boxY, boxSize, boxSize, 22);
          ctx.fill();
          ctx.stroke();
        } else {
          ctx.fillRect(boxX, boxY, boxSize, boxSize);
        }

        const maxIcon = 78;
        const iconScale = Math.min(maxIcon / img.width, maxIcon / img.height, 1);
        const iw = img.width * iconScale;
        const ih = img.height * iconScale;
        const ix = boxX + (boxSize - iw) / 2;
        const iy = boxY + (boxSize - ih) / 2;
        ctx.drawImage(img, ix, iy, iw, ih);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.font = '600 15px -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const displayLabel = title || domain || '';
        const truncated = (displayLabel.length > 28) ? displayLabel.slice(0, 26) + '…' : displayLabel;
        ctx.fillText(truncated, targetWidth / 2, boxY + boxSize + 30);

        try { URL.revokeObjectURL(blobUrl); } catch (e) {}
        const opt = canvas.toDataURL('image/webp', 0.86);
        await saveThumbnail(cleanUrl, opt, false);
        return opt;
      }
    } catch (e) {}
    try { URL.revokeObjectURL(blobUrl); } catch (e) {}
  }

  return null;
}

// In-flight thumbnail capture promises to prevent duplicate requests
const inFlightThumbnails = new Map();

function getOrGenerateThumbnail(url, title = '', force = false) {
  const key = getThumbKey(url);
  if (force) {
    inFlightThumbnails.delete(key);
  } else if (inFlightThumbnails.has(key)) {
    return inFlightThumbnails.get(key);
  }

  const promise = generateOpenGraphThumbnail(url, title);
  inFlightThumbnails.set(key, promise);
  promise.finally(() => inFlightThumbnails.delete(key));
  return promise;
}

// Map of tabId -> target bookmark URL for pending tabs
const pendingBookmarkTabs = new Map();

/**
 * Match a loaded tab URL against favorites
 */
async function findMatchingBookmarkUrl(tabUrl) {
  if (!tabUrl || tabUrl.startsWith('about:') || tabUrl.startsWith('chrome:') || tabUrl.startsWith('moz-extension:')) {
    return null;
  }

  const res = await getStorageData(['safari_speeddial_state']);
  const state = res.safari_speeddial_state;
  if (state) {
    function searchItems(items) {
      if (!items || !Array.isArray(items)) return null;
      for (const it of items) {
        if (it.type === 'folder' && it.children) {
          const sub = searchItems(it.children);
          if (sub) return sub;
        } else if (it.type === 'url' && it.url) {
          if (isMatchingTab(tabUrl, it.url)) return it.url;
        }
      }
      return null;
    }

    let match = searchItems(state.items);
    if (match) return match;

    if (state.favoriteSections && Array.isArray(state.favoriteSections)) {
      for (const sec of state.favoriteSections) {
        match = searchItems(sec.items);
        if (match) return match;
      }
    }
  }

  return null;
}

/**
 * Handle live capture from active tab (used when browsing tab finishes loading)
 */
async function captureTabLive(tabId, matchedUrl) {
  try {
    if (!browser || !browser.tabs || !browser.tabs.captureTab) return null;
    const tab = await browser.tabs.get(tabId);
    if (!tab || !tab.active) return null;

    const raw = await browser.tabs.captureTab(tabId, { format: 'jpeg', quality: 85 });
    if (!raw) return null;

    const opt = await downscaleRawScreenshot(raw);
    if (opt) {
      await saveThumbnail(matchedUrl, opt, false);
      return opt;
    }
    return null;
  } catch (e) {
    return null;
  }
}

/**
 * Passive capture: When the user is ALREADY browsing a bookmarked tab in Firefox,
 * update the thumbnail with the live view (ZERO windows opened!).
 */
async function handleUserBrowsingTab(tabId, url) {
  if (!url || url.startsWith('about:') || url.startsWith('chrome:') || url.startsWith('moz-extension:')) return;

  let matchedUrl = pendingBookmarkTabs.get(tabId);
  if (!matchedUrl) {
    matchedUrl = await findMatchingBookmarkUrl(url);
  }
  if (!matchedUrl) return;

  setTimeout(async () => {
    try {
      await captureTabLive(tabId, matchedUrl);
    } catch (e) {}
  }, 900);
}

/**
 * Handle runtime messages from newtab:
 * - If force is true (user clicked "Actualizar captura"), capture real screenshot of the URL!
 * - If force is false (background queue), use silent Open Graph metadata.
 */
async function handleCaptureUrlLive(msg) {
  if (!msg || !msg.url) return { success: false, dataUrl: null };

  // Manual refresh via right click: Capture live screenshot of the URL link (0 new tabs)!
  if (msg.force) {
    const screenshot = await captureUrlScreenshotLive(msg.url, msg.title || '');
    if (screenshot) {
      return { success: true, dataUrl: screenshot };
    }

    // If live screenshot failed, check if a valid thumbnail already exists
    const hasExisting = await hasThumbnailInDB(msg.url);
    if (!hasExisting) {
      // Only if no thumbnail exists at all, try silent Open Graph fallback
      const ogRes = await getOrGenerateThumbnail(msg.url, msg.title || '', false);
      if (ogRes) {
        return { success: true, dataUrl: ogRes };
      }
    }

    return { success: false, dataUrl: null };
  }

  // Initial queue / background check: Silent Open Graph fetch (no tab creation)
  const res = await getOrGenerateThumbnail(msg.url, msg.title || '', false);
  if (res) {
    return { success: true, dataUrl: res };
  }

  return { success: false, dataUrl: null };
}

// Runtime message listener
if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.onMessage) {
  browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.action) return;

    if (msg.action === 'captureUrlLive') {
      const promise = handleCaptureUrlLive(msg).then((result) => {
        if (typeof sendResponse === 'function') sendResponse(result);
        return result;
      }).catch((err) => {
        const fallback = { success: false, error: String(err) };
        if (typeof sendResponse === 'function') sendResponse(fallback);
        return fallback;
      });
      return promise; // Promise-based for Firefox browser.runtime.sendMessage
    }

    if (msg.action === 'bookmarkOpening' && msg.url) {
      // User clicked bookmark: prepare tab tracking (do NOT overwrite live screenshots with favicons!)
    }

    if (msg.action === 'tabCreatedForBookmark' && msg.tabId && msg.url) {
      pendingBookmarkTabs.set(msg.tabId, msg.url);
    }

    if (msg.action === 'tabNavigatingForBookmark' && msg.tabId && msg.url) {
      pendingBookmarkTabs.set(msg.tabId, msg.url);
    }

    if (msg.action === 'captureUrl' && msg.url) {
      getOrGenerateThumbnail(msg.url, msg.title || '').catch(() => {});
    }
  });
}

// 1. Passive capture when a user finishes loading a bookmarked tab in their window
if (typeof browser !== 'undefined' && browser.tabs && browser.tabs.onUpdated) {
  browser.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
      try {
        const currentTab = await browser.tabs.get(tabId);
        if (currentTab && currentTab.active && currentTab.url) {
          handleUserBrowsingTab(tabId, currentTab.url);
        }
      } catch (e) {}
    }
  });
}

// 2. Passive capture when user switches to a bookmarked tab in their window
if (typeof browser !== 'undefined' && browser.tabs && browser.tabs.onActivated) {
  browser.tabs.onActivated.addListener(async (activeInfo) => {
    try {
      const tab = await browser.tabs.get(activeInfo.tabId);
      if (tab && tab.url && tab.status === 'complete') {
        handleUserBrowsingTab(activeInfo.tabId, tab.url);
      }
    } catch (e) {}
  });
}

// Clean up pending tabs when tab is closed
if (typeof browser !== 'undefined' && browser.tabs && browser.tabs.onRemoved) {
  browser.tabs.onRemoved.addListener((tabId) => {
    pendingBookmarkTabs.delete(tabId);
  });
}
