/**
 * Safari Speed Dial for Firefox
 * Faithfully replicates Safari Start Page Favorites with:
 * - Live Firefox bookmarks sync (all bookmarks & all folders)
 * - Safari-style fluid animated Drag and Drop reordering (FLIP transitions)
 * - Flexible URL entry (meneame.net) with auto-completed name
 * - Steppers for Columns, Rows, Icon Size, and Element Spacing
 * - "Limpiar página" and "Reimportar de Firefox" actions
 */

(function () {
  'use strict';

  const browserAPI = (typeof browser !== 'undefined') ? browser : ((typeof chrome !== 'undefined') ? chrome : (window.browser || window.chrome || {}));

  /**
   * Universal cross-browser storage helpers (Promise and Callback agnostic)
   */
  async function getStorageData(keys) {
    try {
      if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
        const res = await browser.storage.local.get(keys);
        if (res) return res;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        return await new Promise((resolve) => {
          try {
            chrome.storage.local.get(keys, (res) => resolve(res || {}));
          } catch (err) {
            resolve({});
          }
        });
      }
    } catch (e) {}
    return {};
  }

  async function setStorageData(obj) {
    try {
      if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
        await browser.storage.local.set(obj);
        return;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await new Promise((resolve) => {
          try {
            chrome.storage.local.set(obj, () => resolve());
          } catch (err) {
            resolve();
          }
        });
      }
    } catch (e) {}
  }

  async function removeStorageData(keys) {
    try {
      if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) {
        await browser.storage.local.remove(keys);
        return;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        await new Promise((resolve) => {
          try {
            chrome.storage.local.remove(keys, () => resolve());
          } catch (err) {
            resolve();
          }
        });
      }
    } catch (e) {}
  }

  // Default Apple Start Page palette for letter monograms
  const APPLE_COLORS = [
    '#E04438', // Safari Red
    '#EA6127', // Safari Orange
    '#D97724', // Amber
    '#5B6E38', // Olive Green
    '#2E7D32', // Emerald
    '#0A84FF', // Apple Blue
    '#2563EB', // Cobalt
    '#6D28D9', // Purple
    '#A21CAF', // Magenta
    '#BE123C', // Crimson
    '#4B5563', // Slate
    '#1F2937'  // Charcoal
  ];

  // Brand icons & SVG definitions
  const BRAND_SVGS = {
    google: `<svg viewBox="0 0 48 48" width="46" height="46"><path fill="#FFC107" d="M43.6 20H24v8.5h11.3C33.7 33.6 29.3 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 6 .1 8.2 3.1l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.4-4z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 11 24 11c3.1 0 6 1.1 8.2 3.1l6.4-6.4C34.6 4.1 29.6 2 24 2 16.5 2 9.9 7.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 46c5.3 0 10.3-1.9 14.1-5.3l-6.5-5.3c-2.1 1.5-4.7 2.4-7.6 2.4-5.3 0-9.8-3.4-11.4-8.3l-6.6 5.1C9.6 40.5 16.3 46 24 46z"/><path fill="#1976D2" d="M43.6 20H24v8.5h11.3c-.9 2.7-2.6 4.9-4.8 6.5l6.5 5.3C40.8 36.6 44 30.7 44 24c0-1.3-.1-2.7-.4-4z"/></svg>`,
    gemini: `<svg viewBox="0 0 48 48" width="46" height="46"><defs><linearGradient id="geminiGrad" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stop-color="#1B72E8"/><stop offset="35%" stop-color="#8E51FF"/><stop offset="70%" stop-color="#E84435"/><stop offset="100%" stop-color="#F8BC06"/></linearGradient></defs><path fill="url(#geminiGrad)" d="M24 2C24 14.15 14.15 24 2 24C14.15 24 24 33.85 24 46C24 33.85 33.85 24 46 24C33.85 24 24 14.15 24 2Z"/></svg>`,
    youtube: `<svg viewBox="0 0 48 48" width="52" height="52"><path fill="#FF0000" d="M43.2 13.9c-.5-1.9-2-3.4-3.9-3.9C35.9 9 24 9 24 9s-11.9 0-15.3 1c-1.9.5-3.4 2-3.9 3.9C3.8 17.3 3.8 24 3.8 24s0 6.7 1 10.1c.5 1.9 2 3.4 3.9 3.9 3.4 1 15.3 1 15.3 1s11.9 0 15.3-1c1.9-.5 3.4-2 3.9-3.9 1-3.4 1-10.1 1-10.1s0-6.7-1-10.1z"/><polygon fill="#FFFFFF" points="20,31 31,24 20,17"/></svg>`,
    x: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#000000"/><path fill="#FFFFFF" d="M34.5 10h5.3L28.2 23.3 42 41.5H31.3l-8.4-11-9.6 11H8l12.4-14.2L7.2 10h11l7.6 10.1L34.5 10zm-1.9 28.3h2.9L16.2 13H13.1l19.5 25.3z"/></svg>`,
    reddit: `<svg viewBox="0 0 48 48" width="48" height="48"><circle cx="24" cy="24" r="22" fill="#FF4500"/><path fill="#FFFFFF" d="M37.5 22.8c0-1.5-1.2-2.7-2.7-2.7-.7 0-1.4.3-1.9.8-2.3-1.6-5.5-2.6-9-2.7l1.5-7.2 5 1.1c.1 1.3 1.1 2.3 2.5 2.3 1.4 0 2.5-1.1 2.5-2.5s-1.1-2.5-2.5-2.5c-1 0-1.9.6-2.3 1.5l-5.6-1.2c-.3-.1-.6.1-.7.4L22.4 18c-3.6.1-6.8 1.1-9.1 2.7-.5-.5-1.2-.8-1.9-.8-1.5 0-2.7 1.2-2.7 2.7 0 1.1.6 2 1.5 2.4-.1.5-.1 1-.1 1.6 0 4.8 5.7 8.7 12.8 8.7s12.8-3.9 12.8-8.7c0-.5 0-1.1-.1-1.6.9-.5 1.5-1.4 1.5-2.5zm-19.1 3c1 0 1.9.8 1.9 1.9s-.8 1.9-1.9 1.9-1.9-.8-1.9-1.9.8-1.9 1.9-1.9zm11.3 7.3c-1.7 1.2-4.1 1.3-5.7 1.3-1.6 0-4-.1-5.7-1.3-.3-.2-.3-.6-.1-.9.2-.3.6-.3.9-.1 1.4 1 3.4 1.1 4.9 1.1 1.5 0 3.5-.1 4.9-1.1.3-.2.7-.1.9.1.2.3.1.7-.1.9zm-.1-5.4c-1 0-1.9-.8-1.9-1.9s.8-1.9 1.9-1.9 1.9.8 1.9 1.9-.9 1.9-1.9 1.9z"/></svg>`,
    netflix: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#141414"/><path fill="#E50914" d="M14 8h6v32h-6zM28 8h6v32h-6z"/><path fill="#B81D24" d="M14 8h6l14 32h-6z"/></svg>`,
    gmail: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#FFFFFF"/><path fill="#EA4335" d="M38.5 10H9.5C7.6 10 6 11.6 6 13.5l18 13 18-13c0-1.9-1.6-3.5-3.5-3.5z"/><path fill="#D93025" d="M6 13.5v21c0 1.9 1.6 3.5 3.5 3.5h3.5V22.5L6 13.5z"/><path fill="#D93025" d="M42 13.5v21c0 1.9-1.6 3.5-3.5 3.5H35V22.5l7-9z"/><path fill="none" stroke="#EA4335" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" d="M6 13.5L24 26.5 42 13.5M6 34.5V13.5M42 34.5V13.5"/></svg>`,
    github: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#24292e"/><path fill="#FFFFFF" d="M24 10C16.3 10 10 16.3 10 24c0 6.2 4 11.4 9.6 13.3.7.1 1-.3 1-.7v-2.4c-3.9.8-4.7-1.9-4.7-1.9-.6-1.6-1.5-2.1-1.5-2.1-1.3-.9.1-.9.1-.9 1.4.1 2.2 1.5 2.2 1.5 1.3 2.2 3.3 1.5 4.1 1.2.1-.9.5-1.5.9-1.9-3.1-.4-6.4-1.6-6.4-7 0-1.5.5-2.8 1.5-3.8-.1-.4-.7-1.8.1-3.7 0 0 1.2-.4 3.9 1.5 1.1-.3 2.3-.5 3.5-.5s2.4.2 3.5.5c2.7-1.9 3.9-1.5 3.9-1.5.8 1.9.3 3.4.1 3.7 1 1 1.5 2.3 1.5 3.8 0 5.4-3.3 6.6-6.4 7 .5.4 1 1.3 1 2.6v3.8c0 .4.3.8 1 .7C34 35.4 38 30.2 38 24c0-7.7-6.3-14-14-14z"/></svg>`,
    amazon: `<svg viewBox="0 0 48 48" width="46" height="46"><path fill="#FF9900" d="M33.4 34.2c-5.2 3.8-12.8 5.8-19.3 5.8-9.1 0-17.3-3.4-23.5-9.1-.5-.4-.1-1.1.5-.7 6.7 4 14.8 6.4 23 6.4 5.8 0 12.1-1.4 17.8-4.4.9-.5 1.7.5.9 1.2l.6.8z"/><path fill="#FF9900" d="M35.6 31.9c-.7-.9-4.4-.4-6.1-.2-.5.1-.6-.4-.2-.7 2.7-1.9 7.2-1.3 7.8-.5.6.8-.2 5.3-2.7 7.4-.4.3-.8.1-.6-.3.6-1.5 2.5-4.8 1.8-5.7z"/><path fill="#FFFFFF" d="M25.7 13.6c-1.3 0-2.8.4-3.7 1.1-.3.2-.5.5-.3.8l1.3 2.1c.2.3.5.4.8.2.5-.4 1.1-.6 1.8-.6 1.3 0 2.1.8 2.1 2.2v1c-7.3.7-10.9 3.5-10.9 8.2 0 4.2 3.1 6.8 7.3 6.8 3.3 0 5.4-1.4 6.5-3.3h.1v2.5c0 .4.3.7.7.7h3.1c.4 0 .7-.3.7-.7v-13.6c0-4.6-3.7-7.3-9.6-7.3zm2 14.4c-.6 1.4-1.9 2.5-3.6 2.5-1.9 0-3.1-1.2-3.1-2.9 0-2.6 2.2-3.8 6.7-4.1v4.5z"/></svg>`,
    spotify: `<svg viewBox="0 0 48 48" width="46" height="46"><circle cx="24" cy="24" r="22" fill="#1DB954"/><path fill="#FFFFFF" d="M34.3 31.1c-.4.6-1.2.8-1.8.4-5-3.1-11.3-3.8-18.7-2.1-.7.2-1.4-.3-1.5-1-.2-.7.3-1.4 1-1.5 8.1-1.9 15.1-1.1 20.6 2.3.6.4.8 1.3.4 1.9zm2.7-6c-.5.8-1.5 1-2.3.5-5.7-3.5-14.4-4.5-21.1-2.5-.9.3-1.8-.2-2.1-1.1-.3-.9.2-1.8 1.1-2.1 7.7-2.3 17.3-1.2 23.8 2.8.8.6 1 1.6.6 2.4zm.2-6.3C30.4 14.8 19.1 14.4 12.6 16.4c-1 .3-2.1-.3-2.4-1.3-.3-1 .3-2.1 1.3-2.4 7.6-2.3 20-1.8 28 3 1 .6 1.3 1.8.7 2.8-.5.9-1.8 1.2-2.7.6z"/></svg>`,
    twitch: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#9146FF"/><path fill="#FFFFFF" d="M12 9l-3 7v21h8v5h5l5-5h6l9-9V9H12zm26 19l-5 5h-7l-5 5v-5h-5V13h22v15zm-13-8h4v8h-4v-8zm9 0h4v8h-4v-8z"/></svg>`,
    wikipedia: `<svg viewBox="0 0 48 48" width="46" height="46"><rect width="48" height="48" rx="10" fill="#FFFFFF"/><path fill="#000000" d="M37.3 12.2l3.4-.6v.8l-2.4.5c-.8.2-1.4.7-1.8 1.6l-6.8 18.2h-1.3l-5-13.6-5.3 13.6h-1.4l-7-18.4c-.4-.9-1-1.4-1.8-1.6l-2.4-.4v-.8l4.4.6v.8l-1.6.3c-.6.1-.9.5-.7 1.1l5.4 14.6 4.3-11.4-2.1-5.1c-.5-.7-.9-.9-1.7-1l-1.6-.2v-.8l4.4.6v.8l-1.5.3c-.7.1-1 .5-.7 1.2l4.8 12.5 4.1-10.8c.4-.9.1-1.6-.5-1.9l-1.9-.3v-.8l3.6.6v.8l-1.3.3c-.6.1-.9.6-.7 1.2l3.2 8.5 3.3-8.8c.3-.8 0-1.4-.6-1.7l-1.8-.3v-.7z"/></svg>`
  };

  // View mode config: icons & labels for dropdown
  const VIEW_MODE_CONFIG = {
    grid: {
      label: 'Iconos',
      svg: `<svg viewBox="0 0 20 20" width="13" height="13" fill="currentColor"><path d="M4.25 2A2.25 2.25 0 002 4.25v2.5A2.25 2.25 0 004.25 9h2.5A2.25 2.25 0 009 6.75v-2.5A2.25 2.25 0 006.75 2h-2.5zm8.5 0A2.25 2.25 0 0010.5 4.25v2.5A2.25 2.25 0 0012.75 9h2.5A2.25 2.25 0 0017.5 6.75v-2.5A2.25 2.25 0 0015.25 2h-2.5zM4.25 11A2.25 2.25 0 002 13.25v2.5A2.25 2.25 0 004.25 18h2.5A2.25 2.25 0 009 15.75v-2.5A2.25 2.25 0 006.75 11h-2.5zm8.5 0a2.25 2.25 0 00-2.25 2.25v2.5A2.25 2.25 0 0012.75 18h2.5A2.25 2.25 0 0017.5 15.75v-2.5A2.25 2.25 0 0015.25 11h-2.5z"/></svg>`
    },
    tile: {
      label: 'Fichas',
      svg: `<svg viewBox="0 0 20 20" width="13" height="13" fill="currentColor"><path fill-rule="evenodd" d="M2 4.75A2.75 2.75 0 014.75 2h10.5A2.75 2.75 0 0118 4.75v2.5A2.75 2.75 0 0115.25 10H4.75A2.75 2.75 0 012 7.25v-2.5zM4.75 3.5c-.69 0-1.25.56-1.25 1.25v2.5c0 .69.56 1.25 1.25 1.25h10.5c.69 0 1.25-.56 1.25-1.25v-2.5c0-.69-.56-1.25-1.25-1.25H4.75zm-2.75 9.25A2.75 2.75 0 014.75 10h10.5A2.75 2.75 0 0118 12.75v2.5A2.75 2.75 0 0115.25 18H4.75A2.75 2.75 0 012 15.25v-2.5zm2.75-1.25c-.69 0-1.25.56-1.25 1.25v2.5c0 .69.56 1.25 1.25 1.25h10.5c.69 0 1.25-.56 1.25-1.25v-2.5c0-.69-.56-1.25-1.25-1.25H4.75z" clip-rule="evenodd"/></svg>`
    },
    thumb: {
      label: 'Thumbnails',
      svg: `<svg viewBox="0 0 20 20" width="13" height="13" fill="currentColor"><path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/></svg>`
    }
  };

  // State
  let state = {
    favoriteSections: [
      {
        id: 'section_default',
        title: 'Favoritos',
        items: []
      }
    ],
    activeFavoriteSectionId: 'section_default',
    settings: {
      cardSize: 74,
      thumbWidth: 220,
      thumbHeight: 132,
      cardGap: 16,
      title: '',
      theme: 'dark',
      viewMode: 'grid',
      iconStyle: 'uniform',
      showSearchBar: true,
      searchBarCenter: false,
      expandScreen: false,
      panelLabelSize: 'normal',
      customWallpaper: 'wallpapers/galaxy.jpg',
      wallpaperInitialized: true,
      folderColor: 'liquid-glass',
      folderAnimation: true,
      bookmarkColor: 'liquid-glass',
      bookmarkSameColorAsFolder: false,
      liquidGlass: {
        refraction: 0.08,
        blur: 0.8,
        bevel: 0.35,
        useMouseLight: false
      },
      sections: {
        favorites: { enabled: true, collapsed: false, viewMode: 'grid' },
        closedTabs: { enabled: true, collapsed: false, viewMode: 'grid' },
        history: { enabled: true, collapsed: false, viewMode: 'grid' }
      }
    },
    activeFolderId: null
  };

  function ensureFavoriteSections() {
    if (!state.favoriteSections || !Array.isArray(state.favoriteSections) || state.favoriteSections.length === 0) {
      const defaultTitle = (state.settings && state.settings.title) ? state.settings.title : 'Favoritos';
      state.favoriteSections = [
        {
          id: 'section_default',
          title: defaultTitle,
          items: []
        }
      ];
      state.activeFavoriteSectionId = 'section_default';
    }
    if (!state.activeFavoriteSectionId || !state.favoriteSections.some(s => s.id === state.activeFavoriteSectionId)) {
      state.activeFavoriteSectionId = state.favoriteSections[0].id;
    }
  }

  function getActiveFavoriteSection() {
    ensureFavoriteSections();
    return state.favoriteSections.find(s => s.id === state.activeFavoriteSectionId) || state.favoriteSections[0];
  }

  function setupStateGetters(targetState) {
    if (!targetState) return;
    try {
      Object.defineProperty(targetState, 'items', {
        get() {
          ensureFavoriteSections();
          const sec = targetState.favoriteSections.find(s => s.id === targetState.activeFavoriteSectionId) || targetState.favoriteSections[0];
          if (!sec.items) sec.items = [];
          return sec.items;
        },
        set(val) {
          ensureFavoriteSections();
          const sec = targetState.favoriteSections.find(s => s.id === targetState.activeFavoriteSectionId) || targetState.favoriteSections[0];
          sec.items = Array.isArray(val) ? val : [];
        },
        enumerable: true,
        configurable: true
      });
    } catch (e) {}
  }

  setupStateGetters(state);

  // Pointer-based Drag & Drop state (matching liquidtest)
  let dragNode = null;
  let dragGhost = null;
  let ghostOffset = { x: 0, y: 0 };
  let dragStartPos = { x: 0, y: 0 };
  let isDragging = false;
  let preventNextClick = false;
  let currentDropTarget = null;
  let currentFolderTarget = null;
  let lastSwapTime = 0;
  const SWAP_THROTTLE = 120;
  let dragStartParent = null; // 'grid' | 'folder'
  let draggedSectionId = null;

  // Compatibility dragData for section tabs
  let dragData = {
    sourceId: null,
    sourceFolderId: null
  };
  let activeFolderDropTargetId = null;
  let hasDroppedIntoFolder = false;
  let lastReorderTime = 0;

  let customDragGhost = null; // alias for dragGhost

  function cleanupCustomDragGhost() {
    if (dragGhost && dragGhost.parentNode) {
      dragGhost.parentNode.removeChild(dragGhost);
    }
    dragGhost = null;
    customDragGhost = null;
    if (dragNode) {
      dragNode.classList.remove('is-placeholder', 'dragging');
    }
    dragNode = null;
    isDragging = false;
    dragStartParent = null;
    if (currentFolderTarget) {
      currentFolderTarget.classList.remove('folder-drop-target', 'is-over-folder');
      currentFolderTarget = null;
    }
    if (currentDropTarget) {
      currentDropTarget.classList.remove('drag-over-left', 'drag-over-right');
      currentDropTarget = null;
    }
    document.querySelectorAll('.folder-drop-target, .is-over-folder, .tab-card-drop-target, .drag-over-left, .drag-over-right').forEach(n => {
      n.classList.remove('folder-drop-target', 'is-over-folder', 'tab-card-drop-target', 'drag-over-left', 'drag-over-right');
    });
    setTimeout(() => { preventNextClick = false; }, 50);
  }

  // Context menu state
  let contextTarget = {
    item: null,
    folderId: null
  };

  // Flag for auto-generated shortcut name
  let isNameAutoGenerated = true;

  // Track items/folders currently being created internally to prevent duplicate additions
  // when browser.bookmarks.onCreated fires synchronously
  const internalCreatingShortcutUrls = new Set();
  const internalCreatingFolderTitles = new Set();

  // DOM Elements: Sections
  const elSectionFavorites = document.getElementById('section-favorites');
  const elGrid = document.getElementById('dial-grid');
  const elSectionTitle = document.getElementById('section-title');
  const elFavoritesTabBar = document.getElementById('favorites-tab-bar');
  const elBtnAddSection = document.getElementById('btn-add-section');
  const elBtnAddShortcut = document.getElementById('btn-add-shortcut');
  const elBtnAddFolder = document.getElementById('btn-add-folder');
  const elEmptyState = document.getElementById('empty-state');
  const elBtnEmptyAdd = document.getElementById('btn-empty-add');

  const elSectionClosedTabs = document.getElementById('section-closed-tabs');
  const elBtnToggleClosedTabs = document.getElementById('btn-toggle-closed-tabs');
  const elClosedTabsGrid = document.getElementById('closed-tabs-grid');
  const elClosedTabsEmpty = document.getElementById('closed-tabs-empty');

  const elSectionHistory = document.getElementById('section-history');
  const elBtnToggleHistory = document.getElementById('btn-toggle-history');
  const elHistoryGrid = document.getElementById('history-grid');
  const elHistoryEmpty = document.getElementById('history-empty');
  let lastClosedTabsSessions = null;
  let lastHistoryResults = null;

  const elBtnOpenSettings = document.getElementById('btn-open-settings');
  const elApp = document.getElementById('app');

  // Start Page Top Bar: Search & View Mode Dropdown
  const elQuickFilterInput = document.getElementById('quick-filter-input');
  const elBtnClearSearch = document.getElementById('btn-clear-search');
  const elViewModeDropdownWrap = document.getElementById('view-mode-dropdown-wrap');
  const elViewModeDropdownBtn = document.getElementById('view-mode-dropdown-btn');
  const elViewModeActiveIcon = document.getElementById('view-mode-active-icon');
  const elViewModeActiveLabel = document.getElementById('view-mode-active-label');
  const elViewModeMenu = document.getElementById('view-mode-menu');
  const elBtnViewGrid = document.getElementById('btn-view-grid');
  const elBtnViewTile = document.getElementById('btn-view-tile');
  const elBtnViewThumb = document.getElementById('btn-view-thumb');
  let currentSearchQuery = '';

  // Modals: Settings
  const elSettingsModal = document.getElementById('settings-modal');
  const elBtnCloseSettings = document.getElementById('btn-close-settings');
  const elBtnSaveSettings = document.getElementById('btn-save-settings');

  // Section Visibility Switches in Settings
  const elSettingShowFavorites = document.getElementById('setting-show-favorites');
  const elSettingShowClosedTabs = document.getElementById('setting-show-closed-tabs');
  const elSettingShowHistory = document.getElementById('setting-show-history');

  // Steppers (Size & Spacing)
  const elDisplaySize = document.getElementById('display-size');
  const elBtnSizeMinus = document.getElementById('btn-size-minus');
  const elBtnSizePlus = document.getElementById('btn-size-plus');
  const elDisplayGap = document.getElementById('display-gap');
  const elBtnGapMinus = document.getElementById('btn-gap-minus');
  const elBtnGapPlus = document.getElementById('btn-gap-plus');

  const elSettingTitleInput = document.getElementById('setting-title-input');
  const elBtnResyncBookmarks = document.getElementById('btn-resync-bookmarks');
  const elBtnClearPage = document.getElementById('btn-clear-page');
  const elBtnImportBrowserFile = document.getElementById('btn-import-browser-file');
  const elInputImportFile = document.getElementById('input-import-file');

  // Search Controls & Custom Wallpaper
  const elSettingShowSearch = document.getElementById('setting-show-search');
  const elSettingCenterSearch = document.getElementById('setting-center-search');
  const elSettingExpandScreen = document.getElementById('setting-expand-screen');
  const elWallpaperBg = document.getElementById('wallpaper-bg');
  const elBtnUploadWallpaper = document.getElementById('btn-upload-wallpaper');
  const elInputWallpaperFile = document.getElementById('input-wallpaper-file');
  const elBtnRemoveWallpaper = document.getElementById('btn-remove-wallpaper');
  const elSettingPanelLabels = document.getElementById('setting-panel-labels');
  const elWpPresetGalaxy = document.getElementById('wp-preset-galaxy');
  const elWpPresetAurora = document.getElementById('wp-preset-aurora');
  const elWpPresetCustom = document.getElementById('wp-preset-custom');
  const elWpPresetCustomImg = document.getElementById('wp-preset-custom-img');
  const elBtnCustomBgColor = document.getElementById('btn-custom-bg-color');
  const elInputCustomBgColor = document.getElementById('input-custom-bg-color');
  const elThemeCustomSwatch = document.getElementById('theme-custom-swatch');

  // Sliding Settings Navigation & Subpanels
  const elSettingsPanelMain = document.getElementById('settings-panel-main');
  const elSettingsPopup = document.querySelector('.settings-popup');
  const elFolderColorPalette = document.getElementById('folder-color-palette');
  const elFolderCustomColorInput = document.getElementById('folder-custom-color-input');
  const elFolderSettingsPreview = document.getElementById('folder-settings-preview');
  const elSettingFolderAnimation = document.getElementById('setting-folder-animation');
  const elSettingBookmarkSameColor = document.getElementById('setting-bookmark-same-color');
  const elBookmarkColorRow = document.getElementById('bookmark-color-row');
  const elBookmarkColorPalette = document.getElementById('bookmark-color-palette');
  const elBookmarkCustomColorInput = document.getElementById('bookmark-custom-color-input');
  const elBookmarkSettingsPreview = document.getElementById('bookmark-settings-preview');
  const elBookmarkPreviewIcon = document.getElementById('bookmark-preview-icon');

  // Liquid Glass Settings Controls
  const elSettingLiquidRefraction = document.getElementById('setting-liquid-refraction');
  const elDisplayLiquidRefraction = document.getElementById('display-liquid-refraction');
  const elSettingLiquidBlur = document.getElementById('setting-liquid-blur');
  const elDisplayLiquidBlur = document.getElementById('display-liquid-blur');
  const elSettingLiquidBevel = document.getElementById('setting-liquid-bevel');
  const elDisplayLiquidBevel = document.getElementById('display-liquid-bevel');
  const elSettingLiquidMouseLight = document.getElementById('setting-liquid-mouselight');
  const elBtnResetLiquid = document.getElementById('btn-reset-liquid');

  // Shortcut Modal
  const elShortcutModal = document.getElementById('shortcut-modal');
  const elShortcutModalTitle = document.getElementById('shortcut-modal-title');
  const elShortcutForm = document.getElementById('shortcut-form');
  const elShortcutNameInput = document.getElementById('shortcut-name-input');
  const elShortcutUrlInput = document.getElementById('shortcut-url-input');
  const elShortcutFolderSelect = document.getElementById('shortcut-folder-select');
  const elShortcutPreviewCard = document.getElementById('shortcut-preview-card');
  const elPreviewTitle = document.getElementById('preview-title');
  const elBtnCloseShortcut = document.getElementById('btn-close-shortcut-modal');
  const elBtnCancelShortcut = document.getElementById('btn-cancel-shortcut');
  let editingShortcutId = null;

  // Folder Modal
  const elFolderModal = document.getElementById('folder-modal');
  const elFolderForm = document.getElementById('folder-form');
  const elFolderNameInput = document.getElementById('folder-name-input');
  const elBtnCloseFolderModal = document.getElementById('btn-close-folder-modal');
  const elBtnCancelFolder = document.getElementById('btn-cancel-folder');
  let editingFolderId = null;

  // Folder View Modal
  const elFolderViewModal = document.getElementById('folder-view-modal');
  const elFolderViewTitle = document.getElementById('folder-view-title');
  const elFolderItemsGrid = document.getElementById('folder-items-grid');
  const elFolderEmptyNotice = document.getElementById('folder-empty-notice');
  const elBtnCloseFolderView = document.getElementById('btn-close-folder-view');
  const elBtnFolderAddShortcut = document.getElementById('btn-folder-add-shortcut');

  // Context Menu
  const elContextMenu = document.getElementById('context-menu');
  const elCtxOpenNewTab = document.getElementById('ctx-open-new-tab');
  const elCtxOpenNewWindow = document.getElementById('ctx-open-new-window');
  const elCtxSepThumb = document.getElementById('ctx-sep-thumb');
  const elCtxCustomThumbnail = document.getElementById('ctx-custom-thumbnail');
  const elCtxRemoveCustomThumbnail = document.getElementById('ctx-remove-custom-thumbnail');
  const elInputCustomThumb = document.getElementById('input-custom-thumb');
  const elCtxSepFav = document.getElementById('ctx-sep-fav');
  const elCtxAddToFavorites = document.getElementById('ctx-add-to-favorites');
  const elCtxSepEdit = document.getElementById('ctx-sep-edit');
  const elCtxEdit = document.getElementById('ctx-edit');
  const elCtxMoveFolder = document.getElementById('ctx-move-folder');
  const elCtxSepDelete = document.getElementById('ctx-sep-delete');
  const elCtxDelete = document.getElementById('ctx-delete');
  const elSettingIconStyle = document.getElementById('setting-icon-style');

  // Background Context Menu
  const elBgContextMenu = document.getElementById('bg-context-menu');
  const elBgCtxNewShortcut = document.getElementById('bg-ctx-new-shortcut');
  const elBgCtxNewFolder = document.getElementById('bg-ctx-new-folder');
  const elBgCtxSettings = document.getElementById('bg-ctx-settings');
  const elBgCtxToggleClosedTabs = document.getElementById('bg-ctx-toggle-closed-tabs');
  const elBgCheckClosedTabs = document.getElementById('bg-check-closed-tabs');
  const elBgCtxToggleHistory = document.getElementById('bg-ctx-toggle-history');
  const elBgCheckHistory = document.getElementById('bg-check-history');
  const elBgCtxToggleSearch = document.getElementById('bg-ctx-toggle-search');
  const elBgCheckSearch = document.getElementById('bg-check-search');
  const elBtnBuyCoffee = document.getElementById('btn-buy-coffee');

  // Tab Context Menu
  const elTabContextMenu = document.getElementById('tab-context-menu');
  const elTabCtxRename = document.getElementById('tab-ctx-rename');
  const elTabCtxNewSection = document.getElementById('tab-ctx-new-section');
  const elTabCtxDelete = document.getElementById('tab-ctx-delete');
  const elTabCtxSepDelete = document.getElementById('tab-ctx-sep-delete');

  // Language Navigation & Subpanel Elements
  const elSettingsCurrentLangBadge = document.getElementById('settings-current-lang-badge');
  const elFolderModalTitle = document.getElementById('folder-modal-title');

  /**
   * Internationalization (i18n): English (Default) & Spanish
   */
  const I18N = {
    en: {
      // Top Bar & Dropdown
      searchPlaceholder: "Search favorites, tabs and history...",
      clearSearch: "Clear search",
      changeView: "Change view",
      changeSectionView: "Change section view",
      viewIcons: "Icons",
      viewTiles: "Tiles",
      viewThumbnails: "Thumbnails",

      // Main Sections
      favoritesTitle: "Favorites",
      emptyFavoritesTitle: "No favorites yet",
      emptyFavoritesDesc: "Bookmarks you add in Firefox will appear here automatically, or click \"+\" to create one.",
      emptyFavoritesBtn: "Add favorite",
      searchNoMatchesFav: "No favorites match \"{query}\"",
      itemSingular: "item",
      itemPlural: "items",
      closedTabsTitle: "Recently Closed Tabs",
      closedTabsEmpty: "No recently closed tabs",
      historyTitle: "History",
      historyEmpty: "No recent history",
      collapseExpand: "Collapse / Expand",

      // Settings Navigation
      settingsTitle: "Settings",
      backToSettings: "Settings",
      doneBtn: "Done",
      aboutTitle: "About",
      aboutAppName: "Jaime Miguel",
      aboutDesc: "Jaime Miguel, author and notes",
      aboutVersion: "Version 1.2",
      aboutAuthorLabel: "Developed by",
      aboutBugsBadge: "KNOWN BUGS",
      aboutBugsDesc: "Thumbnails do not load well, working on fixing it",
      aboutCoffeeText: "Buy me a coffee!",
      aboutCoffeeNote: "Not yet implemented, if you liked the app please leave a review as thanks :)",
      languageTitle: "Language",
      languageDesc: "Choose interface language",
      langEnglishDesc: "English (United Kingdom / US)",
      langSpanishDesc: "Spanish (Spain / Latin America)",
      langGermanDesc: "German (Germany / Austria / Switzerland)",
      langRussianDesc: "Russian (Russia / CIS)",
      langChineseDesc: "Simplified Chinese (China)",
      designTitle: "Design",
      designDesc: "Wallpaper, appearance and search bar",
      foldersTitle: "Folders",
      foldersDesc: "Background color and appearance",
      bookmarksTitle: "Bookmarks",
      bookmarksDesc: "Size and spacing between items",
      importTitle: "Import",
      importDesc: "Firefox, other browsers and cleanup",

      // Design Panel
      wallpaperAppearance: "Wallpaper & Appearance",
      wallpaperAppearanceDesc: "Visual theme and wallpaper",
      themeSafariDark: "Safari Dark",
      themePureBlack: "Pure Black",
      themeSonomaGlass: "Sonoma Glass",
      themeLight: "Light",
      themeCustom: "Custom",
      chooseWallpaper: "Choose wallpaper image...",
      removeWallpaper: "Remove wallpaper",
      wallpaperGalaxy: "Galaxy",
      wallpaperAurora: "Aurora",
      wallpaperNone: "Solid color",
      wallpaperCustom: "Custom",
      pageTitleHeading: "Page Title",
      pageTitleDesc: "Header title on start page",
      searchBarHeading: "Search Bar",
      searchBarDesc: "Show quick search bar on start page",
      centerSearchHeading: "Center Search Bar",
      centerSearchDesc: "Place search bar in screen center",
      expandScreenHeading: "Expand Screen",
      expandScreenDesc: "Make better use of space by reducing side padding",
      panelLabelsHeading: "Panel Labels",
      panelLabelsDesc: "Size for Favorites, Closed Tabs and History",
      panelLabelSmall: "Small",
      panelLabelNormal: "Normal (Default)",
      panelLabelLarge: "Large",

      // Folders Panel
      folderColorTitle: "Folder Background Color",
      folderColorDesc: "Choose a color for start page folders",
      folderAnimationTitle: "Folder Animation",
      folderAnimationDesc: "Smooth opening and closing transition for folders",
      liquidGlassOption: "Liquid Glass",
      folderPreviewTitle: "Preview",
      folderPreviewDesc: "Folder appearance in grid",

      // Bookmarks Panel
      bookmarkSizeTitle: "Bookmark Size",
      bookmarkSizeDesc: "Dimensions of the icons",
      spacingTitle: "Spacing Between Items",
      spacingDesc: "Horizontal and vertical distance",
      thumbRefreshTitle: "Thumbnail Refresh",
      thumbRefreshDesc: "Update frequency in Favorites",
      thumbRefresh0: "Disabled (Manual only)",
      thumbRefresh5: "Every 5 minutes",
      thumbRefresh10: "Every 10 minutes",
      thumbRefresh15: "Every 15 minutes",
      thumbRefresh30: "Every 30 minutes",
      thumbRefresh60: "Every 1 hour",
      thumbRefresh1440: "Every 24 hours",
      iconStyleTitle: "Icon Style",
      iconStyleDesc: "Size consistency between logos and favicons",
      iconStyleUniform: "Uniform and centered (Recommended)",
      iconStyleFullbleed: "Fill card (Full logos)",
      bookmarkColorTitle: "Bookmark Background Color",
      bookmarkColorDesc: "Choose a color for cards and icons",
      sameColorTitle: "Same color as folders",
      sameColorDesc: "Use folder background color for bookmarks",
      bookmarkPreviewTitle: "Preview",
      bookmarkPreviewDesc: "Bookmark appearance",

      // Sections Panel
      visibleSectionsTitle: "Visible Sections",
      visibleSectionsDesc: "Show or hide on Start Page",
      sectionFavorites: "Favorites",
      sectionClosedTabs: "Closed tabs",
      sectionHistory: "History",

      // Import Panel
      bookmarksBackupTitle: "Bookmarks & Backup",
      bookmarksBackupDesc: "Synchronization and management",
      reimportFirefoxBtn: "Reimport from Firefox",
      importOtherBrowsersBtn: "Import from other browsers...",
      clearPageBtn: "Clear page",

      // Liquid Glass Panel
      liquidGlassSettingsTitle: "Liquid Glass",
      liquidGlassSettingsDesc: "Optical refraction, blur and reflection",
      liquidRefractionLabel: "Refraction",
      liquidRefractionDesc: "Optical lens distortion intensity",
      liquidBlurLabel: "Blur",
      liquidBlurDesc: "Background blur through the glass",
      liquidBevelLabel: "Bevel & Highlights",
      liquidBevelDesc: "Rim specular reflection and relief",
      liquidMouseLightLabel: "Mouse Follow Light",
      liquidMouseLightDesc: "Glass highlights dynamically track cursor",
      liquidResetBtn: "Reset Liquid Glass Settings",

      // Shortcut Modal
      modalAddShortcutTitle: "Add Favorite",
      modalEditShortcutTitle: "Edit Favorite",
      urlLabel: "Web Address / URL",
      urlPlaceholder: "e.g. reddit.com, github.com...",
      nameLabel: "Name",
      namePlaceholder: "Autocompleted from website...",
      folderLabel: "Folder",
      folderRootOption: "(Home / Favorites)",
      previewLabel: "Preview",
      cancelBtn: "Cancel",
      saveBtn: "Save",

      // Folder Modal
      modalAddFolderTitle: "New Folder",
      modalEditFolderTitle: "Edit Folder",
      folderNameLabel: "Folder Name",
      folderNamePlaceholder: "e.g. Work, News, Social...",

      // Folder Drilldown
      folderDefaultTitle: "Folder",
      folderEmptyNotice: "This folder is empty. Drag bookmarks here or click \"+\" to add.",
      addShortcutToFolder: "Add to this folder",

      // Context Menus
      ctxOpenNewTab: "Open in new tab",
      ctxOpenNewWindow: "Open in new window",
      ctxThumbnailTitle: "Thumbnail",
      ctxAddToFavorites: "Add to favorites",
      ctxRemoveFromFavorites: "Remove from favorites",
      ctxRefreshThumbnail: "Update thumbnail",
      ctxCustomThumbnail: "Change thumbnail...",
      ctxRemoveCustomThumbnail: "Remove custom thumbnail",
      ctxEdit: "Edit...",
      ctxMoveFolder: "Move to folder...",
      ctxDelete: "Delete",
      ctxNew: "New",
      ctxNewShortcut: "Bookmark",
      ctxNewFolder: "Folder",
      ctxActions: "Actions",
      ctxRefreshAllThumbs: "Update all thumbnails",
      ctxSettings: "Settings...",
      ctxShowClosedTabs: "Show closed tabs",
      ctxShowHistory: "Show history",
      ctxShowSearch: "Show search bar",

      // Toasts & Confirms
      toastCoffeeThanks: "Thank you so much for your support! ☕",
      toastAddedFavorite: "Added to favorites: {title}",
      toastRemovedFavorite: "Removed from favorites",
      toastAlreadyFavorite: "\"{title}\" is already in favorites",
      toastUpdatingThumb: "Updating thumbnail for \"{title}\"...",
      toastThumbUpdated: "Thumbnail updated for \"{title}\"",
      toastThumbFailed: "Could not update thumbnail",
      toastUpdatingAllThumbs: "Updating all thumbnails...",
      toastAllThumbsUpdated: "All thumbnails updated",
      toastCustomThumbSaved: "Custom thumbnail saved for \"{title}\"",
      toastCustomThumbRemoved: "Custom thumbnail removed",
      confirmReimportFirefox: "Reimport all bookmarks and folders from Firefox?",
      confirmClearPage: "Are you sure you want to clear the page? All speed dial shortcuts will be removed.",
      confirmDeleteItem: "Delete \"{title}\"?",
      addSectionTitle: "Add section",
      newSectionDefaultTitle: "New Section",
      ctxRename: "Rename",
      ctxNewSection: "New section",
      ctxDeleteSection: "Delete section",
      confirmDeleteSection: "Delete section \"{title}\" and all its bookmarks?",
      toastSectionDeleted: "Section deleted"
    },
    es: {
      // Top Bar & Dropdown
      searchPlaceholder: "Buscar en favoritos, pestañas e historial...",
      clearSearch: "Limpiar búsqueda",
      changeView: "Cambiar vista",
      changeSectionView: "Cambiar vista de sección",
      viewIcons: "Iconos",
      viewTiles: "Fichas",
      viewThumbnails: "Thumbnails",

      // Main Sections
      favoritesTitle: "Favoritos",
      emptyFavoritesTitle: "No hay favoritos aún",
      emptyFavoritesDesc: "Los marcadores que añadas en Firefox aparecerán aquí automáticamente, o puedes pulsar \"+\" para crear uno.",
      emptyFavoritesBtn: "Añadir favorito",
      searchNoMatchesFav: "No hay favoritos que coincidan con \"{query}\"",
      itemSingular: "elemento",
      itemPlural: "elementos",
      closedTabsTitle: "Pestañas cerradas recientemente",
      closedTabsEmpty: "No hay pestañas cerradas recientemente",
      historyTitle: "Historial",
      historyEmpty: "No hay historial reciente",
      collapseExpand: "Colapsar / Expandir",

      // Settings Navigation
      settingsTitle: "Ajustes",
      backToSettings: "Ajustes",
      doneBtn: "Hecho",
      aboutTitle: "Acerca de",
      aboutAppName: "Jaime Miguel",
      aboutDesc: "Jaime Miguel, autor y notas",
      aboutVersion: "Versión 1.2",
      aboutAuthorLabel: "Desarrollado por",
      aboutBugsBadge: "BUGS CONOCIDOS",
      aboutBugsDesc: "Los thumbnails no se cargan bien, trabajando en arreglarlo",
      aboutCoffeeText: "¡Cómprame un café!",
      aboutCoffeeNote: "Todavía no implementado, si te gustó la app déjame un review como agradecimiento :)",
      languageTitle: "Idioma",
      languageDesc: "Elige el idioma de la interfaz",
      langEnglishDesc: "Inglés (Reino Unido / EE. UU.)",
      langSpanishDesc: "Español (España / Latinoamérica)",
      langGermanDesc: "Alemán (Alemania / Austria / Suiza)",
      langRussianDesc: "Ruso (Rusia / CEI)",
      langChineseDesc: "Chino simplificado (China)",
      designTitle: "Diseño",
      designDesc: "Fondo, aspecto y barra de búsqueda",
      foldersTitle: "Carpetas",
      foldersDesc: "Color de fondo y aspecto",
      bookmarksTitle: "Marcadores",
      bookmarksDesc: "Tamaño y espacio entre elementos",
      importTitle: "Importar",
      importDesc: "Firefox, otros navegadores y limpieza",

      // Design Panel
      wallpaperAppearance: "Fondo y aspecto",
      wallpaperAppearanceDesc: "Tema visual y fondo de pantalla",
      themeSafariDark: "Safari Dark",
      themePureBlack: "Negro puro",
      themeSonomaGlass: "Sonoma Glass",
      themeLight: "Claro",
      themeCustom: "Color",
      chooseWallpaper: "Elegir imagen de fondo...",
      removeWallpaper: "Quitar fondo",
      wallpaperGalaxy: "Galaxia",
      wallpaperAurora: "Aurora",
      wallpaperNone: "Color sólido",
      wallpaperCustom: "Propia",
      pageTitleHeading: "Título de la página",
      pageTitleDesc: "Nombre visible en el encabezado",
      searchBarHeading: "Barra de búsqueda",
      searchBarDesc: "Mostrar buscador en el Start Page",
      centerSearchHeading: "Centrar barra de búsqueda",
      centerSearchDesc: "Ubica el buscador en el centro de la pantalla",
      expandScreenHeading: "Expandir pantalla",
      expandScreenDesc: "Aprovecha mejor el espacio reduciendo el padding lateral",
      panelLabelsHeading: "Etiquetas de paneles",
      panelLabelsDesc: "Tamaño para Favoritos, Pestañas cerradas e Historial",
      panelLabelSmall: "Pequeña",
      panelLabelNormal: "Normal (Por defecto)",
      panelLabelLarge: "Grande",

      // Folders Panel
      folderColorTitle: "Color de fondo de las carpetas",
      folderColorDesc: "Elige un color para las carpetas del Start Page",
      folderAnimationTitle: "Animación de carpetas",
      folderAnimationDesc: "Efecto fluido al abrir y cerrar carpetas",
      liquidGlassOption: "Liquid Glass",
      folderPreviewTitle: "Vista previa",
      folderPreviewDesc: "Aspecto de las carpetas",

      // Bookmarks Panel
      bookmarkSizeTitle: "Tamaño de elementos",
      bookmarkSizeDesc: "Dimensiones de los iconos",
      spacingTitle: "Espacio entre elementos",
      spacingDesc: "Distancia horizontal y vertical",
      thumbRefreshTitle: "Refresco de miniaturas",
      thumbRefreshDesc: "Frecuencia de actualización en Favoritos",
      thumbRefresh0: "Desactivado (Solo manual)",
      thumbRefresh5: "Cada 5 minutos",
      thumbRefresh10: "Cada 10 minutos",
      thumbRefresh15: "Cada 15 minutos",
      thumbRefresh30: "Cada 30 minutos",
      thumbRefresh60: "Cada 1 hora",
      thumbRefresh1440: "Cada 24 horas",
      iconStyleTitle: "Estilo de los iconos",
      iconStyleDesc: "Consistencia de tamaño entre logos y favicons",
      iconStyleUniform: "Uniforme y centrado (Recomendado)",
      iconStyleFullbleed: "Llenar ficha (Logos completos)",
      bookmarkColorTitle: "Color de fondo de los marcadores",
      bookmarkColorDesc: "Elige un color para las fichas e iconos",
      sameColorTitle: "Mismo color que carpetas",
      sameColorDesc: "Usar el mismo color de las carpetas en los marcadores",
      bookmarkPreviewTitle: "Vista previa",
      bookmarkPreviewDesc: "Aspecto de los marcadores",

      // Sections Panel
      visibleSectionsTitle: "Secciones visibles",
      visibleSectionsDesc: "Mostrar u ocultar en el Start Page",
      sectionFavorites: "Favoritos",
      sectionClosedTabs: "Pestañas cerradas",
      sectionHistory: "Historial",

      // Import Panel
      bookmarksBackupTitle: "Marcadores y copias",
      bookmarksBackupDesc: "Sincronización y administración",
      reimportFirefoxBtn: "Reimportar de Firefox",
      importOtherBrowsersBtn: "Importar de otros navegadores...",
      clearPageBtn: "Limpiar página",

      // Liquid Glass Panel
      liquidGlassSettingsTitle: "Liquid Glass",
      liquidGlassSettingsDesc: "Refracción, desenfoque y brillo",
      liquidRefractionLabel: "Refracción",
      liquidRefractionDesc: "Intensidad de distorsión óptica de la lente",
      liquidBlurLabel: "Desenfoque (Blur)",
      liquidBlurDesc: "Desenfoque del fondo a través del cristal",
      liquidBevelLabel: "Bisel y Brillo",
      liquidBevelDesc: "Reflejo especular del borde y relieve",
      liquidMouseLightLabel: "Luz dinámica del cursor",
      liquidMouseLightDesc: "El reflejo sigue la posición del puntero",
      liquidResetBtn: "Restablecer ajustes Liquid Glass",

      // Shortcut Modal
      modalAddShortcutTitle: "Añadir favorito",
      modalEditShortcutTitle: "Editar favorito",
      urlLabel: "Dirección Web / URL",
      urlPlaceholder: "ej. meneame.net, reddit.com...",
      nameLabel: "Nombre",
      namePlaceholder: "Se autocompleta con la web...",
      folderLabel: "Carpeta",
      folderRootOption: "(Página principal / Favoritos)",
      previewLabel: "Vista previa",
      cancelBtn: "Cancelar",
      saveBtn: "Guardar",

      // Folder Modal
      modalAddFolderTitle: "Nueva carpeta",
      modalEditFolderTitle: "Editar carpeta",
      folderNameLabel: "Nombre de la carpeta",
      folderNamePlaceholder: "Ej. Trabajo, Noticias, Ocio...",

      // Folder Drilldown
      folderDefaultTitle: "Carpeta",
      folderEmptyNotice: "Esta carpeta está vacía. Arrastra marcadores aquí o pulsa \"+\" para añadir.",
      addShortcutToFolder: "Añadir a esta carpeta",

      // Context Menus
      ctxOpenNewTab: "Abrir en pestaña nueva",
      ctxOpenNewWindow: "Abrir en ventana nueva",
      ctxThumbnailTitle: "Thumbnail",
      ctxAddToFavorites: "Añadir a favoritos",
      ctxRemoveFromFavorites: "Eliminar de favoritos",
      ctxRefreshThumbnail: "Actualizar captura",
      ctxCustomThumbnail: "Cambiar miniatura...",
      ctxRemoveCustomThumbnail: "Eliminar miniatura personalizada",
      ctxEdit: "Editar...",
      ctxMoveFolder: "Mover a carpeta...",
      ctxDelete: "Eliminar",
      ctxNew: "Nuevo",
      ctxNewShortcut: "Marcador",
      ctxNewFolder: "Carpeta",
      ctxActions: "Acciones",
      ctxRefreshAllThumbs: "Actualizar todos los thumbnails",
      ctxSettings: "Ajustes...",
      ctxShowClosedTabs: "Mostrar pestañas cerradas",
      ctxShowHistory: "Mostrar historial",
      ctxShowSearch: "Mostrar barra de búsqueda",

      // Toasts & Confirms
      toastCoffeeThanks: "¡Muchas gracias por tu apoyo! ☕",
      toastAddedFavorite: "Añadido a favoritos: {title}",
      toastRemovedFavorite: "Eliminado de favoritos",
      toastAlreadyFavorite: "\"{title}\" ya está en favoritos",
      toastUpdatingThumb: "Actualizando captura de \"{title}\"...",
      toastThumbUpdated: "Captura actualizada para \"{title}\"",
      toastThumbFailed: "No se pudo actualizar la miniatura",
      toastUpdatingAllThumbs: "Actualizando todas las capturas...",
      toastAllThumbsUpdated: "Todas las capturas se han actualizado",
      toastCustomThumbSaved: "Miniatura personalizada guardada para \"{title}\"",
      toastCustomThumbRemoved: "Miniatura personalizada eliminada",
      confirmReimportFirefox: "¿Reimportar todos los marcadores y carpetas de Firefox?",
      confirmClearPage: "¿Estás seguro de que quieres limpiar la página? Se eliminarán todos los accesos directos del Speed Dial.",
      confirmDeleteItem: "¿Eliminar \"{title}\"?",
      addSectionTitle: "Añadir sección",
      newSectionDefaultTitle: "Nueva sección",
      ctxRename: "Renombrar",
      ctxNewSection: "Nueva sección",
      ctxDeleteSection: "Eliminar sección",
      confirmDeleteSection: "¿Eliminar la sección \"{title}\" y todos sus marcadores?",
      toastSectionDeleted: "Sección eliminada"
    },
    de: {
      // Top Bar & Dropdown
      searchPlaceholder: "Lesezeichen, Tabs und Verlauf durchsuchen...",
      clearSearch: "Suche löschen",
      changeView: "Ansicht ändern",
      changeSectionView: "Bereichsansicht ändern",
      viewIcons: "Symbole",
      viewTiles: "Kacheln",
      viewThumbnails: "Thumbnails",

      // Main Sections
      favoritesTitle: "Favoriten",
      emptyFavoritesTitle: "Noch keine Favoriten",
      emptyFavoritesDesc: "Lesezeichen, die du in Firefox hinzufügst, erscheinen hier automatisch, oder klicke auf „+“, um eines zu erstellen.",
      emptyFavoritesBtn: "Favorit hinzufügen",
      searchNoMatchesFav: "Keine Favoriten entsprechen \"{query}\"",
      itemSingular: "Element",
      itemPlural: "Elemente",
      closedTabsTitle: "Kürzlich geschlossene Tabs",
      closedTabsEmpty: "Keine kürzlich geschlossenen Tabs",
      historyTitle: "Verlauf",
      historyEmpty: "Kein aktueller Verlauf",
      collapseExpand: "Einklappen / Ausklappen",

      // Settings Navigation
      settingsTitle: "Einstellungen",
      backToSettings: "Einstellungen",
      doneBtn: "Fertig",
      aboutTitle: "Über",
      aboutAppName: "Jaime Miguel",
      aboutDesc: "Jaime Miguel, Entwickler und Notizen",
      aboutVersion: "Version 1.2",
      aboutAuthorLabel: "Entwickelt von",
      aboutBugsBadge: "BEKANNTE FEHLER",
      aboutBugsDesc: "Thumbnails laden nicht richtig, Korrektur in Arbeit",
      aboutCoffeeText: "Kauf mir einen Kaffee!",
      aboutCoffeeNote: "Noch nicht implementiert. Wenn dir die App gefallen hat, hinterlasse gerne eine Bewertung als Dankeschön :)",
      languageTitle: "Sprache",
      languageDesc: "Wähle die Sprache der Benutzeroberfläche",
      langEnglishDesc: "Englisch (Großbritannien / USA)",
      langSpanishDesc: "Spanisch (Spanien / Lateinamerika)",
      langGermanDesc: "Deutsch (Deutschland / Österreich / Schweiz)",
      langRussianDesc: "Russisch (Russland / GUS)",
      langChineseDesc: "Vereinfachtes Chinesisch (China)",
      designTitle: "Design",
      designDesc: "Hintergrund, Aussehen und Suchleiste",
      foldersTitle: "Ordner",
      foldersDesc: "Hintergrundfarbe und Erscheinungsbild",
      bookmarksTitle: "Lesezeichen",
      bookmarksDesc: "Größe und Abstand zwischen Elementen",
      importTitle: "Importieren",
      importDesc: "Firefox, andere Browser und Bereinigung",

      // Design Panel
      wallpaperAppearance: "Hintergrund & Aussehen",
      wallpaperAppearanceDesc: "Visuelles Design und Hintergrundbild",
      themeSafariDark: "Safari Dunkel",
      themePureBlack: "Tiefschwarz",
      themeSonomaGlass: "Sonoma Glas",
      themeLight: "Hell",
      themeCustom: "Farbe",
      chooseWallpaper: "Hintergrundbild auswählen...",
      removeWallpaper: "Hintergrund entfernen",
      wallpaperGalaxy: "Galaxie",
      wallpaperAurora: "Aurora",
      wallpaperNone: "Einfarbig",
      wallpaperCustom: "Eigenes",
      pageTitleHeading: "Seitentitel",
      pageTitleDesc: "Kopftitel auf der Startseite",
      searchBarHeading: "Suchleiste",
      searchBarDesc: "Schnellsuche auf der Startseite anzeigen",
      centerSearchHeading: "Suchleiste zentrieren",
      centerSearchDesc: "Suchleiste in der Bildschirmmitte platzieren",
      expandScreenHeading: "Bildschirm erweitern",
      expandScreenDesc: "Platz optimal nutzen durch reduzierten Seitenabstand",
      panelLabelsHeading: "Panel-Beschriftungen",
      panelLabelsDesc: "Größe für Favoriten, geschlossene Tabs und Chronik",
      panelLabelSmall: "Klein",
      panelLabelNormal: "Normal (Standard)",
      panelLabelLarge: "Groß",

      // Folders Panel
      folderColorTitle: "Ordner-Hintergrundfarbe",
      folderColorDesc: "Wähle eine Farbe für Ordner auf der Startseite",
      folderAnimationTitle: "Ordneranimation",
      folderAnimationDesc: "Fließender Übergang beim Öffnen und Schließen von Ordnern",
      liquidGlassOption: "Liquid Glass",
      folderPreviewTitle: "Vorschau",
      folderPreviewDesc: "Erscheinungsbild der Ordner im Raster",

      // Bookmarks Panel
      bookmarkSizeTitle: "Lesezeichengröße",
      bookmarkSizeDesc: "Abmessungen der Symbole",
      spacingTitle: "Abstand zwischen Elementen",
      spacingDesc: "Horizontaler und vertikaler Abstand",
      thumbRefreshTitle: "Thumbnail-Aktualisierung",
      thumbRefreshDesc: "Häufigkeit der Aktualisierung in Favoriten",
      thumbRefresh0: "Deaktiviert (Nur manuell)",
      thumbRefresh5: "Alle 5 Minuten",
      thumbRefresh10: "Alle 10 Minuten",
      thumbRefresh15: "Alle 15 Minuten",
      thumbRefresh30: "Alle 30 Minuten",
      thumbRefresh60: "Jede Stunde",
      thumbRefresh1440: "Alle 24 Stunden",
      iconStyleTitle: "Symbolstil",
      iconStyleDesc: "Größenkonsistenz zwischen Logos und Favicons",
      iconStyleUniform: "Einheitlich und zentriert (Empfohlen)",
      iconStyleFullbleed: "Karte ausfüllen (Vollständige Logos)",
      bookmarkColorTitle: "Lesezeichen-Hintergrundfarbe",
      bookmarkColorDesc: "Wähle eine Farbe für Karten und Symbole",
      sameColorTitle: "Gleiche Farbe wie Ordner",
      sameColorDesc: "Ordner-Hintergrundfarbe für Lesezeichen verwenden",
      bookmarkPreviewTitle: "Vorschau",
      bookmarkPreviewDesc: "Erscheinungsbild des Lesezeichens",

      // Sections Panel
      visibleSectionsTitle: "Sichtbare Abschnitte",
      visibleSectionsDesc: "Auf Startseite ein- oder ausblenden",
      sectionFavorites: "Favoriten",
      sectionClosedTabs: "Geschlossene Tabs",
      sectionHistory: "Verlauf",

      // Import Panel
      bookmarksBackupTitle: "Lesezeichen & Sicherung",
      bookmarksBackupDesc: "Synchronisierung und Verwaltung",
      reimportFirefoxBtn: "Aus Firefox erneut importieren",
      importOtherBrowsersBtn: "Aus anderen Browsern importieren...",
      clearPageBtn: "Seite leeren",

      // Shortcut Modal
      modalAddShortcutTitle: "Favorit hinzufügen",
      modalEditShortcutTitle: "Favorit bearbeiten",
      urlLabel: "Webadresse / URL",
      urlPlaceholder: "z. B. spiegel.de, github.com...",
      nameLabel: "Name",
      namePlaceholder: "Automatisch von Website ausgefüllt...",
      folderLabel: "Ordner",
      folderRootOption: "(Startseite / Favoriten)",
      previewLabel: "Vorschau",
      cancelBtn: "Abbrechen",
      saveBtn: "Speichern",

      // Folder Modal
      modalAddFolderTitle: "Neuer Ordner",
      modalEditFolderTitle: "Ordner bearbeiten",
      folderNameLabel: "Ordnername",
      folderNamePlaceholder: "z. B. Arbeit, Nachrichten, Soziales...",

      // Folder Drilldown
      folderDefaultTitle: "Ordner",
      folderEmptyNotice: "Dieser Ordner ist leer. Ziehe Lesezeichen hierher oder klicke auf „+“.",
      addShortcutToFolder: "Zu diesem Ordner hinzufügen",

      // Context Menus
      ctxOpenNewTab: "In neuem Tab öffnen",
      ctxOpenNewWindow: "In neuem Fenster öffnen",
      ctxThumbnailTitle: "Thumbnail",
      ctxAddToFavorites: "Zu Favoriten hinzufügen",
      ctxRemoveFromFavorites: "Aus Favoriten entfernen",
      ctxRefreshThumbnail: "Thumbnail aktualisieren",
      ctxCustomThumbnail: "Thumbnail ändern...",
      ctxRemoveCustomThumbnail: "Benutzerdefiniertes Thumbnail entfernen",
      ctxEdit: "Bearbeiten...",
      ctxMoveFolder: "In Ordner verschieben...",
      ctxDelete: "Löschen",
      ctxNew: "Neu",
      ctxNewShortcut: "Lesezeichen",
      ctxNewFolder: "Ordner",
      ctxActions: "Aktionen",
      ctxRefreshAllThumbs: "Alle Thumbnails aktualisieren",
      ctxSettings: "Einstellungen...",
      ctxShowClosedTabs: "Geschlossene Tabs anzeigen",
      ctxShowHistory: "Verlauf anzeigen",
      ctxShowSearch: "Suchleiste anzeigen",

      // Toasts & Confirms
      toastCoffeeThanks: "Vielen Dank für deine Unterstützung! ☕",
      toastAddedFavorite: "Zu Favoriten hinzugefügt: {title}",
      toastRemovedFavorite: "Aus Favoriten entfernt",
      toastAlreadyFavorite: "„{title}“ ist bereits in Favoriten",
      toastUpdatingThumb: "Thumbnail für „{title}“ wird aktualisiert...",
      toastThumbUpdated: "Thumbnail für „{title}“ aktualisiert",
      toastThumbFailed: "Thumbnail konnte nicht aktualisiert werden",
      toastUpdatingAllThumbs: "Alle Thumbnails werden aktualisiert...",
      toastAllThumbsUpdated: "Alle Thumbnails aktualisiert",
      toastCustomThumbSaved: "Benutzerdefiniertes Thumbnail gespeichert für „{title}“",
      toastCustomThumbRemoved: "Benutzerdefiniertes Thumbnail entfernt",
      confirmReimportFirefox: "Alle Lesezeichen und Ordner aus Firefox erneut importieren?",
      confirmClearPage: "Möchtest du die Seite wirklich leeren? Alle Schnellwahleinträge werden gelöscht.",
      confirmDeleteItem: "„{title}“ löschen?",
      addSectionTitle: "Bereich hinzufügen",
      newSectionDefaultTitle: "Neuer Bereich",
      ctxRename: "Umbenennen",
      ctxNewSection: "Neuer Bereich",
      ctxDeleteSection: "Bereich löschen",
      confirmDeleteSection: "Bereich „{title}“ und alle Lesezeichen darin löschen?",
      toastSectionDeleted: "Bereich gelöscht"
    },
    ru: {
      // Top Bar & Dropdown
      searchPlaceholder: "Поиск в закладках, вкладках и истории...",
      clearSearch: "Очистить поиск",
      changeView: "Сменить вид",
      changeSectionView: "Изменить вид раздела",
      viewIcons: "Значки",
      viewTiles: "Плитки",
      viewThumbnails: "Миниатюры",

      // Main Sections
      favoritesTitle: "Закладки",
      emptyFavoritesTitle: "Пока нет закладок",
      emptyFavoritesDesc: "Закладки, добавленные в Firefox, появятся здесь автоматически, или нажмите «+», чтобы создать закладку.",
      emptyFavoritesBtn: "Добавить закладку",
      searchNoMatchesFav: "Нет закладок, соответствующих «{query}»",
      itemSingular: "элемент",
      itemPlural: "элементов",
      closedTabsTitle: "Недавно закрытые вкладки",
      closedTabsEmpty: "Нет недавно закрытых вкладок",
      historyTitle: "История",
      historyEmpty: "История пуста",
      collapseExpand: "Свернуть / Развернуть",

      // Settings Navigation
      settingsTitle: "Настройки",
      backToSettings: "Настройки",
      doneBtn: "Готово",
      aboutTitle: "О программе",
      aboutAppName: "Jaime Miguel",
      aboutDesc: "Jaime Miguel, автор и примечания",
      aboutVersion: "Версия 1.2",
      aboutAuthorLabel: "Разработчик:",
      aboutBugsBadge: "ИЗВЕСТНЫЕ ОШИБКИ",
      aboutBugsDesc: "Миниатюры загружаются некорректно, работаем над исправлением",
      aboutCoffeeText: "Купи мне кофе!",
      aboutCoffeeNote: "Пока не реализовано. Если вам понравилось приложение, оставьте отзыв в знак благодарности :)",
      languageTitle: "Язык",
      languageDesc: "Выберите язык интерфейса",
      langEnglishDesc: "Английский (Великобритания / США)",
      langSpanishDesc: "Испанский (Испания / Латинская Америка)",
      langGermanDesc: "Немецкий (Германия / Австрия / Швейцария)",
      langRussianDesc: "Русский (Россия / СНГ)",
      langChineseDesc: "Упрощенный китайский (Китай)",
      designTitle: "Оформление",
      designDesc: "Фон, внешний вид и строка поиска",
      foldersTitle: "Папки",
      foldersDesc: "Цвет фона и внешний вид",
      bookmarksTitle: "Закладки",
      bookmarksDesc: "Размер и расстояние между элементами",
      importTitle: "Импорт",
      importDesc: "Firefox, другие браузеры и очистка",

      // Design Panel
      wallpaperAppearance: "Фон и оформление",
      wallpaperAppearanceDesc: "Визуальная тема и обои",
      themeSafariDark: "Safari Темная",
      themePureBlack: "Глубокий черный",
      themeSonomaGlass: "Sonoma Стекло",
      themeLight: "Светлая",
      themeCustom: "Цвет",
      chooseWallpaper: "Выбрать фоновое изображение...",
      removeWallpaper: "Удалить обои",
      wallpaperGalaxy: "Галактика",
      wallpaperAurora: "Аврора",
      wallpaperNone: "Сплошной цвет",
      wallpaperCustom: "Свои обои",
      pageTitleHeading: "Заголовок страницы",
      pageTitleDesc: "Название в верхней части начальной страницы",
      searchBarHeading: "Строка поиска",
      searchBarDesc: "Показывать строку быстрого поиска",
      centerSearchHeading: "По центру",
      centerSearchDesc: "Расположить строку поиска в центре экрана",
      expandScreenHeading: "Расширить экран",
      expandScreenDesc: "Использовать больше места, уменьшив боковые отступы",
      panelLabelsHeading: "Подписи панелей",
      panelLabelsDesc: "Размер для Закладок, закрытых вкладок и истории",
      panelLabelSmall: "Маленький",
      panelLabelNormal: "Обычный (По умолчанию)",
      panelLabelLarge: "Большой",

      // Folders Panel
      folderColorTitle: "Цвет фона папок",
      folderColorDesc: "Выберите цвет для папок на начальной странице",
      folderAnimationTitle: "Анимация папок",
      folderAnimationDesc: "Плавный эффект открытия и закрытия папок",
      liquidGlassOption: "Liquid Glass",
      folderPreviewTitle: "Предпросмотр",
      folderPreviewDesc: "Отображение папки в сетке",

      // Bookmarks Panel
      bookmarkSizeTitle: "Размер значков",
      bookmarkSizeDesc: "Габариты значков и карточек",
      spacingTitle: "Расстояние между элементами",
      spacingDesc: "Горизонтальный и вертикальный отступ",
      thumbRefreshTitle: "Обновление миниатюр",
      thumbRefreshDesc: "Периодичность обновления в закладках",
      thumbRefresh0: "Отключено (Только вручную)",
      thumbRefresh5: "Каждые 5 минут",
      thumbRefresh10: "Каждые 10 минут",
      thumbRefresh15: "Каждые 15 минут",
      thumbRefresh30: "Каждые 30 минут",
      thumbRefresh60: "Каждый 1 час",
      thumbRefresh1440: "Каждые 24 часа",
      iconStyleTitle: "Стиль значков",
      iconStyleDesc: "Единообразие размера логотипов и favicon",
      iconStyleUniform: "Единый и по центру (Рекомендуется)",
      iconStyleFullbleed: "Во всю карточку (Полные логотипы)",
      bookmarkColorTitle: "Цвет фона закладок",
      bookmarkColorDesc: "Выберите цвет для карточек и значков",
      sameColorTitle: "Такой же цвет, как у папок",
      sameColorDesc: "Использовать цвет фона папок для закладок",
      bookmarkPreviewTitle: "Предпросмотр",
      bookmarkPreviewDesc: "Внешний вид закладки",

      // Sections Panel
      visibleSectionsTitle: "Видимые разделы",
      visibleSectionsDesc: "Показывать или скрывать на начальной странице",
      sectionFavorites: "Закладки",
      sectionClosedTabs: "Закрытые вкладки",
      sectionHistory: "История",

      // Import Panel
      bookmarksBackupTitle: "Закладки и резервное копирование",
      bookmarksBackupDesc: "Синхронизация и управление",
      reimportFirefoxBtn: "Повторный импорт из Firefox",
      importOtherBrowsersBtn: "Импорт из других браузеров...",
      clearPageBtn: "Очистить страницу",

      // Shortcut Modal
      modalAddShortcutTitle: "Добавить закладку",
      modalEditShortcutTitle: "Редактировать закладку",
      urlLabel: "Веб-адрес / URL",
      urlPlaceholder: "например, yandex.ru, github.com...",
      nameLabel: "Название",
      namePlaceholder: "Заполняется автоматически...",
      folderLabel: "Папка",
      folderRootOption: "(Главная / Закладки)",
      previewLabel: "Предпросмотр",
      cancelBtn: "Отмена",
      saveBtn: "Сохранить",

      // Folder Modal
      modalAddFolderTitle: "Новая папка",
      modalEditFolderTitle: "Редактировать папку",
      folderNameLabel: "Название папки",
      folderNamePlaceholder: "например, Работа, Новости, Общение...",

      // Folder Drilldown
      folderDefaultTitle: "Папка",
      folderEmptyNotice: "Эта папка пуста. Перетащите сюда закладки или нажмите «+».",
      addShortcutToFolder: "Добавить в эту папку",

      // Context Menus
      ctxOpenNewTab: "Открыть в новой вкладке",
      ctxOpenNewWindow: "Открыть в новом окне",
      ctxThumbnailTitle: "Thumbnail",
      ctxAddToFavorites: "Добавить в закладки",
      ctxRemoveFromFavorites: "Удалить из закладок",
      ctxRefreshThumbnail: "Обновить миниатюру",
      ctxCustomThumbnail: "Изменить миниатюру...",
      ctxRemoveCustomThumbnail: "Удалить свою миниатюру",
      ctxEdit: "Редактировать...",
      ctxMoveFolder: "Переместить в папку...",
      ctxDelete: "Удалить",
      ctxNew: "Создать",
      ctxNewShortcut: "Закладку",
      ctxNewFolder: "Папку",
      ctxActions: "Действия",
      ctxRefreshAllThumbs: "Обновить все миниатюры",
      ctxSettings: "Настройки...",
      ctxShowClosedTabs: "Показывать закрытые вкладки",
      ctxShowHistory: "Показывать историю",
      ctxShowSearch: "Показывать строку поиска",

      // Toasts & Confirms
      toastCoffeeThanks: "Большое спасибо за вашу поддержку! ☕",
      toastAddedFavorite: "Добавлено в закладки: {title}",
      toastRemovedFavorite: "Удалено из закладок",
      toastAlreadyFavorite: "«{title}» уже в закладках",
      toastUpdatingThumb: "Обновление миниатюры для «{title}»...",
      toastThumbUpdated: "Миниатюра обновлена для «{title}»",
      toastThumbFailed: "Не удалось обновить миниатюру",
      toastUpdatingAllThumbs: "Обновление всех миниатюр...",
      toastAllThumbsUpdated: "Все миниатюры обновлены",
      toastCustomThumbSaved: "Своя миниатюра сохранена для «{title}»",
      toastCustomThumbRemoved: "Своя миниатюра удалена",
      confirmReimportFirefox: "Повторно импортировать все закладки и папки из Firefox?",
      confirmClearPage: "Вы уверены, что хотите очистить страницу? Все значки будут удалены.",
      confirmDeleteItem: "Удалить «{title}»?",
      addSectionTitle: "Добавить раздел",
      newSectionDefaultTitle: "Новый раздел",
      ctxRename: "Переименовать",
      ctxNewSection: "Новый раздел",
      ctxDeleteSection: "Удалить раздел",
      confirmDeleteSection: "Удалить раздел «{title}» и все его закладки?",
      toastSectionDeleted: "Раздел удален"
    },
    zh: {
      // Top Bar & Dropdown
      searchPlaceholder: "搜索书签、标签页和历史记录...",
      clearSearch: "清除搜索",
      changeView: "切换视图",
      changeSectionView: "更改分组视图",
      viewIcons: "图标",
      viewTiles: "卡片",
      viewThumbnails: "缩略图",

      // Main Sections
      favoritesTitle: "收藏",
      emptyFavoritesTitle: "暂无收藏",
      emptyFavoritesDesc: "在 Firefox 中添加的书签将自动显示在这里，或点击“+”创建新书签。",
      emptyFavoritesBtn: "添加收藏",
      searchNoMatchesFav: "未找到与 \"{query}\" 匹配的收藏",
      itemSingular: "个项目",
      itemPlural: "个项目",
      closedTabsTitle: "最近关闭的标签页",
      closedTabsEmpty: "暂无最近关闭的标签页",
      historyTitle: "历史记录",
      historyEmpty: "暂无最近历史记录",
      collapseExpand: "折叠 / 展开",

      // Settings Navigation
      settingsTitle: "设置",
      backToSettings: "设置",
      doneBtn: "完成",
      aboutTitle: "关于",
      aboutAppName: "Jaime Miguel",
      aboutDesc: "Jaime Miguel、作者及说明",
      aboutVersion: "版本 1.2",
      aboutAuthorLabel: "开发者",
      aboutBugsBadge: "已知问题",
      aboutBugsDesc: "缩略图可能无法正常加载，正在全力修复中",
      aboutCoffeeText: "请我喝杯咖啡！",
      aboutCoffeeNote: "尚未实现，如果您喜欢这款应用，欢迎留下好评作为感谢 :)",
      languageTitle: "语言",
      languageDesc: "选择界面语言",
      langEnglishDesc: "英语（英国 / 美国）",
      langSpanishDesc: "西班牙语（西班牙 / 拉美）",
      langGermanDesc: "德语（德国 / 奥地利 / 瑞士）",
      langRussianDesc: "俄语（俄罗斯 / 独联体）",
      langChineseDesc: "简体中文（中国）",
      designTitle: "外观设计",
      designDesc: "壁纸、主题与搜索栏",
      foldersTitle: "文件夹",
      foldersDesc: "背景颜色与外观样式",
      bookmarksTitle: "书签设置",
      bookmarksDesc: "图标大小与间距",
      importTitle: "导入与备份",
      importDesc: "Firefox、其他浏览器与清理",

      // Design Panel
      wallpaperAppearance: "壁纸与外观",
      wallpaperAppearanceDesc: "视觉主题与壁纸",
      themeSafariDark: "Safari 深色",
      themePureBlack: "纯黑",
      themeSonomaGlass: "Sonoma 毛玻璃",
      themeLight: "浅色",
      themeCustom: "自定义",
      chooseWallpaper: "选择壁纸图片...",
      removeWallpaper: "移除壁纸",
      wallpaperGalaxy: "星系",
      wallpaperAurora: "极光",
      wallpaperNone: "纯色",
      wallpaperCustom: "自定义",
      pageTitleHeading: "页面标题",
      pageTitleDesc: "起始页顶部显示的标题",
      searchBarHeading: "搜索栏",
      searchBarDesc: "在起始页显示快速搜索栏",
      centerSearchHeading: "居中搜索栏",
      centerSearchDesc: "将搜索栏置于屏幕正中央",
      expandScreenHeading: "扩展屏幕",
      expandScreenDesc: "通过减少两侧内边距更充分地利用空间",
      panelLabelsHeading: "面板标签",
      panelLabelsDesc: "收藏夹、已关闭标签页和历史记录的字体大小",
      panelLabelSmall: "小",
      panelLabelNormal: "正常 (默认)",
      panelLabelLarge: "大",

      // Folders Panel
      folderColorTitle: "文件夹背景颜色",
      folderColorDesc: "为起始页文件夹选择背景颜色",
      folderAnimationTitle: "文件夹动画",
      folderAnimationDesc: "打开和关闭文件夹时的平滑过渡效果",
      liquidGlassOption: "液态玻璃 (Liquid Glass)",
      folderPreviewTitle: "预览",
      folderPreviewDesc: "网格中的文件夹外观",

      // Bookmarks Panel
      bookmarkSizeTitle: "书签大小",
      bookmarkSizeDesc: "图标尺寸大小",
      spacingTitle: "项目间距",
      spacingDesc: "水平与垂直间距",
      thumbRefreshTitle: "缩略图刷新频率",
      thumbRefreshDesc: "收藏夹缩略图自动更新频率",
      thumbRefresh0: "已禁用（仅手动更新）",
      thumbRefresh5: "每 5 分钟",
      thumbRefresh10: "每 10 分钟",
      thumbRefresh15: "每 15 分钟",
      thumbRefresh30: "每 30 分钟",
      thumbRefresh60: "每 1 小时",
      thumbRefresh1440: "每 24 小时",
      iconStyleTitle: "图标样式",
      iconStyleDesc: "Logo 与 Favicon 的尺寸显示一致性",
      iconStyleUniform: "统一且居中（推荐）",
      iconStyleFullbleed: "填满卡片（完整 Logo）",
      bookmarkColorTitle: "书签背景颜色",
      bookmarkColorDesc: "为卡片和图标选择背景颜色",
      sameColorTitle: "与文件夹同色",
      sameColorDesc: "书签使用与文件夹相同的背景颜色",
      bookmarkPreviewTitle: "预览",
      bookmarkPreviewDesc: "书签外观",

      // Sections Panel
      visibleSectionsTitle: "显示区块",
      visibleSectionsDesc: "在起始页显示或隐藏",
      sectionFavorites: "收藏",
      sectionClosedTabs: "最近关闭的标签页",
      sectionHistory: "历史记录",

      // Import Panel
      bookmarksBackupTitle: "书签与备份",
      bookmarksBackupDesc: "同步与管理",
      reimportFirefoxBtn: "重新从 Firefox 导入",
      importOtherBrowsersBtn: "从其他浏览器导入...",
      clearPageBtn: "清空页面",

      // Shortcut Modal
      modalAddShortcutTitle: "添加收藏",
      modalEditShortcutTitle: "编辑收藏",
      urlLabel: "网址 / URL",
      urlPlaceholder: "例如 bilibili.com, github.com...",
      nameLabel: "名称",
      namePlaceholder: "将从网站自动填充...",
      folderLabel: "文件夹",
      folderRootOption: "(主页 / 收藏)",
      previewLabel: "预览",
      cancelBtn: "取消",
      saveBtn: "保存",

      // Folder Modal
      modalAddFolderTitle: "新建文件夹",
      modalEditFolderTitle: "编辑文件夹",
      folderNameLabel: "文件夹名称",
      folderNamePlaceholder: "例如：工作、新闻、社交...",

      // Folder Drilldown
      folderDefaultTitle: "文件夹",
      folderEmptyNotice: "此文件夹为空。将书签拖动到此处或点击“+”添加。",
      addShortcutToFolder: "添加到此文件夹",

      // Context Menus
      ctxOpenNewTab: "在新标签页中打开",
      ctxOpenNewWindow: "在新窗口中打开",
      ctxThumbnailTitle: "Thumbnail",
      ctxAddToFavorites: "添加到收藏",
      ctxRemoveFromFavorites: "从收藏中移除",
      ctxRefreshThumbnail: "更新缩略图",
      ctxCustomThumbnail: "更换缩略图...",
      ctxRemoveCustomThumbnail: "删除自定义缩略图",
      ctxEdit: "编辑...",
      ctxMoveFolder: "移动到文件夹...",
      ctxDelete: "删除",
      ctxNew: "新建",
      ctxNewShortcut: "书签",
      ctxNewFolder: "文件夹",
      ctxActions: "操作",
      ctxRefreshAllThumbs: "更新所有缩略图",
      ctxSettings: "设置...",
      ctxShowClosedTabs: "显示最近关闭的标签页",
      ctxShowHistory: "显示历史记录",
      ctxShowSearch: "显示搜索栏",

      // Toasts & Confirms
      toastCoffeeThanks: "非常感谢您的支持！☕",
      toastAddedFavorite: "已添加到收藏：{title}",
      toastRemovedFavorite: "已从收藏中移除",
      toastAlreadyFavorite: "“{title}”已在收藏夹中",
      toastUpdatingThumb: "正在更新“{title}”的缩略图...",
      toastThumbUpdated: "“{title}”的缩略图已更新",
      toastThumbFailed: "无法更新缩略图",
      toastUpdatingAllThumbs: "正在更新所有缩略图...",
      toastAllThumbsUpdated: "所有缩略图更新完成",
      toastCustomThumbSaved: "已为“{title}”保存自定义缩略图",
      toastCustomThumbRemoved: "已删除自定义缩略图",
      confirmReimportFirefox: "确定要重新从 Firefox 导入所有书签和文件夹吗？",
      confirmClearPage: "确定要清空页面吗？所有快捷方式都将被移除。",
      confirmDeleteItem: "确定要删除“{title}”吗？",
      addSectionTitle: "添加分区",
      newSectionDefaultTitle: "新分区",
      ctxRename: "重命名",
      ctxNewSection: "新建分区",
      ctxDeleteSection: "删除分区",
      confirmDeleteSection: "确定删除分区“{title}”及其所有书签吗？",
      toastSectionDeleted: "分区已删除"
    }
  };

  function getDefaultLanguage() {
    const nav = (typeof navigator !== 'undefined' && (navigator.language || (navigator.languages && navigator.languages[0])) || '').toLowerCase();
    if (nav.startsWith('es')) return 'es';
    if (nav.startsWith('de')) return 'de';
    if (nav.startsWith('ru')) return 'ru';
    if (nav.startsWith('zh')) return 'zh';
    return 'en';
  }

  function getLanguage() {
    return (state && state.settings && state.settings.language) || getDefaultLanguage();
  }

  function t(key, params = {}) {
    const lang = getLanguage();
    const dict = I18N[lang] || I18N.en;
    let val = dict[key] || I18N.en[key] || key;
    for (const [k, v] of Object.entries(params)) {
      val = val.replace(new RegExp(`\\{${k}\\}`, 'g'), v);
    }
    return val;
  }

  function applyTranslations(lang = getLanguage()) {
    document.documentElement.lang = lang;

    // Update Language Badge in Settings main menu
    if (elSettingsCurrentLangBadge) {
      const langBadges = {
        en: '🇬🇧 English',
        es: '🇪🇸 Español',
        de: '🇩🇪 Deutsch',
        ru: '🇷🇺 Русский',
        zh: '🇨🇳 简体中文'
      };
      elSettingsCurrentLangBadge.textContent = langBadges[lang] || langBadges.en;
    }

    // Update Language Options checkmarks and active state in Language Subpanel
    document.querySelectorAll('.settings-language-option').forEach(opt => {
      const isSelected = (opt.dataset.lang === lang);
      opt.classList.toggle('is-selected', isSelected);
      const check = opt.querySelector('.settings-language-option-check');
      if (check) {
        check.style.display = isSelected ? 'inline-flex' : 'none';
      }
    });

    // Translate all static elements with data-i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.dataset.i18n;
      if (key && (I18N[lang]?.[key] || I18N.en?.[key])) {
        el.textContent = t(key);
      }
    });

    // Translate all elements with data-i18n-placeholder
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.dataset.i18nPlaceholder;
      if (key && (I18N[lang]?.[key] || I18N.en?.[key])) {
        el.placeholder = t(key);
      }
    });

    // Translate all elements with data-i18n-title
    document.querySelectorAll('[data-i18n-title]').forEach(el => {
      const key = el.dataset.i18nTitle;
      if (key && (I18N[lang]?.[key] || I18N.en?.[key])) {
        const txt = t(key);
        el.title = txt;
        if (el.hasAttribute('aria-label')) el.setAttribute('aria-label', txt);
      }
    });

    if (elSettingIconStyle) {
      const optUniform = elSettingIconStyle.querySelector('option[value="uniform"]');
      if (optUniform) optUniform.textContent = t('iconStyleUniform');
      const optFullbleed = elSettingIconStyle.querySelector('option[value="fullbleed"]');
      if (optFullbleed) optFullbleed.textContent = t('iconStyleFullbleed');
    }

    // Default Section Title if not user-customized
    if (elSectionTitle) {
      const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];
      if (!state.settings.title || defaultTitles.includes(state.settings.title)) {
        state.settings.title = '';
        elSectionTitle.textContent = t('favoritesTitle');
        if (elSettingTitleInput) elSettingTitleInput.value = t('favoritesTitle');
      }
    }

    // Context menu texts
    if (elCtxOpenNewTab) elCtxOpenNewTab.textContent = t('ctxOpenNewTab');
    if (elCtxOpenNewWindow) elCtxOpenNewWindow.textContent = t('ctxOpenNewWindow');
    if (elCtxAddToFavorites) {
      const span = elCtxAddToFavorites.querySelector('span');
      if (span) span.textContent = t('ctxAddToFavorites');
    }
    if (elCtxCustomThumbnail) {
      const span = elCtxCustomThumbnail.querySelector('span');
      if (span) span.textContent = t('ctxCustomThumbnail');
    }
    if (elCtxRemoveCustomThumbnail) {
      const span = elCtxRemoveCustomThumbnail.querySelector('span');
      if (span) span.textContent = t('ctxRemoveCustomThumbnail');
    }
    if (elCtxEdit) elCtxEdit.textContent = t('ctxEdit');
    if (elCtxMoveFolder) elCtxMoveFolder.textContent = t('ctxMoveFolder');
    if (elCtxDelete) elCtxDelete.textContent = t('ctxDelete');

    if (elBgCtxNewShortcut) {
      const span = elBgCtxNewShortcut.querySelector('span');
      if (span) span.textContent = t('ctxNewShortcut');
    }
    if (elBgCtxNewFolder) {
      const span = elBgCtxNewFolder.querySelector('span');
      if (span) span.textContent = t('ctxNewFolder');
    }
    if (elBgCtxSettings) {
      const span = elBgCtxSettings.querySelector('span');
      if (span) span.textContent = t('ctxSettings');
    }
    if (elBgCtxToggleClosedTabs) {
      const spans = elBgCtxToggleClosedTabs.querySelectorAll('span');
      if (spans.length > 1) spans[1].textContent = t('ctxShowClosedTabs');
    }
    if (elBgCtxToggleHistory) {
      const spans = elBgCtxToggleHistory.querySelectorAll('span');
      if (spans.length > 1) spans[1].textContent = t('ctxShowHistory');
    }
    if (elBgCtxToggleSearch) {
      const spans = elBgCtxToggleSearch.querySelectorAll('span');
      if (spans.length > 1) spans[1].textContent = t('ctxShowSearch');
    }

    if (elTabCtxRename) {
      const span = elTabCtxRename.querySelector('span');
      if (span) span.textContent = t('ctxRename');
    }
    if (elTabCtxNewSection) {
      const span = elTabCtxNewSection.querySelector('span');
      if (span) span.textContent = t('ctxNewSection');
    }
    if (elTabCtxDelete) {
      const span = elTabCtxDelete.querySelector('span');
      if (span) span.textContent = t('ctxDeleteSection');
    }

    renderFavoriteSectionsBar();
  }

  /**
   * Native Apple-styled Toast Notification
   */
  let toastTimer = null;
  function showToast(message) {
    let toast = document.getElementById('app-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'app-toast';
      toast.className = 'app-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('visible');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('visible');
    }, 2400);
  }

  /**
   * IndexedDB Storage Engine for Webpage Thumbnails
   */
  const IDB_NAME = 'SafariSpeedDialDB';
  const IDB_VERSION = 1;
  const IDB_STORE_NAME = 'thumbnails';
  let idbInstance = null;
  const thumbCache = new Map();
  const fallbackThumbKeys = new Set();

  function openThumbnailDB() {
    if (idbInstance) return Promise.resolve(idbInstance);
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(IDB_STORE_NAME)) {
          db.createObjectStore(IDB_STORE_NAME, { keyPath: 'url' });
        }
      };
      request.onsuccess = (e) => {
        idbInstance = e.target.result;
        resolve(idbInstance);
      };
      request.onerror = (e) => {
        console.warn('IndexedDB open error:', e.target.error);
        reject(e.target.error);
      };
    });
  }

  async function initThumbnailDB() {
    try {
      const db = await openThumbnailDB();
      // Wipe old bot challenge thumbnails so no Cloudflare captchas remain
      const CLEANUP_KEY = 'safari_speeddial_bot_cleanup_v2';
      if (!localStorage.getItem(CLEANUP_KEY)) {
        localStorage.setItem(CLEANUP_KEY, '1');
        try {
          const clearTx = db.transaction(IDB_STORE_NAME, 'readwrite');
          clearTx.objectStore(IDB_STORE_NAME).clear();
          await new Promise((r) => { clearTx.oncomplete = r; clearTx.onerror = r; });
          thumbCache.clear();
        } catch (e) {}
      }
      await preloadThumbnails(db);
    } catch (err) {
      console.warn('Could not initialize thumbnail IndexedDB:', err);
    }
  }

  function preloadThumbnails(db) {
    return new Promise((resolve) => {
      try {
        if (!db) {
          resolve();
          return;
        }
        const tx = db.transaction(IDB_STORE_NAME, 'readonly');
        const store = tx.objectStore(IDB_STORE_NAME);
        const req = store.getAll();
        req.onsuccess = () => {
          try {
            const records = req.result || [];
            records.forEach(rec => {
              if (rec && rec.url) {
                let thumbSrc = null;
                if (rec.blob instanceof Blob) {
                  try {
                    thumbSrc = URL.createObjectURL(rec.blob);
                  } catch (e) {}
                }
                if (!thumbSrc && rec.dataUrl) {
                  thumbSrc = rec.dataUrl;
                }

                if (thumbSrc) {
                  thumbCache.set(rec.url, thumbSrc);
                  if (rec.isFallback === true) {
                    fallbackThumbKeys.add(rec.url);
                  }
                }
              }
            });
          } catch (e) {
            console.warn('preloadThumbnails error:', e);
          }
          resolve();
        };
        req.onerror = () => resolve();
        tx.onerror = () => resolve();
        tx.onabort = () => resolve();
      } catch (err) {
        resolve();
      }
    });
  }

  function dataUrlToBlob(dataUrl) {
    if (!dataUrl || typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) return null;
    try {
      const parts = dataUrl.split(',');
      if (parts.length === 2) {
        const mimeMatch = parts[0].match(/:(.*?);/);
        const mime = mimeMatch ? mimeMatch[1] : 'image/webp';
        const bstr = atob(parts[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) {
          u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
      }
    } catch (e) {}
    return null;
  }

  function getThumbKey(url) {
    if (!url) return '';
    try {
      const u = new URL(url);
      const host = u.hostname.toLowerCase().replace(/^www\./, '');
      let p = (u.pathname || '').replace(/\/+$/, '').toLowerCase();
      let search = '';
      if (u.search) {
        const sp = new URLSearchParams(u.search);
        ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'ref', 'ref_', 'rdt', 'fbclid', 'gclid'].forEach(k => sp.delete(k));
        const str = sp.toString();
        if (str) search = '?' + str.toLowerCase();
      }
      return `${host}${p}${search}`;
    } catch {
      return String(url).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/+$/, '');
    }
  }

  function isMatchingTab(tabUrl, targetUrl) {
    if (!tabUrl || !targetUrl) return false;
    const k1 = getThumbKey(tabUrl);
    const k2 = getThumbKey(targetUrl);
    if (k1 === k2) return true;

    try {
      const u1 = new URL(tabUrl);
      const u2 = new URL(targetUrl);
      const h1 = u1.hostname.toLowerCase().replace(/^www\./, '');
      const h2 = u2.hostname.toLowerCase().replace(/^www\./, '');
      if (h1 !== h2) return false;

      const p1 = (u1.pathname || '').replace(/\/+$/, '').toLowerCase();
      const p2 = (u2.pathname || '').replace(/\/+$/, '').toLowerCase();
      return p1 === p2;
    } catch {
      return false;
    }
  }

  async function saveThumbnail(url, dataUrl, isFallback = false) {
    const key = getThumbKey(url);
    if (!key || !dataUrl) return;

    let blob = null;
    let cachedUrl = dataUrl;
    if (typeof dataUrl === 'string' && dataUrl.startsWith('data:')) {
      blob = dataUrlToBlob(dataUrl);
      if (blob) {
        const oldSrc = thumbCache.get(key);
        if (oldSrc && typeof oldSrc === 'string' && oldSrc.startsWith('blob:')) {
          try { URL.revokeObjectURL(oldSrc); } catch (e) {}
        }
        try {
          cachedUrl = URL.createObjectURL(blob);
        } catch (e) {
          cachedUrl = dataUrl;
        }
      }
    }

    thumbCache.set(key, cachedUrl);
    if (isFallback) {
      fallbackThumbKeys.add(key);
    } else {
      fallbackThumbKeys.delete(key);
    }

    try {
      const db = await openThumbnailDB();
      const tx = db.transaction(IDB_STORE_NAME, 'readwrite');
      const store = tx.objectStore(IDB_STORE_NAME);
      store.put({
        url: key,
        dataUrl: dataUrl,
        blob: blob,
        originalUrl: url,
        timestamp: Date.now(),
        isFallback: !!isFallback
      });
      await new Promise((resolve) => {
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      });
    } catch (err) {
      console.warn('Failed to save thumbnail in IDB:', err);
    }
    updateCardThumbnails(url, cachedUrl);
  }

  function downscaleImage(dataUrl, targetWidth = 640, targetHeight = 384) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          const ctx = canvas.getContext('2d');
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          const scale = Math.max(targetWidth / img.width, targetHeight / img.height);
          const w = img.width * scale;
          const h = img.height * scale;
          const x = (targetWidth - w) / 2;
          const y = 0; // Focus on top navbar, header & hero banner
          ctx.drawImage(img, x, y, w, h);
          try {
            const webpData = canvas.toDataURL('image/webp', 0.82);
            if (webpData && webpData.startsWith('data:image/webp')) {
              return resolve(webpData);
            }
          } catch (e) {}
          resolve(canvas.toDataURL('image/jpeg', 0.85));
        } catch (e) {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  }

  // Background Screenshot Capture Concurrent Queue
  const MAX_CONCURRENT_CAPTURES = 4;
  let runningCapturesCount = 0;
  const captureQueue = [];
  const captureQueueSet = new Set();
  const activeCaptures = new Set();

  function queueCapture(url, force = false, showBadge = false, title = '') {
    if (!url || url.startsWith('about:') || url.startsWith('chrome:') || url.startsWith('moz-extension:')) return;
    const key = getThumbKey(url);
    if (!key) return;

    if (!force && thumbCache.has(key) && !fallbackThumbKeys.has(key)) return;
    if (captureQueueSet.has(key)) return;

    captureQueueSet.add(key);
    if (force) {
      captureQueue.unshift({ url, force, showBadge, key, title });
    } else {
      captureQueue.push({ url, force, showBadge, key, title });
    }
    processCaptureQueue();
  }

  function processCaptureQueue() {
    while (runningCapturesCount < MAX_CONCURRENT_CAPTURES && captureQueue.length > 0) {
      const task = captureQueue.shift();
      captureQueueSet.delete(task.key);
      activeCaptures.add(task.key);
      runningCapturesCount++;

      if (task.showBadge) {
        setCardRefreshingState(task.url, true);
      }

      captureUrlScreenshot(task.url, task.showBadge, task.title, task.force)
        .catch((err) => {
          console.warn('Screenshot capture failed for:', task.url, err);
        })
        .finally(() => {
          activeCaptures.delete(task.key);
          if (task.showBadge) {
            setCardRefreshingState(task.url, false);
          }
          runningCapturesCount--;
          processCaptureQueue();
        });
    }
  }

  function generateFallbackScreenshot(url, domain, title = '') {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 384;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      ctx.save();
      ctx.scale(640 / 480, 384 / 270);

      const cleanDomain = domain || extractDomain(url) || '';
      const isReddit = cleanDomain.includes('reddit.com');
      const isAmazon = cleanDomain.includes('amazon');

      // Detect subreddit if reddit
      let subTitle = '';
      if (isReddit) {
        const match = url.match(/\/r\/([a-zA-Z0-9_-]+)/i);
        subTitle = match ? `r/${match[1]}` : '';
      }

      const displayTitle = title || subTitle || cleanDomain || 'Web';

      // Background gradient with unique subtle hue based on URL string hash
      const colorHash = getColorForString(url);
      const grad = ctx.createLinearGradient(0, 0, 480, 270);
      if (isReddit) {
        grad.addColorStop(0, '#ff4500');
        grad.addColorStop(1, '#8b2500');
      } else if (isAmazon) {
        grad.addColorStop(0, '#232f3e');
        grad.addColorStop(1, '#131921');
      } else {
        grad.addColorStop(0, colorHash);
        grad.addColorStop(1, '#141518');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 480, 270);

      // Browser top bar simulation
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      ctx.fillRect(0, 0, 480, 36);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.fillRect(0, 35, 480, 1);

      // 3 macOS window dots
      const dots = ['#ff5f56', '#ffbd2e', '#27c93f'];
      dots.forEach((color, i) => {
        ctx.beginPath();
        ctx.arc(20 + i * 14, 18, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.8;
        ctx.fill();
      });
      ctx.globalAlpha = 1.0;

      // Domain pill in simulated URL bar
      ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
      if (ctx.roundRect) {
        ctx.roundRect(125, 7, 230, 22, 6);
        ctx.fill();
      } else {
        ctx.fillRect(125, 7, 230, 22);
      }
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.font = '11.5px -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(subTitle ? `reddit.com/${subTitle}` : (cleanDomain || 'website'), 240, 18);

      // Center initial monogram or brand symbol circle
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.beginPath();
      ctx.arc(240, 114, 38, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const badgeText = isReddit ? (subTitle ? subTitle.replace(/^r\//, '').slice(0, 3).toUpperCase() : 'r/') : displayTitle.charAt(0).toUpperCase();
      ctx.fillText(badgeText, 240, 115);

      // Primary header text (e.g. "r/Tekken", "r/MagicArena", product name)
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif';
      const mainText = subTitle || displayTitle;
      const truncatedMain = (mainText.length > 28) ? mainText.slice(0, 26) + '…' : mainText;
      ctx.fillText(truncatedMain, 240, 172);

      // Secondary subtitle (bookmark title or domain)
      if (subTitle && title && title !== subTitle) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.font = '12.5px -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif';
        const subDesc = (title.length > 38) ? title.slice(0, 36) + '…' : title;
        ctx.fillText(subDesc, 240, 200);
      } else {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.font = '12px -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif';
        ctx.fillText(cleanDomain, 240, 200);
      }

      ctx.restore();

      try {
        const webpData = canvas.toDataURL('image/webp', 0.82);
        if (webpData && webpData.startsWith('data:image/webp')) {
          return webpData;
        }
      } catch (e) {}

      return canvas.toDataURL('image/jpeg', 0.85);
    } catch (e) {
      return null;
    }
  }

  async function fetchOpenGraphThumbnail(url) {
    const cleanUrl = normalizeUrl(url);
    const isReddit = cleanUrl.includes('reddit.com');

    // Engine 1: OpenGraph / Twitter meta image directly from webpage HTML
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      const pageRes = await fetch(cleanUrl, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (pageRes.ok) {
        const text = await pageRes.text();
        const ogMatch = text.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
                        text.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i) ||
                        text.match(/<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i) ||
                        text.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']twitter:image["']/i);
        if (ogMatch && ogMatch[1]) {
          let ogUrl = ogMatch[1].trim();
          if (ogUrl.startsWith('//')) ogUrl = 'https:' + ogUrl;
          else if (ogUrl.startsWith('/')) {
            const u = new URL(cleanUrl);
            ogUrl = `${u.protocol}//${u.host}${ogUrl}`;
          }
          const imgRes = await fetch(ogUrl);
          if (imgRes.ok) {
            const blob = await imgRes.blob();
            if (blob && blob.size > 1000) {
              return await blobToOptimizedDataUrl(blob);
            }
          }
        }
      }
    } catch (e) {}

    // Engine 2: Reddit RSS feed (extracts official media thumbnail for subreddits and posts)
    if (isReddit) {
      try {
        const subMatch = cleanUrl.match(/reddit\.com\/(r\/[a-zA-Z0-9_-]+)/i);
        const rssUrl = subMatch ? `https://www.reddit.com/${subMatch[1]}/.rss` : (cleanUrl.replace(/\/+$/, '') + '/.rss');
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);
        const rssRes = await fetch(rssUrl, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (rssRes.ok) {
          const xml = await rssRes.text();
          const mediaMatch = xml.match(/<media:thumbnail\s+url="([^"]+)"/i) || xml.match(/&lt;img\s+src="([^"]+)"/i);
          if (mediaMatch && mediaMatch[1]) {
            const imgUrl = mediaMatch[1].replace(/&amp;/g, '&');
            const imgRes = await fetch(imgUrl);
            if (imgRes.ok) {
              const blob = await imgRes.blob();
              if (blob && blob.size > 800) {
                return await blobToOptimizedDataUrl(blob);
              }
            }
          }
        }
      } catch (e) {}
    }

    return null;
  }

  function blobToOptimizedDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const optimized = await downscaleImage(reader.result, 640, 384);
          resolve(optimized);
        } catch (err) {
          resolve(reader.result);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function captureUrlScreenshot(url, showToastOnSuccess = false, customTitle = '', force = false) {
    let dataUrl = null;
    let isReal = false;

    // 0. Request background service worker to capture live tab (open tab or hidden tab)
    if (browserAPI.runtime && browserAPI.runtime.sendMessage) {
      try {
        const res = await browserAPI.runtime.sendMessage({
          action: 'captureUrlLive',
          url: url,
          title: customTitle,
          force: force
        });
        if (res && res.success && res.dataUrl) {
          dataUrl = res.dataUrl;
          isReal = true;
        }
      } catch (e) {}
    }

    // 1. Direct OpenGraph / media extraction from page
    if (!dataUrl) {
      try {
        dataUrl = await fetchOpenGraphThumbnail(url);
        if (dataUrl) isReal = true;
      } catch (err) {}
    }

    // 2. Fallback: generate sleek offline canvas thumbnail banner (NO bot captchas!)
    if (!dataUrl) {
      const key = getThumbKey(url);
      if (thumbCache.has(key) && !fallbackThumbKeys.has(key)) {
        return thumbCache.get(key);
      }
      const domain = extractDomain(url);
      dataUrl = generateFallbackScreenshot(url, domain, customTitle);
      isReal = false;
    }

    if (dataUrl) {
      await saveThumbnail(url, dataUrl, !isReal);
      if (showToastOnSuccess) {
        const domain = extractDomain(url);
        showToast(`Captura actualizada para ${customTitle || domain}`);
      }
      return dataUrl;
    }
  }

  function createThumbnailFaviconPill(domain, brand, favIconUrl, title) {
    const pill = document.createElement('div');
    pill.className = 'thumb-favicon-pill';
    pill.title = title || domain || '';
    if (brand && BRAND_SVGS[brand]) {
      pill.innerHTML = BRAND_SVGS[brand];
    } else {
      const img = document.createElement('img');
      img.decoding = 'async';
      img.loading = 'lazy';
      img.src = favIconUrl || getFaviconUrl(domain);
      img.alt = '';
      img.onerror = () => {
        pill.innerHTML = `<span>${(title || domain || 'S').charAt(0).toUpperCase()}</span>`;
        pill.style.fontSize = '10px';
        pill.style.fontWeight = 'bold';
        pill.style.color = '#ffffff';
      };
      pill.appendChild(img);
    }
    return pill;
  }

  function updateCardThumbnails(url, dataUrl) {
    const key = getThumbKey(url);
    if (!key) return;

    // 1. Update full shortcut cards
    document.querySelectorAll('.shortcut-card[data-thumb-url]').forEach(card => {
      if (getThumbKey(card.dataset.thumbUrl) === key) {
        if (card.dataset.hasCustomThumb === 'true') {
          const badge = card.querySelector('.thumb-refreshing-badge');
          if (badge) badge.remove();
          return;
        }

        const fallback = card.querySelector('.thumb-fallback-preview');
        if (fallback) fallback.remove();

        let shimmer = card.querySelector('.thumb-skeleton-shimmer');
        let previewImg = card.querySelector('.thumb-preview-img');

        if (previewImg) {
          previewImg.classList.remove('is-loaded');
          if (shimmer) shimmer.style.display = '';
          previewImg.onload = () => {
            previewImg.classList.add('is-loaded');
            if (shimmer) shimmer.style.display = 'none';
          };
          previewImg.src = dataUrl;
          if (previewImg.complete) {
            previewImg.classList.add('is-loaded');
            if (shimmer) shimmer.style.display = 'none';
          }
        } else {
          if (!shimmer) {
            shimmer = document.createElement('div');
            shimmer.className = 'thumb-skeleton-shimmer';
            card.prepend(shimmer);
          }
          const img = document.createElement('img');
          img.className = 'thumb-preview-img';
          img.decoding = 'async';
          img.loading = 'lazy';
          img.alt = '';
          img.onload = () => {
            img.classList.add('is-loaded');
            if (shimmer) shimmer.style.display = 'none';
          };
          img.src = dataUrl;
          if (img.complete) {
            img.classList.add('is-loaded');
            if (shimmer) shimmer.style.display = 'none';
          }
          card.appendChild(img);
        }

        // Add frosted favicon pill badge if not yet present
        if (!card.querySelector('.thumb-favicon-pill')) {
          const domain = card.dataset.domain || extractDomain(url);
          const brand = getKnownBrand(domain);
          const pill = createThumbnailFaviconPill(domain, brand, null, card.dataset.title || '');
          card.appendChild(pill);
        }

        const badge = card.querySelector('.thumb-refreshing-badge');
        if (badge) badge.remove();
      }
    });

    // 2. Update folder mini preview items in thumbnail mode
    if (state.settings.viewMode === 'thumb') {
      document.querySelectorAll('.folder-mini-item[data-child-thumb-url]').forEach(cell => {
        if (getThumbKey(cell.dataset.childThumbUrl) === key) {
          if (cell.dataset.hasCustomThumb === 'true') return;
          cell.innerHTML = '';
          cell.classList.remove('is-pending-thumb');
          const img = document.createElement('img');
          img.className = 'folder-mini-thumb-img';
          img.decoding = 'async';
          img.loading = 'lazy';
          img.src = dataUrl;
          img.alt = '';
          cell.appendChild(img);
        }
      });
    }
  }

  function setCardRefreshingState(url, isRefreshing) {
    const key = getThumbKey(url);
    if (!key) return;

    document.querySelectorAll('.shortcut-card[data-thumb-url]').forEach(card => {
      if (getThumbKey(card.dataset.thumbUrl) === key) {
        const existingBadge = card.querySelector('.thumb-refreshing-badge');
        if (isRefreshing && !existingBadge) {
          const badge = document.createElement('div');
          badge.className = 'thumb-refreshing-badge';
          badge.innerHTML = `<div class="thumb-spinner"></div><span>Actualizando...</span>`;
          card.appendChild(badge);
        } else if (!isRefreshing && existingBadge) {
          existingBadge.remove();
        }
      }
    });
  }

  /**
   * Scan bookmarks in Favoritos and extract missing thumbnails one by one
   */
  function checkAndExtractMissingThumbnails() {
    if (state.settings.viewMode !== 'thumb') return;

    const itemsToCapture = [];

    function scanItems(items) {
      for (const item of items) {
        if (item.type === 'folder' && item.children) {
          scanItems(item.children);
        } else if (item.type === 'url' && item.url && (item.url.startsWith('http://') || item.url.startsWith('https://'))) {
          const key = getThumbKey(item.url);
          if (!thumbCache.has(key) || fallbackThumbKeys.has(key)) {
            itemsToCapture.push({ url: item.url, title: item.title });
          }
        }
      }
    }
    scanItems(getAllFavoriteItems());

    itemsToCapture.forEach(it => {
      queueCapture(it.url, false, false, it.title);
    });
  }

  /**
   * Open a bookmark: opens immediately, then updates thumbnail after a few seconds
   */
  function openBookmark(url, isNewTab = false) {
    if (!url) return;

    // 1. Notify background worker immediately that this bookmark was opened
    if (browserAPI.runtime && browserAPI.runtime.sendMessage) {
      browserAPI.runtime.sendMessage({ action: 'bookmarkOpening', url: url }).catch(() => {});
    }
    recordPendingCapture(url);

    // 2. Open tab
    if (isNewTab) {
      if (browserAPI.tabs && browserAPI.tabs.create) {
        browserAPI.tabs.create({ url: url }).then(tab => {
          if (tab && tab.id && browserAPI.runtime && browserAPI.runtime.sendMessage) {
            browserAPI.runtime.sendMessage({
              action: 'tabCreatedForBookmark',
              tabId: tab.id,
              url: url
            }).catch(() => {});
          }
        }).catch(() => {
          window.open(url, '_blank');
        });
      } else {
        window.open(url, '_blank');
      }

      // Start page remains open: capture in background after 2 seconds if missing
      setTimeout(() => {
        queueCapture(url, false, false);
      }, 2000);
    } else {
      const doNavigate = () => { window.location.href = url; };
      if (browserAPI.tabs && browserAPI.tabs.getCurrent) {
        browserAPI.tabs.getCurrent().then(tab => {
          if (tab && tab.id && browserAPI.runtime && browserAPI.runtime.sendMessage) {
            browserAPI.runtime.sendMessage({
              action: 'tabNavigatingForBookmark',
              tabId: tab.id,
              url: url
            }).finally(doNavigate);
          } else {
            doNavigate();
          }
        }).catch(doNavigate);
      } else {
        setTimeout(doNavigate, 60);
      }
    }
  }

  function openBookmarkInNewWindow(url) {
    if (!url) return;
    if (browserAPI.runtime && browserAPI.runtime.sendMessage) {
      browserAPI.runtime.sendMessage({ action: 'bookmarkOpening', url: url }).catch(() => {});
    }
    recordPendingCapture(url);

    if (browserAPI.windows && browserAPI.windows.create) {
      browserAPI.windows.create({ url: url }).then(win => {
        const tab = win && win.tabs && win.tabs[0];
        if (tab && tab.id && browserAPI.runtime && browserAPI.runtime.sendMessage) {
          browserAPI.runtime.sendMessage({
            action: 'tabCreatedForBookmark',
            tabId: tab.id,
            url: url
          }).catch(() => {});
        }
      }).catch(() => {
        window.open(url, '_blank', 'width=1200,height=800');
      });
    } else {
      window.open(url, '_blank', 'width=1200,height=800');
    }

    setTimeout(() => {
      queueCapture(url, false, false);
    }, 2000);
  }

  async function recordPendingCapture(url) {
    try {
      const res = await getStorageData(['pending_thumb_captures']);
      const list = res?.pending_thumb_captures || [];
      if (!list.includes(url)) {
        list.push(url);
        await setStorageData({ pending_thumb_captures: list.slice(-25) });
      }
    } catch (e) {}
  }



  // Star & Favorite Helpers for Closed Tabs / History
  function isUrlInFavorites(url) {
    if (!url) return false;
    const targetKey = getThumbKey(url);
    ensureFavoriteSections();
    for (const sec of state.favoriteSections) {
      for (const item of (sec.items || [])) {
        if (item.type === 'folder') {
          for (const child of (item.children || [])) {
            if (child.url && getThumbKey(child.url) === targetKey) return true;
          }
        } else if (item.url && getThumbKey(item.url) === targetKey) {
          return true;
        }
      }
    }
    return false;
  }

  function getStarIconSvg(isFilled) {
    if (isFilled) {
      return `<svg viewBox="0 0 20 20" width="14" height="14" fill="#ffb800">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
      </svg>`;
    } else {
      return `<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="10 2 12.8 7.6 19 8.5 14.5 12.9 15.6 19 10 16.1 4.4 19 5.5 12.9 1 8.5 7.2 7.6 10 2"/>
      </svg>`;
    }
  }

  function updateStarsForUrl(url, isStarred) {
    const targetKey = getThumbKey(url);
    document.querySelectorAll('.quick-star-btn').forEach(btn => {
      const card = btn.closest('.shortcut-item');
      const cardUrl = card?.dataset?.url;
      if (cardUrl && getThumbKey(cardUrl) === targetKey) {
        btn.classList.toggle('is-starred', isStarred);
        btn.innerHTML = getStarIconSvg(isStarred);
        btn.title = isStarred ? t('ctxAddToFavorites') : t('ctxAddToFavorites');
        btn.setAttribute('aria-label', isStarred ? t('ctxAddToFavorites') : t('ctxAddToFavorites'));
      }
    });
  }

  function addUrlToFavorites(url, title, favIconUrl) {
    if (!url) return;
    if (isUrlInFavorites(url)) {
      showToast(t('toastAlreadyFavorite', { title: title || url }));
      return;
    }

    const domain = extractDomain(url);
    const cleanTitle = title || deriveNameFromDomain(domain) || domain || t('sectionFavorites');
    const newItem = createShortcutItem(cleanTitle, url, null, favIconUrl);
    state.items.push(newItem);
    saveState();
    renderGrid();
    updateStarsForUrl(url, true);
    showToast(t('toastAddedFavorite', { title: cleanTitle }));

    if (state.settings.viewMode === 'thumb') {
      queueCapture(url, false);
    }
  }

  function toggleFavoriteFromCard(url, title, favIconUrl, btnEl) {
    const isStarred = isUrlInFavorites(url);
    if (!isStarred) {
      addUrlToFavorites(url, title, favIconUrl);
    } else {
      const targetKey = getThumbKey(url);
      const initialCount = state.items.length;
      state.items = state.items.filter(item => {
        if (item.type === 'url' && getThumbKey(item.url) === targetKey) return false;
        return true;
      });
      if (state.items.length !== initialCount) {
        saveState();
        renderGrid();
        updateStarsForUrl(url, false);
        showToast(t('toastRemovedFavorite'));
      }
    }
  }

  function renderThumbnailCardInner(cardEl, url, title, domain, brand, favIconUrl, customThumbnail = null) {
    cardEl.dataset.thumbUrl = url;
    cardEl.dataset.domain = domain || '';
    cardEl.dataset.title = title || '';
    if (customThumbnail) {
      cardEl.dataset.hasCustomThumb = 'true';
    } else {
      delete cardEl.dataset.hasCustomThumb;
    }
    const thumbKey = getThumbKey(url);
    const displayThumb = customThumbnail || (thumbKey ? thumbCache.get(thumbKey) : null);

    if (displayThumb) {
      const shimmer = document.createElement('div');
      shimmer.className = 'thumb-skeleton-shimmer';
      cardEl.appendChild(shimmer);

      const img = document.createElement('img');
      img.className = 'thumb-preview-img';
      img.decoding = 'async';
      img.loading = 'lazy';
      img.alt = '';
      img.onload = () => {
        img.classList.add('is-loaded');
        shimmer.style.display = 'none';
      };
      img.onerror = () => {
        shimmer.style.display = 'none';
      };
      img.src = displayThumb;
      if (img.complete) {
        img.classList.add('is-loaded');
        shimmer.style.display = 'none';
      }
      cardEl.appendChild(img);

      const pill = createThumbnailFaviconPill(domain, brand, favIconUrl, title);
      cardEl.appendChild(pill);
    } else {
      const fallback = document.createElement('div');
      fallback.className = 'thumb-fallback-preview';

      const iconBox = document.createElement('div');
      iconBox.className = 'thumb-fallback-icon';

      if (brand && BRAND_SVGS[brand]) {
        iconBox.innerHTML = BRAND_SVGS[brand];
      } else {
        const img = document.createElement('img');
        img.src = favIconUrl || getFaviconUrl(domain);
        img.alt = '';
        img.onerror = () => {
          iconBox.innerHTML = `<span>${(title || domain || 'S').charAt(0).toUpperCase()}</span>`;
          iconBox.style.backgroundColor = getColorForString(domain || title);
        };
        iconBox.appendChild(img);
      }

      const domainLabel = document.createElement('div');
      domainLabel.className = 'thumb-fallback-domain';
      domainLabel.textContent = domain || title || '';

      fallback.appendChild(iconBox);
      fallback.appendChild(domainLabel);
      cardEl.appendChild(fallback);

      if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
        queueCapture(url, false, false, title);
      }
    }

    if (activeCaptures.has(thumbKey)) {
      const badge = document.createElement('div');
      badge.className = 'thumb-refreshing-badge';
      badge.innerHTML = `<div class="thumb-spinner"></div><span>Actualizando...</span>`;
      cardEl.appendChild(badge);
    }
  }

  /**
   * Helper: Generate stable color based on string
   */
  function getColorForString(str) {
    if (!str) return APPLE_COLORS[0];
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const index = Math.abs(hash) % APPLE_COLORS.length;
    return APPLE_COLORS[index];
  }

  /**
   * Helper: Determine if a color string (hex, rgb, or rgba) has high perceived luminance,
   * factoring in alpha transparency over the given theme context (dark by default).
   */
  function isColorLight(hexOrRgba, isContextLight = false) {
    if (!hexOrRgba) return isContextLight;
    if (hexOrRgba === 'liquid-glass') return isContextLight;
    let r = 0, g = 0, b = 0, a = 1;
    if (hexOrRgba.startsWith('#')) {
      let hex = hexOrRgba.slice(1);
      if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
      if (hex.length >= 6) {
        r = parseInt(hex.slice(0, 2), 16);
        g = parseInt(hex.slice(2, 4), 16);
        b = parseInt(hex.slice(4, 6), 16);
      }
      if (hex.length === 8) {
        a = parseInt(hex.slice(6, 8), 16) / 255;
      }
    } else if (hexOrRgba.startsWith('rgb')) {
      const parts = hexOrRgba.match(/[\d.]+/g);
      if (parts && parts.length >= 3) {
        r = parseFloat(parts[0]);
        g = parseFloat(parts[1]);
        b = parseFloat(parts[2]);
        if (parts.length >= 4) {
          a = parseFloat(parts[3]);
        }
      }
    }
    const bg = isContextLight ? 245 : 30;
    const effectiveR = r * a + bg * (1 - a);
    const effectiveG = g * a + bg * (1 - a);
    const effectiveB = b * a + bg * (1 - a);
    const luminance = (0.299 * effectiveR + 0.587 * effectiveG + 0.114 * effectiveB) / 255;
    return luminance > 0.6;
  }

  /**
   * ==========================================================================
   * Liquid Glass WebGL Engine
   * Based on WebGL Squircle Shader (https://codepen.io/shingidad/pen/jEPxMgW)
   * Deforms and refracts the background wallpaper under cards, folders, settings,
   * and cursor with GPU-accelerated convex lens refraction and chromatic dispersion.
   * ==========================================================================
   */
 
  const LiquidGlassEngine = (() => {
    let canvas = null;
    let gl = null;
    let program = null;
    let positionBuffer = null;
    let wallpaperTexture = null;
    let isInitialized = false;
    let isRunning = false;
    let currentWpUrl = '';
    let imageObj = null;
    let imgNaturalWidth = 1920;
    let imgNaturalHeight = 1080;
    let mouse = [0, 0];
    let isDarkMode = 0.0;
    
    let rafId = null;
    let boxCount = 0;
    const MAX_BOXES = 80;
    const boxData = new Float32Array(MAX_BOXES * 4);
    let cachedElements = [];
    let frameCount = 0;
    let uniforms = {};

    const config = { 
      useMouseLight: 0.0, 
      refraction: 0.08, 
      blur: 0.8, 
      bevel: 0.35
    };

    const vsSource = `
      attribute vec2 position;
      void main() {
        gl_Position = vec4(position, 0.0, 1.0);
      }
    `;

    const fsSource = `
      precision mediump float;
      uniform vec3 iResolution;
      uniform vec4 iMouse;
      uniform sampler2D iChannel0;
      uniform vec2 uImageSize;
      
      uniform float uUseMouseLight;
      uniform float uRefraction;
      uniform float uBlur;
      uniform float uLightingIntensity;
      uniform float uDarkMode;
      
      const int MAX_BOXES = 80;
      uniform vec4 uBoxes[MAX_BOXES];
      uniform int uBoxCount;

      vec2 getCoverUV(vec2 p) {
        vec2 uv = p / iResolution.xy;
        float sAspect = (iResolution.y > 0.0) ? (iResolution.x / iResolution.y) : 1.0;
        float iAspect = (uImageSize.y > 0.0) ? (uImageSize.x / uImageSize.y) : 1.0;
        if (sAspect > iAspect) {
          float scale = iAspect / sAspect;
          uv.y = (uv.y - 0.5) * scale + 0.5;
        } else {
          float scale = sAspect / iAspect;
          uv.x = (uv.x - 0.5) * scale + 0.5;
        }
        return clamp(uv, 0.0, 1.0);
      }

      void mainImage(out vec4 fragColor, in vec2 fragCoord) {
        const float NUM_ZERO = 0.0;
        const float NUM_ONE = 1.0;
        
        vec2 uv = getCoverUV(fragCoord.xy);
        vec2 mouse = iMouse.xy / iResolution.xy;
        
        vec4 baseColor = texture2D(iChannel0, uv);
        fragColor = baseColor;

        for (int i = 0; i < MAX_BOXES; i++) {
          if (i >= uBoxCount) break;
          vec4 b = uBoxes[i];
          
          if (fragCoord.x >= b.x && fragCoord.x <= (b.x + b.z) &&
              fragCoord.y >= b.y && fragCoord.y <= (b.y + b.w)) {

            vec2 halfSize = b.zw * 0.5;
            vec2 center = b.xy + halfSize;
            vec2 p = fragCoord.xy - center;
            
            float radius = (b.z / b.w > 3.0 && b.w <= 50.0) ? b.w * 0.5 :
                           (b.z > 140.0 && b.w <= 160.0) ? 14.0 :
                           min(min(b.z, b.w) * 0.25, 28.0);
            vec2 q = abs(p) - halfSize + vec2(radius);
            float d = min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius;

            float transition = 1.0 - smoothstep(0.0, 1.5, d);
            
            if (transition > 0.0) {
              float innerD = max(0.0, -d);
              float maxD = min(halfSize.x, halfSize.y);
              float dNorm = 1.0 - clamp(innerD / maxD, 0.0, 1.0);
              
              float roundedBox = pow(dNorm, 3.0);
              
              float rb1 = clamp((NUM_ONE - roundedBox * 1.0) * 8.0, NUM_ZERO, NUM_ONE);
              float rb2 = clamp((0.96 - roundedBox * 0.95) * 16.0, NUM_ZERO, NUM_ONE) - clamp((0.90 - roundedBox * 0.95) * 16.0, NUM_ZERO, NUM_ONE);
              float rb3 = clamp((1.40 - roundedBox * 1.10) * 2.0,  NUM_ZERO, NUM_ONE) - clamp((NUM_ONE - roundedBox * 1.10) * 2.0, NUM_ZERO, NUM_ONE);

            vec2 localP = p / halfSize; 
            vec2 lensOffset = -localP * (1.0 - clamp(roundedBox, 0.0, 1.0)) * uRefraction;
            vec2 lensUV = uv + lensOffset;
            
            vec4 blurredGlass = vec4(NUM_ZERO);
            float total = NUM_ZERO;
            for (int x = -2; x <= 2; x++) {
              for (int y = -2; y <= 2; y++) {
                vec2 offset = vec2(float(x), float(y)) * uBlur / iResolution.xy;
                blurredGlass += texture2D(iChannel0, clamp(lensUV + offset, 0.0, 1.0));
                total += NUM_ONE;
              }
            }
            blurredGlass /= total;

            // Crystal clear transparent glass: subtle clean tint preserving 100% wallpaper vibrancy
            vec4 darkTint = mix(vec4(1.0), vec4(0.94, 0.94, 0.97, 1.0), uDarkMode);
            blurredGlass *= darkTint;

            vec2 defaultLightDir = normalize(vec2(-0.6, 0.7));
            vec2 mouseLightDir = normalize(mouse - (center / iResolution.xy) + vec2(0.0001));
            vec2 lightDir = mix(defaultLightDir, mouseLightDir, uUseMouseLight);

            float surfaceGrad = clamp((clamp(dot(localP, lightDir), NUM_ZERO, 0.4) + 0.1) * 0.7, NUM_ZERO, NUM_ONE) +
                                clamp((clamp(-dot(localP, lightDir), -10.0, 0.4) * rb3 + 0.1) * 0.5, NUM_ZERO, NUM_ONE);

            float lightMod = 1.0;
            vec4 glassWithLight = clamp(blurredGlass + vec4(rb1) * surfaceGrad * 0.42 * lightMod + vec4(rb2) * uLightingIntensity * lightMod, NUM_ZERO, NUM_ONE);
            
            glassWithLight *= (0.94 + 0.06 * smoothstep(0.8, 0.0, roundedBox));

            fragColor = mix(baseColor, glassWithLight, transition);
          }
          break; 
        }
      }
    }
    void main() { mainImage(gl_FragColor, gl_FragCoord.xy); }
  `;

  function init() {
    if (isInitialized) return true;
    canvas = document.getElementById('liquid-glass-canvas');
    if (!canvas) return false;
    try {
      gl = canvas.getContext('webgl', { alpha: false, antialias: false, depth: false }) ||
           canvas.getContext('experimental-webgl');
    } catch (e) {
      gl = null;
    }
    if (!gl) return false;

    const createShader = (type, source) => {
      const shader = gl.createShader(type);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error('[LiquidGlass] Shader compile error:', gl.getShaderInfoLog(shader));
        return null;
      }
      return shader;
    };

    const vs = createShader(gl.VERTEX_SHADER, vsSource);
    const fs = createShader(gl.FRAGMENT_SHADER, fsSource);
    if (!vs || !fs) return false;

    program = gl.createProgram();
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error('[LiquidGlass] Program link error:', gl.getProgramInfoLog(program));
      return false;
    }
    gl.useProgram(program);

    positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(program, 'position');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    uniforms = {
      resolution: gl.getUniformLocation(program, 'iResolution'),
      imageSize: gl.getUniformLocation(program, 'uImageSize'),
      mouse: gl.getUniformLocation(program, 'iMouse'),
      texture: gl.getUniformLocation(program, 'iChannel0'),
      useMouseLight: gl.getUniformLocation(program, 'uUseMouseLight'),
      refraction: gl.getUniformLocation(program, 'uRefraction'),
      blur: gl.getUniformLocation(program, 'uBlur'),
      lightingIntensity: gl.getUniformLocation(program, 'uLightingIntensity'),
      darkMode: gl.getUniformLocation(program, 'uDarkMode'),
      boxCount: gl.getUniformLocation(program, 'uBoxCount'),
      boxes: gl.getUniformLocation(program, 'uBoxes[0]') || gl.getUniformLocation(program, 'uBoxes')
    };

    wallpaperTexture = gl.createTexture();
    setFallbackGradient();

    window.addEventListener('resize', onResize, { passive: true });
    document.addEventListener('mousemove', (e) => {
      if (!isRunning || !canvas) return;
      mouse[0] = e.clientX;
      mouse[1] = canvas.height - e.clientY;
    }, { passive: true });

    isInitialized = true;
    onResize();
    return true;
  }

  function setupTexture(imageSource) {
    if (!gl || !wallpaperTexture) return;
    gl.bindTexture(gl.TEXTURE_2D, wallpaperTexture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, imageSource);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  }

  function setFallbackGradient() {
    if (!gl || !wallpaperTexture) return;
    const off = document.createElement('canvas');
    off.width = 256;
    off.height = 256;
    const ctx = off.getContext('2d');
    if (!ctx) return;

    const curTheme = (typeof state !== 'undefined' && state.settings && state.settings.theme) ? state.settings.theme : 'dark';

    if (curTheme === 'oled') {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, 256, 256);
    } else if (curTheme === 'light') {
      const grad = ctx.createRadialGradient(128, 25, 20, 128, 128, 180);
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(1, '#ebebf0');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);
    } else if (curTheme === 'custom') {
      const customColor = (state.settings && state.settings.customBgColor) ? state.settings.customBgColor : '#212124';
      ctx.fillStyle = customColor;
      ctx.fillRect(0, 0, 256, 256);
    } else if (curTheme === 'glass') {
      const grad = ctx.createRadialGradient(25, 50, 20, 128, 128, 180);
      grad.addColorStop(0, '#201a35');
      grad.addColorStop(0.45, '#151829');
      grad.addColorStop(1, '#0f131c');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);
    } else {
      // 'dark' / default Safari Dark
      const grad = ctx.createRadialGradient(128, 50, 20, 128, 128, 180);
      grad.addColorStop(0, '#28282c');
      grad.addColorStop(1, '#1c1c1e');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 256, 256);
    }
    imgNaturalWidth = 256;
    imgNaturalHeight = 256;
    setupTexture(off);
  }

  function onResize() {
    if (!canvas || !gl) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
      gl.viewport(0, 0, w, h);
    }
  }

  function setWallpaper(wpUrl) {
    if (!wpUrl || wpUrl === 'none') {
      currentWpUrl = '';
      imageObj = null;
      setFallbackGradient();
      return;
    }
    if (wpUrl === currentWpUrl && imageObj) {
      setupTexture(imageObj);
      return;
    }
    currentWpUrl = wpUrl;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      imgNaturalWidth = img.naturalWidth || 1920;
      imgNaturalHeight = img.naturalHeight || 1080;
      imageObj = img;
      setupTexture(img);
    };
    img.onerror = () => {
      imageObj = null;
      setFallbackGradient();
    };
    img.src = wpUrl;
  }

  function updateTileBoundingBoxes() {
    if (!isInitialized || !isRunning || !canvas) return 0;

    boxData.fill(0);
    let count = 0;
    const canvasHeight = canvas.height;

    // 0. Search bar (fixed liquid glass lens)
    const searchBar = document.querySelector('.search-bar-container');
    if (searchBar) {
      searchBar.classList.add('is-liquid-glass');
      if (count < MAX_BOXES && searchBar.offsetParent !== null) {
        const sbRect = searchBar.getBoundingClientRect();
        if (sbRect.width > 0 && sbRect.height > 0 && sbRect.bottom > 0 && sbRect.top < window.innerHeight) {
          const idx = count * 4;
          boxData[idx] = sbRect.left;
          boxData[idx + 1] = canvasHeight - sbRect.bottom;
          boxData[idx + 2] = sbRect.width;
          boxData[idx + 3] = sbRect.height;
          count++;
        }
      }
    }

    // 1. Folder drill-down window (if actively open)
    const isFolderModalOpen = elFolderViewModal && elFolderViewModal.style.display !== 'none';
    if (isFolderModalOpen && count < MAX_BOXES) {
      const windowEl = elFolderViewModal.querySelector('.folder-view-window.is-liquid-glass');
      if (windowEl && windowEl.offsetParent !== null) {
        const fRect = windowEl.getBoundingClientRect();
        if (fRect.width > 0 && fRect.height > 0) {
          const idx = count * 4;
          boxData[idx] = fRect.left;
          boxData[idx + 1] = canvasHeight - fRect.bottom;
          boxData[idx + 2] = fRect.width;
          boxData[idx + 3] = fRect.height;
          count++;
        }
      }
    }

    // 2. Drag Ghost (moving item carried by pointer in 1:1 real-time lock)
    if (dragGhost && count < MAX_BOXES) {
      const isTileGhost = dragGhost.classList.contains('view-tile') ||
        (dragGhost.classList.contains('shortcut-item') &&
        (dragGhost.closest('.view-tile') !== null || (!dragGhost.closest('.view-grid') && !dragGhost.closest('.view-thumb') && getSectionViewMode('favorites') === 'tile')));
      const ghostBox = isTileGhost ? dragGhost : (dragGhost.querySelector('.shortcut-card') || dragGhost);
      if (ghostBox) {
        const gRect = ghostBox.getBoundingClientRect();
        if (gRect.width > 0 && gRect.height > 0) {
          const idx = count * 4;
          boxData[idx] = gRect.left;
          boxData[idx + 1] = canvasHeight - gRect.bottom;
          boxData[idx + 2] = gRect.width;
          boxData[idx + 3] = gRect.height;
          count++;
        }
      }
    }

    // 3. Settings preview cards (ONLY if settings modal is open and visible)
    const isSettingsOpen = elSettingsModal && 
      elSettingsModal.style.display !== 'none' && 
      !elSettingsModal.hasAttribute('hidden') && 
      elSettingsModal.offsetParent !== null;

    if (isSettingsOpen && count < MAX_BOXES) {
      const previews = document.querySelectorAll('#folder-settings-preview.is-liquid-glass, #bookmark-settings-preview.is-liquid-glass');
      for (let i = 0; i < previews.length && count < MAX_BOXES; i++) {
        const pEl = previews[i];
        if (pEl.offsetParent === null) continue;
        const rect = pEl.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          const idx = count * 4;
          boxData[idx] = rect.left;
          boxData[idx + 1] = canvasHeight - rect.bottom;
          boxData[idx + 2] = rect.width;
          boxData[idx + 3] = rect.height;
          count++;
        }
      }
    }

    // 4. Dial Grid Items across main sections (Favorites, Closed Tabs, History)
    // Note: elFolderItemsGrid is intentionally NOT processed here because folder items live
    // inside a scrollable modal overlay and must not draw orphan lenses on the background WebGL canvas.
    const gridsToProcess = [];
    if (elGrid && elGrid.offsetParent !== null) {
      gridsToProcess.push({ grid: elGrid, sectionKey: 'favorites' });
    }
    if (elClosedTabsGrid && elClosedTabsGrid.offsetParent !== null) {
      gridsToProcess.push({ grid: elClosedTabsGrid, sectionKey: 'closedTabs' });
    }
    if (elHistoryGrid && elHistoryGrid.offsetParent !== null) {
      gridsToProcess.push({ grid: elHistoryGrid, sectionKey: 'history' });
    }

    for (let gIdx = 0; gIdx < gridsToProcess.length && count < MAX_BOXES; gIdx++) {
      const gItem = gridsToProcess[gIdx];
      const g = gItem.grid;
      const secKey = gItem.sectionKey;
      const secMode = getSectionViewMode(secKey);
      const isTileView = g.closest('.view-tile') !== null || secMode === 'tile';

      // In tile view, track the rectangular .shortcut-item (260x58)
      // In grid/thumb view, track the squircle / thumbnail .shortcut-card
      const targets = isTileView
        ? g.querySelectorAll('.shortcut-item.is-liquid-glass')
        : g.querySelectorAll('.shortcut-card.is-liquid-glass');

      for (let i = 0; i < targets.length && count < MAX_BOXES; i++) {
        const el = targets[i];
        if (el.closest('.is-placeholder') || el.classList.contains('is-placeholder') || el.classList.contains('dragging')) continue;
        if (isFolderModalOpen && typeof activeFolderOriginEl !== 'undefined' && activeFolderOriginEl && (el === activeFolderOriginEl || activeFolderOriginEl.contains(el))) continue;
        if (el.offsetParent === null) continue;

        const rect = el.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0 || rect.bottom < 0 || rect.top > window.innerHeight) continue;

        const idx = count * 4;
        boxData[idx] = rect.left;
        boxData[idx + 1] = canvasHeight - rect.bottom;
        boxData[idx + 2] = rect.width;
        boxData[idx + 3] = rect.height;
        count++;
      }
    }

    boxCount = count;
    return count;
  }

  function render() {
    if (!isInitialized || !isRunning || !gl || !program) return;
    const activeBoxCount = updateTileBoundingBoxes();
    gl.useProgram(program);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform3f(uniforms.resolution, canvas.width, canvas.height, 1.0);
    gl.uniform2f(uniforms.imageSize, imgNaturalWidth, imgNaturalHeight);
    gl.uniform4f(uniforms.mouse, mouse[0], mouse[1], 0.0, 0.0);
    gl.uniform1f(uniforms.useMouseLight, config.useMouseLight);
    gl.uniform1f(uniforms.refraction, config.refraction);
    gl.uniform1f(uniforms.blur, config.blur);
    gl.uniform1f(uniforms.lightingIntensity, config.bevel);
    gl.uniform1f(uniforms.darkMode, isDarkMode);
    gl.uniform1i(uniforms.boxCount, activeBoxCount);
    if (activeBoxCount > 0 && uniforms.boxes) {
      gl.uniform4fv(uniforms.boxes, boxData.subarray(0, activeBoxCount * 4));
    }
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, wallpaperTexture);
    gl.uniform1i(uniforms.texture, 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  function loop() {
    if (!isRunning) return;
    try {
      render();
    } catch (e) {
      console.error('[LiquidGlass] Render loop error:', e);
    }
    rafId = requestAnimationFrame(loop);
  }

  const onScroll = () => {
    if (isRunning) {
      try {
        render();
      } catch (e) {}
    }
  };

  function start(wpUrl) {
    if (!isInitialized && !init()) { console.warn('[LiquidGlass] WebGL init failed.'); return; }
    isRunning = true;
    if (canvas) { canvas.style.display = 'block'; requestAnimationFrame(() => canvas.style.opacity = '1'); }
    const wpBg = document.getElementById('wallpaper-bg'); if (wpBg) wpBg.style.opacity = '0';
    if (wpUrl) setWallpaper(wpUrl);
    onResize();
    window.addEventListener('scroll', onScroll, { passive: true });
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(loop);
  }

  function stop() {
    isRunning = false;
    window.removeEventListener('scroll', onScroll);
    if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
    if (canvas) { canvas.style.opacity = '0'; setTimeout(() => { if (!isRunning) canvas.style.display = 'none'; }, 350); }
    const wpBg = document.getElementById('wallpaper-bg'); if (wpBg) wpBg.style.opacity = '';
  }

  function setDarkMode(dark) {
    isDarkMode = 0.0;
  }

  function updateConfig(newConfig) {
    if (!newConfig) return;
    if (typeof newConfig.refraction === 'number') config.refraction = newConfig.refraction;
    if (typeof newConfig.blur === 'number') config.blur = newConfig.blur;
    if (typeof newConfig.bevel === 'number') config.bevel = newConfig.bevel;
    if (typeof newConfig.useMouseLight === 'boolean' || typeof newConfig.useMouseLight === 'number') {
      config.useMouseLight = newConfig.useMouseLight ? 1.0 : 0.0;
    }
  }

  return { 
    init, 
    start, 
    stop, 
    setWallpaper, 
    updateLenses: updateTileBoundingBoxes, 
    updateTileBoundingBoxes, 
    render, 
    setDarkMode, 
    updateConfig,
    getConfig: () => ({ ...config }),
    isRunning: () => isRunning 
  };
})();
  
  /**
   * Helper: Normalize URL string (auto-prefix https:// if missing)
   */
  function normalizeUrl(input) {
    if (!input) return '';
    input = input.trim();
    if (!/^https?:\/\//i.test(input)) {
      return 'https://' + input;
    }
    return input;
  }

  /**
   * Helper: Extract clean domain from URL
   */
  function extractDomain(urlStr) {
    try {
      urlStr = normalizeUrl(urlStr);
      const parsed = new URL(urlStr);
      return parsed.hostname.replace(/^www\./i, '');
    } catch {
      return urlStr.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0];
    }
  }

  /**
   * Helper: Derive a human-friendly shortcut title from domain
   */
  function deriveNameFromDomain(domain) {
    if (!domain) return '';
    let base = domain.replace(/^www\./i, '');
    base = base.replace(/\.(com|net|org|es|io|co\.uk|gov|edu|me|dev|app|info|biz|tv|cc)$/i, '');
    const lower = base.toLowerCase();

    // Well-known brands
    if (lower === 'meneame') return 'Menéame';
    if (lower === 'youtube') return 'YouTube';
    if (lower === 'github') return 'GitHub';
    if (lower === 'linkedin') return 'LinkedIn';
    if (lower === 'reddit') return 'Reddit';
    if (lower === 'netflix') return 'Netflix';
    if (lower === 'twitter' || lower === 'x') return 'X';
    if (lower === 'google') return 'Google';
    if (lower === 'wikipedia') return 'Wikipedia';
    if (lower === 'twitch') return 'Twitch';
    if (lower === 'facebook') return 'Facebook';
    if (lower === 'instagram') return 'Instagram';
    if (lower === 'tiktok') return 'TikTok';

    // Capitalize segmented parts
    return base.split(/[-_.]/).filter(Boolean).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  }

  /**
   * Helper: Match known brand
   */
  function getKnownBrand(domain) {
    if (!domain) return null;
    domain = domain.toLowerCase();
    if (domain.includes('gemini.google') || domain === 'gemini.com') return 'gemini';
    if (domain.includes('mail.google') || domain.includes('gmail')) return 'gmail';
    if (domain.includes('youtube') || domain.includes('youtu.be')) return 'youtube';
    if (domain === 'x.com' || domain.includes('twitter')) return 'x';
    if (domain.includes('reddit')) return 'reddit';
    if (domain.includes('netflix')) return 'netflix';
    if (domain.includes('github')) return 'github';
    // Match only main Google search domain, not subdomains like gemini, drive, maps, etc.
    if (/^(?:www\.)?google\.(?:[a-z]{2,3}|co\.[a-z]{2}|com\.[a-z]{2})$/i.test(domain)) return 'google';
    if (domain.includes('amazon')) return 'amazon';
    if (domain.includes('spotify')) return 'spotify';
    if (domain.includes('twitch')) return 'twitch';
    if (domain.includes('wikipedia')) return 'wikipedia';
    return null;
  }

  /**
   * Helper: Get MAX resolution favicon URL (256px)
   */
  function getFaviconUrl(domain) {
    if (!domain) return '';
    const cleanDomain = domain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim();
    // High-resolution Google Social Favicon V2 endpoint (256x256 max)
    return `https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://${encodeURIComponent(cleanDomain)}&size=256`;
  }

  /**
   * Initialize and load data
   */
  async function init() {
    function revealPage() {
      if (elApp) {
        elApp.classList.remove('is-loading');
        elApp.classList.add('is-ready');
      }
    }
    // Safety fallback: reveal page regardless of errors or delay
    setTimeout(revealPage, 200);

    // Reset native browser viewport zoom to 1:1 so text and search bar don't scale
    if (browserAPI && browserAPI.tabs && browserAPI.tabs.setZoom) {
      try {
        browserAPI.tabs.setZoom(1).catch(() => {});
      } catch (e) {}
    }

    try {
      await Promise.race([
        initThumbnailDB(),
        new Promise(r => setTimeout(r, 400))
      ]);
    } catch (e) {
      console.warn('initThumbnailDB error:', e);
    }
    try {
      setupEventListeners();
    } catch (e) {
      console.warn('setupEventListeners error:', e);
    }
    try {
      await Promise.race([
        loadState(),
        new Promise(r => setTimeout(r, 1000))
      ]);
    } catch (e) {
      console.warn('loadState error:', e);
    }
    try {
      setupBookmarkListeners();
    } catch (e) {
      console.warn('setupBookmarkListeners error:', e);
    }
    try {
      applyTranslations(getLanguage());
    } catch (e) {
      console.warn('applyTranslations error:', e);
    }
    try {
      applySettings();
    } catch (e) {
      console.warn('applySettings error:', e);
    }
    try {
      renderFavoriteSectionsBar();
    } catch (e) {}
    try {
      renderGrid();
    } catch (e) {
      console.warn('renderGrid error:', e);
    }
    try {
      updateSectionsUI();
    } catch (e) {}

    try {
      await Promise.race([
        Promise.allSettled([
          loadRecentlyClosedTabs(),
          loadBrowsingHistory()
        ]),
        new Promise(resolve => setTimeout(resolve, 300))
      ]);
    } catch (e) {}

    // Two animation frames ensure browser has computed the grid positions before fading in
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        revealPage();
      });
    });

    setTimeout(revealPage, 350);

    if (state.settings.viewMode === 'thumb') {
      checkAndExtractMissingThumbnails();
    }

    // Process any pending thumbnail captures from recently opened bookmarks
    try {
      getStorageData(['pending_thumb_captures']).then(async (res) => {
        const list = res?.pending_thumb_captures || [];
        if (list.length > 0) {
          await removeStorageData(['pending_thumb_captures']);
          list.forEach(url => {
            const key = getThumbKey(url);
            if (!thumbCache.has(key) || fallbackThumbKeys.has(key)) {
              queueCapture(url, true, false);
            }
          });
        }
      });
    } catch (e) {}

    // Auto-focus search bar on page load if visible
    if (elQuickFilterInput && state.settings.showSearchBar !== false) {
      setTimeout(() => {
        elQuickFilterInput.focus();
      }, 50);
    }
  }

  /**
   * Deduplicate items and folder children
   */
  function deduplicateItems(items) {
    if (!Array.isArray(items)) return items;

    const seenUrls = new Set();
    const seenBookmarkIds = new Set();
    const seenFoldersByTitle = new Map();
    const result = [];

    for (const item of items) {
      if (!item) continue;

      if (item.type === 'folder') {
        // Deduplicate folder's children
        if (Array.isArray(item.children)) {
          const childUrls = new Set();
          const childBmIds = new Set();
          item.children = item.children.filter(child => {
            if (!child || !child.url) return false;
            const k = getThumbKey(child.url);
            if (child.bookmarkId && childBmIds.has(child.bookmarkId)) return false;
            if (k && childUrls.has(k)) return false;
            if (child.bookmarkId) childBmIds.add(child.bookmarkId);
            if (k) childUrls.add(k);
            return true;
          });
        }

        if (item.bookmarkId && seenBookmarkIds.has(item.bookmarkId)) {
          continue;
        }

        const normTitle = (item.title || '').trim().toLowerCase();
        const hasChildren = item.children && item.children.length > 0;

        if (seenFoldersByTitle.has(normTitle)) {
          const existing = seenFoldersByTitle.get(normTitle);
          // If existing is empty and this one has children, adopt the children
          if (!existing.children?.length && hasChildren) {
            existing.children = item.children;
            if (!existing.bookmarkId && item.bookmarkId) {
              existing.bookmarkId = item.bookmarkId;
            }
            continue;
          }
          // If this one is empty, merge bookmarkId to existing if needed and drop duplicate
          if (!item.children?.length) {
            if (!existing.bookmarkId && item.bookmarkId) {
              existing.bookmarkId = item.bookmarkId;
            }
            continue;
          }
        }

        if (item.bookmarkId) seenBookmarkIds.add(item.bookmarkId);
        seenFoldersByTitle.set(normTitle, item);
        result.push(item);
      } else {
        // Shortcut item
        if (item.bookmarkId && seenBookmarkIds.has(item.bookmarkId)) {
          continue;
        }

        const k = item.url ? getThumbKey(item.url) : null;
        if (k && seenUrls.has(k)) {
          if (item.bookmarkId) {
            const prev = result.find(r => r.type !== 'folder' && r.url && getThumbKey(r.url) === k);
            if (prev && !prev.bookmarkId) {
              prev.bookmarkId = item.bookmarkId;
            }
          }
          continue;
        }

        if (item.bookmarkId) seenBookmarkIds.add(item.bookmarkId);
        if (k) seenUrls.add(k);
        result.push(item);
      }
    }

    return result;
  }

  /**
   * Load state from browser.storage.local or import bookmarks if empty
   */
  async function loadState() {
    try {
      const result = await getStorageData(['safari_speeddial_state']);
      if (result && result.safari_speeddial_state) {
        const loaded = result.safari_speeddial_state;
        if (loaded.settings) state.settings = Object.assign(state.settings || {}, loaded.settings);
        if (!state.settings.language) state.settings.language = getDefaultLanguage();
        if (!state.settings.iconStyle) state.settings.iconStyle = 'uniform';
        if (!state.settings.panelLabelSize) state.settings.panelLabelSize = 'normal';
        if (state.settings.wallpaperInitialized === undefined) {
          state.settings.wallpaperInitialized = true;
          if (!state.settings.customWallpaper) {
            state.settings.customWallpaper = 'wallpapers/galaxy.jpg';
          }
        }
        const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];
        if (defaultTitles.includes(state.settings.title)) {
          state.settings.title = '';
        }
        ensureSectionsSettings();

        // Load favorite sections or migrate legacy single items list
        if (Array.isArray(loaded.favoriteSections) && loaded.favoriteSections.length > 0) {
          state.favoriteSections = loaded.favoriteSections.map(sec => ({
            id: sec.id || ('sec_' + Math.random().toString(36).substr(2, 9)),
            title: sec.title || t('favoritesTitle') || 'Favoritos',
            items: deduplicateItems(Array.isArray(sec.items) ? sec.items : [])
          }));
          state.activeFavoriteSectionId = loaded.activeFavoriteSectionId || state.favoriteSections[0].id;
        } else if (Array.isArray(loaded.items)) {
          const defTitle = state.settings.title || t('favoritesTitle') || 'Favoritos';
          state.favoriteSections = [
            {
              id: 'section_default',
              title: defTitle,
              items: deduplicateItems(loaded.items)
            }
          ];
          state.activeFavoriteSectionId = 'section_default';
        }

        ensureFavoriteSections();
        setupStateGetters(state);

        // Safety: If after loading, all sections have 0 items, import from Firefox Bookmarks
        const totalItemsCount = state.favoriteSections.reduce((sum, s) => sum + (Array.isArray(s.items) ? s.items.length : 0), 0);
        if (totalItemsCount === 0) {
          await importFromFirefoxBookmarks();
          ensureFavoriteSections();
        }

        saveState();
      } else {
        // First start: import from Firefox Bookmarks!
        if (!state.settings) state.settings = {};
        if (!state.settings.language) state.settings.language = getDefaultLanguage();
        if (!state.settings.iconStyle) state.settings.iconStyle = 'uniform';
        if (!state.settings.panelLabelSize) state.settings.panelLabelSize = 'normal';
        if (!state.settings.customWallpaper) state.settings.customWallpaper = 'wallpapers/galaxy.jpg';
        state.settings.wallpaperInitialized = true;
        ensureSectionsSettings();
        ensureFavoriteSections();
        setupStateGetters(state);
        await importFromFirefoxBookmarks();
        ensureFavoriteSections();
        saveState();
      }
    } catch (err) {
      console.warn('loadState error:', err);
      ensureSectionsSettings();
      ensureFavoriteSections();
      setupStateGetters(state);
    }
  }

  /**
   * Save state to browser.storage.local
   */
  function saveState() {
    ensureFavoriteSections();
    setStorageData({ safari_speeddial_state: state });
    try {
      if (state && state.settings) {
        localStorage.setItem('safari_speeddial_settings_cache', JSON.stringify(state.settings));
      }
    } catch (e) {}
  }

  /**
   * Import ALL bookmarks and ALL folders from Firefox Bookmarks
   */
  async function importFromFirefoxBookmarks() {
    if (!browserAPI.bookmarks) {
      loadFallbackSampleFavorites();
      return;
    }

    try {
      const tree = await browserAPI.bookmarks.getTree();
      const extracted = [];

      function traverseBookmarkNode(node, isSystemRoot = false) {
        if (!node) return;

        // If it's a URL shortcut
        if (node.url) {
          extracted.push(createShortcutItem(node.title, node.url, node.id));
          return;
        }

        // If it has children
        if (node.children) {
          // If it is root node "root________"
          if (node.id === 'root________') {
            for (const child of node.children) {
              traverseBookmarkNode(child, true);
            }
            return;
          }

          // If it is a known system container: toolbar_____, menu________, unfiled_____, mobile______
          if (isSystemRoot || ['toolbar_____', 'menu________', 'unfiled_____', 'mobile______'].includes(node.id)) {
            for (const child of node.children) {
              traverseBookmarkNode(child, false);
            }
            return;
          }

          // User folder: recursively gather all bookmarks inside
          const folderChildren = [];
          function gatherFolderChildren(fNode) {
            if (!fNode || !fNode.children) return;
            for (const c of fNode.children) {
              if (c.url) {
                folderChildren.push(createShortcutItem(c.title, c.url, c.id));
              } else if (c.children) {
                gatherFolderChildren(c);
              }
            }
          }
          gatherFolderChildren(node);

          if (folderChildren.length > 0 || (node.title && node.title.trim())) {
            extracted.push({
              id: 'folder_' + node.id,
              bookmarkId: node.id,
              type: 'folder',
              title: node.title || 'Carpeta',
              children: folderChildren
            });
          }
        }
      }

      if (tree && tree.length > 0) {
        traverseBookmarkNode(tree[0], true);
      }

      if (extracted.length === 0) {
        loadFallbackSampleFavorites();
      } else {
        state.items = extracted;
        saveState();
      }
    } catch (err) {
      console.warn('Could not import all bookmarks, loading defaults:', err);
      loadFallbackSampleFavorites();
    }
  }

  /**
   * Fallback sample favorites (matching the screenshot) if bookmarks are empty
   */
  function loadFallbackSampleFavorites() {
    state.items = [
      {
        id: 'folder_sample_1',
        type: 'folder',
        title: 'TRABAJO BUSCAR',
        children: [
          createShortcutItem('LinkedIn', 'https://linkedin.com'),
          createShortcutItem('InfoJobs', 'https://infojobs.net'),
          createShortcutItem('Indeed', 'https://indeed.com'),
          createShortcutItem('Glassdoor', 'https://glassdoor.com')
        ]
      },
      {
        id: 'folder_sample_2',
        type: 'folder',
        title: 'Reddit',
        children: [
          createShortcutItem('r/firefox', 'https://reddit.com/r/firefox'),
          createShortcutItem('r/webdev', 'https://reddit.com/r/webdev'),
          createShortcutItem('r/mac', 'https://reddit.com/r/mac')
        ]
      },
      createShortcutItem('Google', 'https://google.com'),
      createShortcutItem('YouTube', 'https://youtube.com'),
      createShortcutItem('Home / X', 'https://x.com'),
      createShortcutItem('Menéame', 'https://meneame.net'),
      createShortcutItem('Wikipedia', 'https://wikipedia.org'),
      createShortcutItem('GitHub', 'https://github.com'),
      createShortcutItem('Gmail', 'https://mail.google.com'),
      createShortcutItem('Netflix', 'https://netflix.com'),
      createShortcutItem('Windows Report', 'https://windowsreport.com'),
      createShortcutItem('Kingston Canvas', 'https://kingston.com')
    ];
    saveState();
  }

  function createShortcutItem(title, url, bookmarkId = null, favIconUrl = null) {
    const domain = extractDomain(url);
    const cleanTitle = title || deriveNameFromDomain(domain) || domain;
    return {
      id: 'sc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      bookmarkId: bookmarkId,
      favIconUrl: favIconUrl || getFaviconUrl(domain),
      type: 'url',
      title: cleanTitle,
      url: normalizeUrl(url),
      domain: domain,
      color: getColorForString(domain || cleanTitle)
    };
  }

  /**
   * Setup Real-Time Firefox Bookmark Listeners
   * "whenever i add a new favourite , display it there automatically."
   */
  function setupBookmarkListeners() {
    if (!browserAPI.bookmarks) return;

    // When bookmark is created in Firefox
    browserAPI.bookmarks.onCreated.addListener((id, bookmarkNode) => {
      const exists = findItemByBookmarkId(id);
      if (exists) return;

      if (bookmarkNode.url) {
        // If an item with this URL already exists without bookmarkId, link it
        const pendingItem = findPendingItemByUrl(bookmarkNode.url);
        if (pendingItem) {
          pendingItem.bookmarkId = id;
          saveState();
          return;
        }

        // If an item with this URL already exists in speed dial, link if needed and skip
        const existingUrlItem = findItemByUrl(bookmarkNode.url);
        if (existingUrlItem) {
          if (!existingUrlItem.bookmarkId) {
            existingUrlItem.bookmarkId = id;
            saveState();
          }
          return;
        }

        // Check if currently being created internally
        const normKey = getThumbKey(bookmarkNode.url);
        if (normKey && internalCreatingShortcutUrls.has(normKey)) {
          return;
        }

        const newItem = createShortcutItem(bookmarkNode.title, bookmarkNode.url, id);
        let addedToFolder = false;
        for (const item of state.items) {
          if (item.type === 'folder' && item.bookmarkId === bookmarkNode.parentId) {
            item.children.push(newItem);
            addedToFolder = true;
            break;
          }
        }
        if (!addedToFolder) {
          state.items.push(newItem);
        }
        saveState();
        renderGrid();
        if (state.activeFolderId) renderFolderView();
      } else {
        // It's a folder
        const pendingFolder = state.items.find(i => i.type === 'folder' && !i.bookmarkId && (i.title === bookmarkNode.title || internalCreatingFolderTitles.has(bookmarkNode.title)));
        if (pendingFolder) {
          pendingFolder.bookmarkId = id;
          if (bookmarkNode.title && pendingFolder.title !== bookmarkNode.title) {
            pendingFolder.title = bookmarkNode.title;
          }
          saveState();
          return;
        }

        if (state.items.some(i => i.type === 'folder' && i.bookmarkId === id)) {
          return;
        }

        if (bookmarkNode.title && internalCreatingFolderTitles.has(bookmarkNode.title)) {
          return;
        }

        state.items.push({
          id: 'folder_' + id,
          bookmarkId: id,
          type: 'folder',
          title: bookmarkNode.title || 'Carpeta',
          children: []
        });
        saveState();
        renderGrid();
      }
    });

    // When bookmark is removed in Firefox
    browserAPI.bookmarks.onRemoved.addListener((id) => {
      let changed = false;
      ensureFavoriteSections();
      for (const sec of state.favoriteSections) {
        sec.items = (sec.items || []).filter(item => {
          if (item.bookmarkId === id) {
            changed = true;
            return false;
          }
          if (item.type === 'folder' && item.children) {
            const prevLen = item.children.length;
            item.children = item.children.filter(child => child.bookmarkId !== id);
            if (item.children.length !== prevLen) changed = true;
          }
          return true;
        });
      }

      if (changed) {
        saveState();
        renderGrid();
        if (state.activeFolderId) renderFolderView();
      }
    });

    // When bookmark is updated in Firefox
    browserAPI.bookmarks.onChanged.addListener((id, changeInfo) => {
      let changed = false;
      const updateItem = (item) => {
        if (item.bookmarkId === id) {
          if (changeInfo.title) item.title = changeInfo.title;
          if (changeInfo.url) {
            item.url = normalizeUrl(changeInfo.url);
            item.domain = extractDomain(item.url);
          }
          changed = true;
        }
      };

      ensureFavoriteSections();
      for (const sec of state.favoriteSections) {
        for (const item of (sec.items || [])) {
          updateItem(item);
          if (item.type === 'folder' && item.children) {
            item.children.forEach(updateItem);
          }
        }
      }

      if (changed) {
        saveState();
        renderGrid();
        if (state.activeFolderId) renderFolderView();
      }
    });
  }

  function getAllFavoriteItems() {
    ensureFavoriteSections();
    const all = [];
    for (const sec of state.favoriteSections) {
      if (Array.isArray(sec.items)) {
        all.push(...sec.items);
      }
    }
    return all;
  }

  function findItemByBookmarkId(bookmarkId) {
    if (!bookmarkId) return null;
    ensureFavoriteSections();
    for (const sec of state.favoriteSections) {
      for (const item of (sec.items || [])) {
        if (item.bookmarkId === bookmarkId) return item;
        if (item.type === 'folder' && item.children) {
          const found = item.children.find(c => c.bookmarkId === bookmarkId);
          if (found) return found;
        }
      }
    }
    return null;
  }

  function findPendingItemByUrl(url) {
    if (!url) return null;
    const targetKey = getThumbKey(url);
    if (!targetKey) return null;
    ensureFavoriteSections();
    for (const sec of state.favoriteSections) {
      for (const item of (sec.items || [])) {
        if (item.type === 'folder' && item.children) {
          const found = item.children.find(c => !c.bookmarkId && c.url && getThumbKey(c.url) === targetKey);
          if (found) return found;
        } else if (item.type !== 'folder' && !item.bookmarkId && item.url && getThumbKey(item.url) === targetKey) {
          return item;
        }
      }
    }
    return null;
  }

  function findItemByUrl(url) {
    if (!url) return null;
    const targetKey = getThumbKey(url);
    if (!targetKey) return null;
    ensureFavoriteSections();
    for (const sec of state.favoriteSections) {
      for (const item of (sec.items || [])) {
        if (item.type === 'folder' && item.children) {
          const found = item.children.find(c => c.url && getThumbKey(c.url) === targetKey);
          if (found) return found;
        } else if (item.type !== 'folder' && item.url && getThumbKey(item.url) === targetKey) {
          return item;
        }
      }
    }
    return null;
  }

  /**
   * Apply settings (CSS variables, themes, title, steppers)
   */
  function applySettings() {
    const s = state.settings;
    const cardSize = (s.cardSize !== undefined) ? s.cardSize : 74;
    const thumbWidth = (s.thumbWidth !== undefined) ? s.thumbWidth : 220;
    const thumbHeight = (s.thumbHeight !== undefined) ? s.thumbHeight : Math.round(thumbWidth * 0.6);
    const cardGap = (s.cardGap !== undefined) ? s.cardGap : 16;
    document.documentElement.style.setProperty('--card-size', cardSize + 'px');
    document.documentElement.style.setProperty('--thumb-width', thumbWidth + 'px');
    document.documentElement.style.setProperty('--thumb-height', thumbHeight + 'px');
    document.documentElement.style.setProperty('--card-gap-x', cardGap + 'px');
    document.documentElement.style.setProperty('--card-gap-y', Math.max(6, cardGap + 6) + 'px');

    if (elDisplaySize) elDisplaySize.textContent = (s.viewMode === 'thumb' ? thumbWidth : cardSize) + 'px';
    if (elDisplayGap) elDisplayGap.textContent = cardGap + 'px';

    const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];
    const isCustomTitle = s.title && !defaultTitles.includes(s.title);
    const effectiveTitle = isCustomTitle ? s.title : t('favoritesTitle');
    elSectionTitle.textContent = effectiveTitle;
    if (elSettingTitleInput) elSettingTitleInput.value = effectiveTitle;
    renderFavoriteSectionsBar();

    // Theme, View mode, Search Centering, and Search Bar Visibility
    const viewMode = s.viewMode || 'grid';
    const theme = s.theme || 'dark';
    const isCustomTheme = (theme === 'custom');
    const customBgColor = s.customBgColor || '#212124';
    const isCustomBgLight = isCustomTheme && isColorLight(customBgColor);

    document.documentElement.style.setProperty('--custom-bg-color', customBgColor);

    let appClasses = `safari-theme-${theme}`;
    if (isCustomBgLight && !appClasses.includes('safari-theme-light')) {
      appClasses += ' safari-theme-light';
    }
    if (s.searchBarCenter) {
      appClasses += ' search-centered';
    }
    if (s.expandScreen) {
      appClasses += ' expand-screen';
    }
    const panelLabelSize = s.panelLabelSize || 'normal';
    if (panelLabelSize === 'small') {
      appClasses += ' panel-labels-small';
    } else if (panelLabelSize === 'large') {
      appClasses += ' panel-labels-large';
    }
    if (s.showSearchBar === false) {
      appClasses += ' hide-search-bar';
    }
    if (elApp.classList.contains('is-loading')) {
      appClasses += ' is-loading';
    }
    if (elApp.classList.contains('is-ready')) {
      appClasses += ' is-ready';
    }
    elApp.className = appClasses;

    // Apply view mode classes per section
    ensureSectionsSettings();
    const favMode = getSectionViewMode('favorites');
    const closedTabsMode = getSectionViewMode('closedTabs');
    const historyMode = getSectionViewMode('history');

    if (elSectionFavorites) {
      elSectionFavorites.classList.remove('view-grid', 'view-tile', 'view-thumb');
      elSectionFavorites.classList.add(`view-${favMode}`);
    }
    if (elSectionClosedTabs) {
      elSectionClosedTabs.classList.remove('view-grid', 'view-tile', 'view-thumb');
      elSectionClosedTabs.classList.add(`view-${closedTabsMode}`);
    }
    if (elSectionHistory) {
      elSectionHistory.classList.remove('view-grid', 'view-tile', 'view-thumb');
      elSectionHistory.classList.add(`view-${historyMode}`);
    }
    if (elFolderViewModal) {
      elFolderViewModal.classList.remove('view-grid', 'view-tile', 'view-thumb');
      elFolderViewModal.classList.add(`view-${favMode}`);
    }

    updateSectionViewModeUI();

    if (elSettingFolderAnimation) {
      elSettingFolderAnimation.checked = (s.folderAnimation !== false);
    }

    if (elSettingCenterSearch) {
      elSettingCenterSearch.checked = !!s.searchBarCenter;
    }
    if (elSettingExpandScreen) {
      elSettingExpandScreen.checked = !!s.expandScreen;
    }
    if (elSettingPanelLabels) {
      elSettingPanelLabels.value = panelLabelSize;
    }
    if (elSettingShowSearch) {
      elSettingShowSearch.checked = (s.showSearchBar !== false);
    }
    if (elSettingIconStyle) {
      elSettingIconStyle.value = s.iconStyle || 'uniform';
    }

    // Update view mode toggle buttons & unified dropdown button (Icon only on trigger button)
    const activeCfg = VIEW_MODE_CONFIG[viewMode] || VIEW_MODE_CONFIG.grid;
    if (elViewModeActiveIcon) elViewModeActiveIcon.innerHTML = activeCfg.svg;
    if (elViewModeActiveLabel) elViewModeActiveLabel.textContent = '';
    if (elViewModeDropdownBtn) elViewModeDropdownBtn.title = t('changeView');

    if (elBtnViewGrid) elBtnViewGrid.classList.toggle('active', viewMode === 'grid');
    if (elBtnViewTile) elBtnViewTile.classList.toggle('active', viewMode === 'tile');
    if (elBtnViewThumb) elBtnViewThumb.classList.toggle('active', viewMode === 'thumb');

    document.querySelectorAll('.theme-option').forEach(opt => {
      opt.classList.toggle('active', opt.dataset.theme === theme);
    });

    if (elThemeCustomSwatch) {
      if (isCustomTheme && s.customBgColor) {
        elThemeCustomSwatch.style.background = s.customBgColor;
      } else {
        elThemeCustomSwatch.style.background = '';
      }
    }
    if (elInputCustomBgColor && s.customBgColor) {
      elInputCustomBgColor.value = s.customBgColor;
    }

    // Custom Wallpaper & Gallery Presets
    const currentWp = s.customWallpaper || '';
    const isGalaxy = currentWp === 'wallpapers/galaxy.jpg';
    const isAurora = currentWp === 'wallpapers/aurora.jpg';
    const isCustomWp = !isGalaxy && !isAurora && !!currentWp && currentWp !== 'none';

    if (elWallpaperBg) {
      if (currentWp && currentWp !== 'none') {
        elWallpaperBg.style.backgroundImage = 'url(' + currentWp + ')';
        elWallpaperBg.classList.add('has-wallpaper');
      } else {
        elWallpaperBg.style.backgroundImage = '';
        elWallpaperBg.classList.remove('has-wallpaper');
      }
    }
    if (typeof LiquidGlassEngine !== 'undefined' && LiquidGlassEngine.setWallpaper) {
      LiquidGlassEngine.setWallpaper(currentWp);
    }

    if (elWpPresetGalaxy) elWpPresetGalaxy.classList.toggle('active', isGalaxy);
    if (elWpPresetAurora) elWpPresetAurora.classList.toggle('active', isAurora);
    if (elWpPresetCustom) {
      if (isCustomWp) {
        elWpPresetCustom.style.display = 'flex';
        elWpPresetCustom.classList.add('active');
        elWpPresetCustom.dataset.customWp = currentWp;
        if (elWpPresetCustomImg) {
          elWpPresetCustomImg.style.backgroundImage = 'url(' + currentWp + ')';
        }
      } else {
        elWpPresetCustom.classList.remove('active');
        if (!elWpPresetCustom.dataset.customWp && (!elWpPresetCustomImg || !elWpPresetCustomImg.style.backgroundImage)) {
          elWpPresetCustom.style.display = 'none';
        }
      }
    }
    if (elBtnRemoveWallpaper) {
      elBtnRemoveWallpaper.style.display = (currentWp && currentWp !== 'none') ? 'inline-flex' : 'none';
    }

    const isThemeLight = elApp ? elApp.classList.contains('safari-theme-light') : false;

    // Folder Background Color & Dynamic Contrast
    const isLiquidFolder = s.folderColor === 'liquid-glass';
    const defaultFolderColor = isThemeLight ? 'rgba(246, 246, 248, 0.94)' : '#3a3a3e';
    const folderColor = (s.folderColor && s.folderColor !== '#3a3a3e') ? s.folderColor : (isThemeLight ? defaultFolderColor : '#3a3a3e');

    if (document.documentElement && document.documentElement.classList) {
      document.documentElement.classList.toggle('has-liquid-glass-folders', isLiquidFolder);
    }
    if (elApp && elApp.classList) elApp.classList.toggle('has-liquid-glass-folders', isLiquidFolder);

    if (isLiquidFolder) {
      document.documentElement.style.setProperty('--folder-bg', 'rgba(255, 255, 255, 0.05)');
    } else {
      document.documentElement.style.setProperty('--folder-bg', folderColor);
    }

    const isFolderLight = isLiquidFolder ? isThemeLight : isColorLight(folderColor, isThemeLight);
    const folderFg = isFolderLight ? '#1c1c1e' : '#ffffff';
    const folderSubFg = isFolderLight ? 'rgba(60, 60, 67, 0.78)' : 'rgba(255, 255, 255, 0.78)';
    const folderBorder = isLiquidFolder ? 'rgba(255, 255, 255, 0.4)' : (isFolderLight ? 'rgba(0, 0, 0, 0.14)' : 'rgba(255, 255, 255, 0.16)');
    const folderBtnBg = isLiquidFolder ? 'rgba(255, 255, 255, 0.2)' : (isFolderLight ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.18)');
    const folderBtnBorder = isLiquidFolder ? 'rgba(255, 255, 255, 0.35)' : (isFolderLight ? 'rgba(0, 0, 0, 0.14)' : 'rgba(255, 255, 255, 0.22)');
    const folderBtnHover = isLiquidFolder ? 'rgba(255, 255, 255, 0.32)' : (isFolderLight ? 'rgba(0, 0, 0, 0.16)' : 'rgba(255, 255, 255, 0.32)');
    const folderBtnHoverBorder = isLiquidFolder ? 'rgba(255, 255, 255, 0.5)' : (isFolderLight ? 'rgba(0, 0, 0, 0.22)' : 'rgba(255, 255, 255, 0.4)');
    const folderBtnActive = isLiquidFolder ? 'rgba(255, 255, 255, 0.15)' : (isFolderLight ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.12)');

    document.documentElement.style.setProperty('--folder-fg', folderFg);
    document.documentElement.style.setProperty('--folder-sub-fg', folderSubFg);
    document.documentElement.style.setProperty('--folder-border', folderBorder);
    document.documentElement.style.setProperty('--folder-btn-bg', folderBtnBg);
    document.documentElement.style.setProperty('--folder-btn-border', folderBtnBorder);
    document.documentElement.style.setProperty('--folder-btn-hover', folderBtnHover);
    document.documentElement.style.setProperty('--folder-btn-hover-border', folderBtnHoverBorder);
    document.documentElement.style.setProperty('--folder-btn-active', folderBtnActive);

    const folderWinEl = document.querySelector('.folder-view-window');
    if (folderWinEl) {
      folderWinEl.classList.toggle('is-light', isFolderLight);
      folderWinEl.classList.toggle('is-dark', !isFolderLight);
      folderWinEl.classList.toggle('is-liquid-glass', isLiquidFolder);
    }

    if (elFolderSettingsPreview) {
      elFolderSettingsPreview.classList.toggle('is-liquid-glass', isLiquidFolder);
      elFolderSettingsPreview.style.backgroundColor = isLiquidFolder ? '' : folderColor;
    }
    if (elFolderCustomColorInput) {
      elFolderCustomColorInput.value = (folderColor.startsWith('#') && folderColor.length === 7) ? folderColor : '#3a3a3e';
    }
    if (elFolderColorPalette) {
      elFolderColorPalette.querySelectorAll('.folder-color-option').forEach(opt => {
        opt.classList.toggle('active', (opt.dataset.color || '').toLowerCase() === (s.folderColor || '#3a3a3e').toLowerCase());
      });
    }

    // Bookmark Background Color & "Mismo color que carpetas"
    const sameColor = !!s.bookmarkSameColorAsFolder;
    if (elSettingBookmarkSameColor) {
      elSettingBookmarkSameColor.checked = sameColor;
    }
    if (elBookmarkColorRow) {
      elBookmarkColorRow.style.opacity = sameColor ? '0.4' : '1';
      elBookmarkColorRow.style.pointerEvents = sameColor ? 'none' : 'auto';
    }

    let effectiveBookmarkColor;
    const defaultCardColor = isThemeLight ? '#ffffff' : '#2a2a2d';

    if (sameColor) {
      effectiveBookmarkColor = folderColor;
    } else if (s.bookmarkColor && s.bookmarkColor !== 'default') {
      effectiveBookmarkColor = s.bookmarkColor;
    } else if (isLiquidFolder) {
      effectiveBookmarkColor = 'liquid-glass';
    } else {
      effectiveBookmarkColor = defaultCardColor;
    }

    const isLiquidBookmark = effectiveBookmarkColor === 'liquid-glass';
    const hasAnyLiquid = true; // Search bar is ALWAYS liquid glass!
    if (document.documentElement && document.documentElement.classList) {
      document.documentElement.classList.toggle('has-liquid-glass-bookmarks', isLiquidBookmark);
      document.documentElement.classList.toggle('has-liquid-glass', true);
    }
    if (elApp && elApp.classList) {
      elApp.classList.toggle('has-liquid-glass-bookmarks', isLiquidBookmark);
      elApp.classList.toggle('has-liquid-glass', true);
    }

    if (isLiquidBookmark) {
      document.documentElement.style.setProperty('--card-bg', 'rgba(255, 255, 255, 0.05)');
    } else {
      document.documentElement.style.setProperty('--card-bg', effectiveBookmarkColor);
    }

    const isLight = isLiquidBookmark ? isThemeLight : isColorLight(effectiveBookmarkColor);
    const cardFg = isLight ? '#1d1d1f' : '#ffffff';
    const cardBorder = isLiquidBookmark ? 'rgba(255, 255, 255, 0.42)' : (isLight ? 'rgba(0, 0, 0, 0.12)' : 'rgba(255, 255, 255, 0.1)');
    document.documentElement.style.setProperty('--card-fg', cardFg);
    document.documentElement.style.setProperty('--card-border', cardBorder);

    if (elBookmarkSettingsPreview) {
      elBookmarkSettingsPreview.classList.toggle('is-liquid-glass', isLiquidBookmark);
      elBookmarkSettingsPreview.style.backgroundColor = isLiquidBookmark ? '' : effectiveBookmarkColor;
      elBookmarkSettingsPreview.style.border = isLiquidBookmark ? '' : (isLight ? '1px solid rgba(0,0,0,0.15)' : '1px solid rgba(255,255,255,0.1)');
    }
    if (elBookmarkPreviewIcon) {
      elBookmarkPreviewIcon.style.color = cardFg;
    }
    if (elBookmarkCustomColorInput) {
      elBookmarkCustomColorInput.value = (effectiveBookmarkColor.startsWith('#') && effectiveBookmarkColor.length === 7) ? effectiveBookmarkColor : '#2a2a2d';
    }
    if (elBookmarkColorPalette) {
      const activeColorKey = sameColor ? folderColor.toLowerCase() : ((s.bookmarkColor && s.bookmarkColor !== 'default') ? s.bookmarkColor.toLowerCase() : (isLiquidFolder ? 'liquid-glass' : 'default'));
      elBookmarkColorPalette.querySelectorAll('.folder-color-option').forEach(opt => {
        const optColor = (opt.dataset.color || '').toLowerCase();
        opt.classList.toggle('active', optColor === activeColorKey);
      });
    }

    // ── Liquid Glass WebGL Engine & Configuration ─────────────────────────
    const lg = s.liquidGlass || {
      refraction: 0.08,
      blur: 0.8,
      bevel: 0.35,
      useMouseLight: false
    };
    LiquidGlassEngine.updateConfig(lg);

    if (elSettingLiquidRefraction) {
      elSettingLiquidRefraction.value = lg.refraction;
      if (elDisplayLiquidRefraction) elDisplayLiquidRefraction.textContent = Number(lg.refraction).toFixed(2);
    }
    if (elSettingLiquidBlur) {
      elSettingLiquidBlur.value = lg.blur;
      if (elDisplayLiquidBlur) elDisplayLiquidBlur.textContent = Number(lg.blur).toFixed(1);
    }
    if (elSettingLiquidBevel) {
      elSettingLiquidBevel.value = lg.bevel;
      if (elDisplayLiquidBevel) elDisplayLiquidBevel.textContent = Number(lg.bevel).toFixed(2);
    }
    if (elSettingLiquidMouseLight) {
      elSettingLiquidMouseLight.checked = !!lg.useMouseLight;
    }

    if (hasAnyLiquid) {
      const wpUrl = (s.customWallpaper && s.customWallpaper !== 'none')
        ? s.customWallpaper
        : '';
      LiquidGlassEngine.setDarkMode(false);
      LiquidGlassEngine.start(wpUrl);
    } else {
      LiquidGlassEngine.stop();
    }

    updateSectionsUI();
    if (state.activeFolderId) renderFolderView();
  }

  function toggleViewModeDropdown(open) {
    if (!elViewModeMenu) return;
    const shouldOpen = (open !== undefined) ? open : (elViewModeMenu.style.display === 'none');
    if (shouldOpen) {
      elViewModeMenu.style.display = 'flex';
      if (elViewModeDropdownWrap) elViewModeDropdownWrap.classList.add('open');
      if (elViewModeDropdownBtn) elViewModeDropdownBtn.setAttribute('aria-expanded', 'true');
    } else {
      elViewModeMenu.style.display = 'none';
      if (elViewModeDropdownWrap) elViewModeDropdownWrap.classList.remove('open');
      if (elViewModeDropdownBtn) elViewModeDropdownBtn.setAttribute('aria-expanded', 'false');
    }
  }

  function setViewMode(mode) {
    state.settings.viewMode = mode;
    ensureSectionsSettings();
    ['favorites', 'closedTabs', 'history'].forEach(key => {
      if (state.settings.sections[key]) {
        state.settings.sections[key].viewMode = mode;
      }
    });
    applySettings();
    saveState();
    renderGrid();
    if (lastClosedTabsSessions) {
      renderRecentlyClosedTabs(lastClosedTabsSessions);
    } else {
      loadRecentlyClosedTabs();
    }
    if (lastHistoryResults) {
      renderBrowsingHistory(lastHistoryResults);
    } else {
      loadBrowsingHistory();
    }
    if (mode === 'thumb') {
      checkAndExtractMissingThumbnails();
    }
  }

  /**
   * Favorite Sections Bar & Tab Management
   */
  function renderFavoriteSectionsBar() {
    if (!elFavoritesTabBar) return;
    ensureFavoriteSections();
    elFavoritesTabBar.innerHTML = '';

    const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];

    state.favoriteSections.forEach((section) => {
      const tab = document.createElement('div');
      tab.className = 'fav-section-tab';
      tab.dataset.sectionId = section.id;
      tab.setAttribute('role', 'tab');
      tab.draggable = true;

      const isActive = (section.id === state.activeFavoriteSectionId);
      tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
      if (isActive) {
        tab.classList.add('is-active');
      }

      // Section display title
      let displayTitle = section.title;
      if (!displayTitle || defaultTitles.includes(displayTitle)) {
        displayTitle = t('favoritesTitle');
      }

      const titleSpan = document.createElement('span');
      titleSpan.className = 'fav-section-tab-title';
      titleSpan.textContent = displayTitle;
      tab.appendChild(titleSpan);

      // Left-click: switch active section
      tab.addEventListener('click', () => {
        if (tab.querySelector('.fav-section-title-input')) return;
        if (state.activeFavoriteSectionId !== section.id) {
          switchFavoriteSection(section.id);
        }
      });

      // Double-click: inline rename
      tab.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        startInlineRename(section.id, tab);
      });

      // Right-click: context menu
      tab.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        showTabContextMenu(e.clientX, e.clientY, section.id);
      });

      // Drag and drop reordering left/right
      setupTabDragAndDrop(tab, section.id);

      elFavoritesTabBar.appendChild(tab);
    });

    if (elSectionTitle) {
      const activeSec = getActiveFavoriteSection();
      elSectionTitle.textContent = activeSec ? (activeSec.title || t('favoritesTitle')) : t('favoritesTitle');
    }
  }

  function setupTabDragAndDrop(tabEl, sectionId) {
    tabEl.addEventListener('dragstart', (e) => {
      if (tabEl.querySelector('.fav-section-title-input')) {
        e.preventDefault();
        return;
      }
      draggedSectionId = sectionId;
      tabEl.classList.add('is-dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', `section:${sectionId}`);
    });

    tabEl.addEventListener('dragend', () => {
      tabEl.classList.remove('is-dragging');
      document.querySelectorAll('.fav-section-tab').forEach(el => {
        el.classList.remove('drag-over-left', 'drag-over-right', 'tab-card-drop-target');
      });
      draggedSectionId = null;
    });

    tabEl.addEventListener('dragover', (e) => {
      // If a bookmark card is dragged over this tab
      if (dragData.sourceId) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        tabEl.classList.add('tab-card-drop-target');
        return;
      }

      // If a section tab is being reordered left / right
      if (!draggedSectionId || draggedSectionId === sectionId) return;

      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      const rect = tabEl.getBoundingClientRect();
      const isLeft = e.clientX < (rect.left + rect.width / 2);

      tabEl.classList.toggle('drag-over-left', isLeft);
      tabEl.classList.toggle('drag-over-right', !isLeft);
    });

    tabEl.addEventListener('dragleave', () => {
      tabEl.classList.remove('drag-over-left', 'drag-over-right', 'tab-card-drop-target');
    });

    tabEl.addEventListener('drop', (e) => {
      e.preventDefault();
      tabEl.classList.remove('drag-over-left', 'drag-over-right', 'tab-card-drop-target');

      // Drop card onto section tab -> move bookmark into that section
      if (dragData.sourceId) {
        const cardId = dragData.sourceId;
        const folderId = dragData.sourceFolderId;
        moveBookmarkToSection(cardId, folderId, sectionId);
        return;
      }

      // Drop section tab to reorder left / right
      if (!draggedSectionId || draggedSectionId === sectionId) return;

      const fromIdx = state.favoriteSections.findIndex(s => s.id === draggedSectionId);
      if (fromIdx === -1) return;

      const rect = tabEl.getBoundingClientRect();
      const isLeft = e.clientX < (rect.left + rect.width / 2);

      const [movedSec] = state.favoriteSections.splice(fromIdx, 1);
      let toIdx = state.favoriteSections.findIndex(s => s.id === sectionId);
      const insertIdx = isLeft ? toIdx : toIdx + 1;
      state.favoriteSections.splice(insertIdx, 0, movedSec);

      saveState();
      renderFavoriteSectionsBar();
    });
  }

  function moveBookmarkToSection(cardId, sourceFolderId, targetSectionId) {
    if (!cardId || !targetSectionId) return;
    ensureFavoriteSections();
    const targetSec = state.favoriteSections.find(s => s.id === targetSectionId);
    if (!targetSec) return;

    let itemToMove = null;
    if (sourceFolderId) {
      const parentFolder = state.items.find(i => i.id === sourceFolderId);
      if (parentFolder && parentFolder.children) {
        const idx = parentFolder.children.findIndex(c => c.id === cardId);
        if (idx !== -1) {
          itemToMove = parentFolder.children.splice(idx, 1)[0];
        }
      }
    } else {
      const idx = state.items.findIndex(i => i.id === cardId);
      if (idx !== -1) {
        itemToMove = state.items.splice(idx, 1)[0];
      }
    }

    if (!itemToMove) return;

    if (!targetSec.items) targetSec.items = [];
    targetSec.items.push(itemToMove);

    saveState();
    renderGrid();
    if (state.activeFolderId) renderFolderView();
    showToast(t('toastAddedFavorite', { title: itemToMove.title || targetSec.title }));
  }

  function startInlineRename(sectionId, tabEl) {
    const section = state.favoriteSections.find(s => s.id === sectionId);
    if (!section) return;

    const titleSpan = tabEl.querySelector('.fav-section-tab-title');
    if (!titleSpan) return;
    if (tabEl.querySelector('.fav-section-title-input')) return;

    const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];
    const currentTitle = (!section.title || defaultTitles.includes(section.title)) ? t('favoritesTitle') : section.title;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'fav-section-title-input';
    input.value = currentTitle;
    input.maxLength = 40;

    titleSpan.style.display = 'none';
    tabEl.appendChild(input);
    input.focus();
    input.select();

    let committed = false;
    const commit = () => {
      if (committed) return;
      committed = true;
      const newTitle = input.value.trim();
      if (newTitle && newTitle !== currentTitle) {
        section.title = newTitle;
        if (section.id === state.activeFavoriteSectionId) {
          state.settings.title = newTitle;
          if (elSettingTitleInput) elSettingTitleInput.value = newTitle;
        }
        saveState();
      }
      renderFavoriteSectionsBar();
    };

    const cancel = () => {
      if (committed) return;
      committed = true;
      renderFavoriteSectionsBar();
    };

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        commit();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        cancel();
      }
    });

    input.addEventListener('blur', () => {
      commit();
    });

    input.addEventListener('click', (e) => e.stopPropagation());
    input.addEventListener('dblclick', (e) => e.stopPropagation());
  }

  function addNewFavoriteSection() {
    ensureFavoriteSections();
    const count = state.favoriteSections.length + 1;
    const newId = 'sec_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const defaultName = `${t('newSectionDefaultTitle') || 'Nueva sección'} ${count}`;

    const newSection = {
      id: newId,
      title: defaultName,
      items: []
    };

    state.favoriteSections.push(newSection);
    state.activeFavoriteSectionId = newId;
    state.activeFolderId = null;
    saveState();
    renderFavoriteSectionsBar();
    renderGrid();

    // Automatically trigger inline rename on the newly created tab
    setTimeout(() => {
      const newTabEl = elFavoritesTabBar?.querySelector(`.fav-section-tab[data-section-id="${newId}"]`);
      if (newTabEl) {
        startInlineRename(newId, newTabEl);
      }
    }, 40);
  }

  function switchFavoriteSection(sectionId) {
    ensureFavoriteSections();
    if (state.activeFavoriteSectionId === sectionId) return;
    state.activeFavoriteSectionId = sectionId;
    state.activeFolderId = null;
    saveState();
    renderFavoriteSectionsBar();
    renderGrid();
  }

  function deleteFavoriteSection(sectionId) {
    ensureFavoriteSections();
    if (state.favoriteSections.length <= 1) return;

    const section = state.favoriteSections.find(s => s.id === sectionId);
    if (!section) return;

    const defaultTitles = ['Favoritos', 'Favorites', 'Favoriten', 'Закладки', '收藏'];
    const sectionDisplayTitle = (!section.title || defaultTitles.includes(section.title)) ? t('favoritesTitle') : section.title;
    const msg = (t('confirmDeleteSection') || '¿Eliminar la sección "{title}" y todos sus marcadores?').replace('{title}', sectionDisplayTitle);
    if (!confirm(msg)) return;

    const idx = state.favoriteSections.findIndex(s => s.id === sectionId);
    if (idx !== -1) {
      state.favoriteSections.splice(idx, 1);
    }

    if (state.activeFavoriteSectionId === sectionId) {
      state.activeFavoriteSectionId = state.favoriteSections[Math.max(0, idx - 1)].id;
      state.activeFolderId = null;
    }

    saveState();
    renderFavoriteSectionsBar();
    renderGrid();
    showToast(t('toastSectionDeleted'));
  }

  /**
   * Render the main Speed Dial grid
   */
  function renderGrid() {
    elGrid.innerHTML = '';

    if (state.items.length === 0) {
      elEmptyState.style.display = 'flex';
      return;
    } else {
      elEmptyState.style.display = 'none';
    }

    if (!currentSearchQuery) {
      elGrid.classList.remove('has-empty-hint');
      elGrid.style.removeProperty('display');
      elGrid.style.removeProperty('flex-direction');
      elGrid.style.removeProperty('width');
      for (let i = 0; i < state.items.length; i++) {
        const item = state.items[i];
        const cardEl = renderItemElement(item, i, null);
        elGrid.appendChild(cardEl);
      }
      requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
      return;
    }

    // Live search active: search root shortcuts and shortcuts inside folders
    const matches = [];
    for (let i = 0; i < state.items.length; i++) {
      const item = state.items[i];
      if (item.type === 'folder') {
        const folderTitle = (item.title || '').toLowerCase();
        if (folderTitle.includes(currentSearchQuery)) {
          matches.push({ item, parentFolderId: null });
        }
        for (const child of (item.children || [])) {
          const childTitle = (child.title || child.domain || '').toLowerCase();
          const childUrl = (child.url || '').toLowerCase();
          if (childTitle.includes(currentSearchQuery) || childUrl.includes(currentSearchQuery)) {
            matches.push({ item: child, parentFolderId: item.id, parentFolderTitle: item.title });
          }
        }
      } else {
        const title = (item.title || item.domain || '').toLowerCase();
        const url = (item.url || '').toLowerCase();
        if (title.includes(currentSearchQuery) || url.includes(currentSearchQuery)) {
          matches.push({ item, parentFolderId: null });
        }
      }
    }

    if (matches.length === 0) {
      elGrid.classList.add('has-empty-hint');
      elGrid.style.display = 'flex';
      elGrid.style.flexDirection = 'column';
      elGrid.style.width = '100%';
      const notice = document.createElement('div');
      notice.className = 'section-empty-hint';
      notice.textContent = (t('searchNoMatchesFav') || 'No favorites match "{query}"').replace('{query}', currentSearchQuery);
      elGrid.appendChild(notice);
    } else {
      elGrid.classList.remove('has-empty-hint');
      elGrid.style.removeProperty('display');
      elGrid.style.removeProperty('flex-direction');
      elGrid.style.removeProperty('width');
      matches.forEach((m, idx) => {
        const cardEl = renderItemElement(m.item, idx, m.parentFolderId);
        if (m.parentFolderTitle) {
          const urlEl = cardEl.querySelector('.shortcut-url');
          if (urlEl) {
            urlEl.textContent = `📁 ${m.parentFolderTitle} · ${urlEl.textContent}`;
          }
        }
        elGrid.appendChild(cardEl);
      });
    }
    // Update WebGL lens bounding boxes after DOM is painted
    requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
  }

  /**
   * Render single item element (Card + Label)
   */
  function renderItemElement(item, index, parentFolderId = null) {
    const favViewMode = getSectionViewMode('favorites');
    const itemContainer = document.createElement('div');
    itemContainer.className = 'shortcut-item';
    itemContainer.dataset.id = item.id;
    itemContainer.dataset.type = item.type;
    if (item.url) itemContainer.dataset.url = item.url;
    if (parentFolderId) itemContainer.dataset.parentFolderId = parentFolderId;

    const card = document.createElement('div');
    card.className = 'shortcut-card';

    const isFolder = item.type === 'folder';
    const sameColor = !!state.settings.bookmarkSameColorAsFolder;
    const isFolderLiquid = (state.settings.folderColor === 'liquid-glass');
    const isBookmarkLiquid = (state.settings.bookmarkColor === 'liquid-glass') || (isFolderLiquid && (state.settings.bookmarkColor === 'default' || !state.settings.bookmarkColor));
    const isLiquid = isFolder ? isFolderLiquid : (sameColor ? isFolderLiquid : isBookmarkLiquid);

    if (isLiquid) {
      card.classList.add('is-liquid-glass');
      if (favViewMode === 'tile') {
        itemContainer.classList.add('is-liquid-glass');
      }
    }
    if (isFolder) {
      card.classList.add('folder-card');
      card.appendChild(createFolderPreviewElement(item));
    } else {
      if (favViewMode === 'thumb') {
        const domain = item.domain || extractDomain(item.url);
        renderThumbnailCardInner(card, item.url, item.title, domain, getKnownBrand(domain), item.favIconUrl, item.customThumbnail);
      } else {
        card.appendChild(createShortcutCardContent(item, card));
      }
    }

    const infoWrap = document.createElement('div');
    infoWrap.className = 'shortcut-info';

    if (favViewMode === 'thumb' && item.type !== 'folder') {
      const fav = document.createElement('img');
      fav.className = 'shortcut-info-favicon';
      fav.src = item.favIconUrl || getFaviconUrl(item.domain || extractDomain(item.url));
      fav.alt = '';
      infoWrap.appendChild(fav);
    }

    const label = document.createElement('div');
    label.className = 'shortcut-label';
    label.textContent = item.title || item.domain || t('favoritesTitle');
    label.title = item.title || item.url || '';

    const urlEl = document.createElement('div');
    urlEl.className = 'shortcut-url';
    if (item.type === 'folder') {
      const count = (item.children || []).length;
      const countWord = count === 1 ? t('itemSingular') : t('itemPlural');
      urlEl.textContent = `${count} ${countWord}`;
    } else {
      urlEl.textContent = item.url ? item.url.replace(/^https?:\/\//i, '').replace(/\/$/, '') : (item.domain || '');
    }

    infoWrap.appendChild(label);
    infoWrap.appendChild(urlEl);

    itemContainer.appendChild(card);
    itemContainer.appendChild(infoWrap);

    // Click handler
    itemContainer.addEventListener('click', (e) => {
      if (preventNextClick) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (e.target.closest('.quick-star-btn')) return;
      if (item.type === 'folder') {
        openFolderView(item.id, card);
      } else {
        openBookmark(item.url, e.metaKey || e.ctrlKey);
      }
    });

    // Middle click opens new tab
    itemContainer.addEventListener('auxclick', (e) => {
      if (preventNextClick) return;
      if (e.button === 1 && item.type === 'url') {
        openBookmark(item.url, true);
      }
    });

    // Context menu
    itemContainer.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showContextMenu(e.clientX, e.clientY, item, parentFolderId, 'favorites');
    });

    return itemContainer;
  }

  /**
   * Render Folder Mini-Grid Preview (Replicating Safari 2x2 folder preview)
   */
  function createFolderPreviewElement(folderItem) {
    const children = folderItem.children || [];
    const grid = document.createElement('div');
    grid.className = 'folder-mini-grid';

    if (children.length === 0) {
      for (let i = 0; i < 4; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'folder-mini-item is-empty-placeholder';
        grid.appendChild(emptyCell);
      }
      return grid;
    }

    const isThumbMode = (getSectionViewMode('favorites') === 'thumb');
    const miniItems = children.slice(0, 4);

    for (const child of miniItems) {
      const cell = document.createElement('div');
      cell.className = 'folder-mini-item';
      if (child.url) {
        cell.dataset.childThumbUrl = child.url;
      }

      if (isThumbMode) {
        const key = getThumbKey(child.url);
        const cachedThumb = child.customThumbnail || (key ? thumbCache.get(key) : null);
        if (child.customThumbnail) {
          cell.dataset.hasCustomThumb = 'true';
        }
        if (cachedThumb) {
          const img = document.createElement('img');
          img.className = 'folder-mini-thumb-img';
          img.decoding = 'async';
          img.loading = 'lazy';
          img.src = cachedThumb;
          img.alt = '';
          cell.appendChild(img);
        } else {
          cell.classList.add('is-pending-thumb');
          const domain = child.domain || extractDomain(child.url);
          const brand = getKnownBrand(domain);
          if (brand && BRAND_SVGS[brand]) {
            cell.innerHTML = BRAND_SVGS[brand];
          } else {
            const faviconUrl = getFaviconUrl(domain);
            const img = document.createElement('img');
            img.src = faviconUrl;
            img.alt = '';
            img.onerror = () => {
              cell.innerHTML = `<span>${(child.title || domain || 'S').charAt(0).toUpperCase()}</span>`;
              cell.style.backgroundColor = child.color || getColorForString(domain);
            };
            cell.appendChild(img);
          }
        }
      } else {
        const brand = getKnownBrand(child.domain);
        if (brand && BRAND_SVGS[brand]) {
          cell.innerHTML = BRAND_SVGS[brand];
        } else {
          const domain = child.domain || extractDomain(child.url);
          const faviconUrl = getFaviconUrl(domain);
          const img = document.createElement('img');
          img.src = faviconUrl;
          img.alt = '';
          img.onerror = () => {
            cell.innerHTML = `<span>${(child.title || domain || 'S').charAt(0).toUpperCase()}</span>`;
            cell.style.backgroundColor = child.color || getColorForString(domain);
          };
          cell.appendChild(img);
        }
      }
      grid.appendChild(cell);
    }

    return grid;
  }

  /**
   * Create inner card content for a shortcut
   */
  function createShortcutCardContent(item, cardEl) {
    const domain = item.domain || extractDomain(item.url);
    const brand = getKnownBrand(domain);
    const iconStyle = state.settings.iconStyle || 'uniform';

    if (brand && BRAND_SVGS[brand]) {
      if (iconStyle === 'fullbleed') {
        cardEl.classList.add('full-bleed');
      } else {
        cardEl.classList.add('icon-uniform');
      }
      const wrap = document.createElement('div');
      wrap.innerHTML = BRAND_SVGS[brand];
      return wrap.firstElementChild;
    }

    if (iconStyle !== 'fullbleed') {
      cardEl.classList.add('icon-uniform');
    }

    const img = document.createElement('img');
    img.className = 'shortcut-icon-img';
    img.src = getFaviconUrl(domain);
    img.alt = '';

    img.onerror = () => {
      renderMonogramFallback(cardEl, item, domain);
    };

    return img;
  }

  function renderMonogramFallback(cardEl, item, domain) {
    cardEl.innerHTML = '';
    const color = item.color || getColorForString(domain || item.title);
    if (!cardEl.classList.contains('is-liquid-glass')) {
      cardEl.style.backgroundColor = color;
    }

    const span = document.createElement('span');
    span.className = 'monogram-text';
    const char = (item.title || domain || 'S').trim().charAt(0).toUpperCase();
    span.textContent = char;
    cardEl.appendChild(span);
  }

  /**
   * FLIP Animation Helper for Fluid Reordering
   */
  function animateFLIP(container, mutateDOMCallback) {
    const children = Array.from(container.children);
    const firstPositions = new Map();

    children.forEach(child => {
      firstPositions.set(child, child.getBoundingClientRect());
    });

    mutateDOMCallback();

    children.forEach(child => {
      if (child.classList.contains('dragging')) return;
      const first = firstPositions.get(child);
      if (!first) return;
      const last = child.getBoundingClientRect();
      const dx = first.left - last.left;
      const dy = first.top - last.top;

      if (dx !== 0 || dy !== 0) {
        child.classList.add('no-transition');
        child.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
        void child.offsetHeight;
        child.classList.remove('no-transition');
        child.style.transform = '';
      }
    });

    lastReorderTime = performance.now();
  }

  /**
   * Move item out of folder back to root grid
   */
  function moveItemOutOfFolder(sourceId, sourceFolderId) {
    if (!sourceFolderId) return;
    const srcFolder = state.items.find(i => i.id === sourceFolderId);
    if (!srcFolder || !srcFolder.children) return;
    const idx = srcFolder.children.findIndex(c => c.id === sourceId);
    if (idx === -1) return;
    const item = srcFolder.children.splice(idx, 1)[0];

    // Insert into state.items right after the parent folder
    const folderIdx = state.items.findIndex(i => i.id === sourceFolderId);
    if (folderIdx !== -1) {
      state.items.splice(folderIdx + 1, 0, item);
    } else {
      state.items.push(item);
    }

    if (item.bookmarkId && browserAPI && browserAPI.bookmarks && browserAPI.bookmarks.move) {
      browserAPI.bookmarks.move(item.bookmarkId, { parentId: state.defaultParentId || 'unfiled_____' }).catch(() => {});
    }

    saveState();
    renderGrid();
    renderFolderView();
  }

  /**
   * Universal Pointer Events Drag and Drop Engine (matching liquidtest)
   */
  function setupPointerDragAndDrop() {
    document.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      // Ignore interactive controls, modals, inputs, menus, buttons
      if (e.target.closest('#settings-modal, #modal-add-bookmark, #context-menu, #bg-context-menu, #header-controls, .section-view-mode-menu, .btn-add-section, .section-view-mode-btn, .quick-star-btn, input, textarea, select')) return;

      const itemEl = e.target.closest('.shortcut-item');
      if (!itemEl) return;

      preventNextClick = false;
      dragNode = itemEl;
      dragStartParent = itemEl.closest('#folder-view-modal') ? 'folder' : 'grid';
      dragStartPos = { x: e.clientX, y: e.clientY };
      const rect = dragNode.getBoundingClientRect();
      ghostOffset = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    });

    document.addEventListener('pointermove', (e) => {
      if (!dragNode) return;

      if (!isDragging) {
        const dist = Math.hypot(e.clientX - dragStartPos.x, e.clientY - dragStartPos.y);
        if (dist > 6) {
          isDragging = true;
          preventNextClick = true;

          const rect = dragNode.getBoundingClientRect();
          const isTile = dragNode.closest('.view-tile') !== null ||
            (!dragNode.closest('.view-grid') && !dragNode.closest('.view-thumb') && getSectionViewMode('favorites') === 'tile');
          const isThumb = dragNode.closest('.view-thumb') !== null ||
            (!dragNode.closest('.view-grid') && !dragNode.closest('.view-tile') && getSectionViewMode('favorites') === 'thumb');

          dragGhost = dragNode.cloneNode(true);
          dragGhost.className = dragNode.className + ' custom-drag-ghost';
          if (isTile) dragGhost.classList.add('view-tile');
          if (isThumb) dragGhost.classList.add('view-thumb');

          dragGhost.style.position = 'fixed';
          dragGhost.style.zIndex = '99999';
          dragGhost.style.pointerEvents = 'none';
          dragGhost.style.margin = '0';
          dragGhost.style.opacity = '0.92';
          dragGhost.style.width = rect.width + 'px';
          dragGhost.style.height = rect.height + 'px';
          dragGhost.style.maxWidth = rect.width + 'px';
          dragGhost.style.maxHeight = rect.height + 'px';
          dragGhost.style.minWidth = rect.width + 'px';
          dragGhost.style.minHeight = rect.height + 'px';
          dragGhost.style.boxSizing = 'border-box';
          dragGhost.style.transform = 'scale(1)';
          dragGhost.style.transformOrigin = 'center center';
          dragGhost.style.transition = 'none';

          dragGhost.style.left = (e.clientX - ghostOffset.x) + 'px';
          dragGhost.style.top = (e.clientY - ghostOffset.y) + 'px';
          document.body.appendChild(dragGhost);

          dragNode.classList.add('is-placeholder');
        } else {
          return;
        }
      }

      dragGhost.style.left = (e.clientX - ghostOffset.x) + 'px';
      dragGhost.style.top = (e.clientY - ghostOffset.y) + 'px';

      dragGhost.style.display = 'none';
      const elemBelow = document.elementFromPoint(e.clientX, e.clientY);
      dragGhost.style.display = '';

      if (!elemBelow) return;

      const draggedId = dragNode.dataset.id;
      const draggedItem = state.items.find(it => it.id === draggedId);
      const isDraggingFolder = draggedItem?.type === 'folder';

      // Section tabs drop target
      const tabTarget = elemBelow.closest('.fav-section-tab');
      if (tabTarget) {
        document.querySelectorAll('.tab-card-drop-target').forEach(t => t.classList.remove('tab-card-drop-target'));
        tabTarget.classList.add('tab-card-drop-target');
        if (currentFolderTarget) {
          currentFolderTarget.classList.remove('folder-drop-target');
          currentFolderTarget = null;
        }
        return;
      } else {
        document.querySelectorAll('.tab-card-drop-target').forEach(t => t.classList.remove('tab-card-drop-target'));
      }

      // Dragging out of folder view modal
      if (dragStartParent === 'folder') {
        const isOutsideFolderWindow = !elemBelow.closest('.folder-view-window');
        if (isOutsideFolderWindow) {
          return;
        }
      }

      // Folder target candidate on main grid
      const folderCandidate = elemBelow.closest('.shortcut-item');
      const folderCandidateId = folderCandidate?.dataset.id;
      const folderCandidateData = folderCandidateId ? state.items.find(it => it.id === folderCandidateId) : null;
      const isFolderTarget = folderCandidate &&
        folderCandidate !== dragNode &&
        folderCandidateData?.type === 'folder' &&
        !isDraggingFolder &&
        dragStartParent === 'grid';

      let isOverFolderCenter = false;
      if (isFolderTarget && folderCandidate) {
        const fr = folderCandidate.getBoundingClientRect();
        const relX = (e.clientX - fr.left) / fr.width;
        const relY = (e.clientY - fr.top) / fr.height;
        if (relX > 0.25 && relX < 0.75 && relY > 0.25 && relY < 0.75) {
          isOverFolderCenter = true;
        }
      }

      if (isFolderTarget && isOverFolderCenter) {
        if (currentFolderTarget && currentFolderTarget !== folderCandidate) {
          currentFolderTarget.classList.remove('folder-drop-target');
        }
        currentFolderTarget = folderCandidate;
        folderCandidate.classList.add('folder-drop-target');
        return;
      } else {
        if (currentFolderTarget) {
          currentFolderTarget.classList.remove('folder-drop-target');
          currentFolderTarget = null;
        }
      }

      // Reorder items in current container
      const container = dragStartParent === 'folder' ? elFolderItemsGrid : elGrid;
      const dropTarget = elemBelow.closest('.shortcut-item');
      if (dropTarget && dropTarget !== dragNode && dropTarget.parentNode === container) {
        const tr = dropTarget.getBoundingClientRect();
        const isLeftSide = e.clientX < (tr.left + tr.width / 2);

        currentDropTarget = dropTarget;

        const now = performance.now();
        if (now - lastSwapTime > SWAP_THROTTLE) {
          lastSwapTime = now;
          const children = [...container.children];
          const dragIndex = children.indexOf(dragNode);
          const dropIndex = children.indexOf(dropTarget);

          if (dragIndex === -1 || dropIndex === -1 || dragIndex === dropIndex) return;

          const rects = new Map();
          children.forEach(c => rects.set(c, c.getBoundingClientRect()));

          if (isLeftSide) {
            container.insertBefore(dragNode, dropTarget);
          } else {
            container.insertBefore(dragNode, dropTarget.nextSibling);
          }

          children.forEach(c => {
            const oldRect = rects.get(c);
            const newRect = c.getBoundingClientRect();
            const dx = oldRect.left - newRect.left;
            const dy = oldRect.top - newRect.top;
            if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
              c.style.transition = 'none';
              c.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
              requestAnimationFrame(() => {
                c.style.transition = 'transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1)';
                c.style.transform = '';
              });
            }
          });
        }
      }
    });

    document.addEventListener('pointerup', (e) => {
      if (currentDropTarget) {
        currentDropTarget.classList.remove('drag-over-left', 'drag-over-right');
        currentDropTarget = null;
      }
      document.querySelectorAll('.tab-card-drop-target').forEach(t => t.classList.remove('tab-card-drop-target'));

      if (isDragging && dragNode) {
        const draggedId = dragNode.dataset.id;
        const parentFolderId = dragNode.dataset.parentFolderId || null;

        dragGhost.style.display = 'none';
        const elemBelow = document.elementFromPoint(e.clientX, e.clientY);
        dragGhost.style.display = '';

        // Drop on section tab
        const tabTarget = elemBelow?.closest('.fav-section-tab');
        if (tabTarget && tabTarget.dataset.sectionId) {
          const targetSectionId = tabTarget.dataset.sectionId;
          cleanupCustomDragGhost();
          moveBookmarkToSection(draggedId, parentFolderId, targetSectionId);
          return;
        }

        // Drop onto folder
        if (currentFolderTarget) {
          const targetFolderId = currentFolderTarget.dataset.id;
          cleanupCustomDragGhost();
          moveItemIntoFolder(draggedId, parentFolderId, targetFolderId);
          return;
        }

        // Drop out of folder view into main grid
        if (dragStartParent === 'folder' && elemBelow && !elemBelow.closest('.folder-view-window')) {
          cleanupCustomDragGhost();
          moveItemOutOfFolder(draggedId, parentFolderId);
          return;
        }

        // Normal reordering finish: animate ghost smoothly to final position
        dragNode.classList.remove('is-placeholder');
        if (dragGhost) {
          const finalRect = dragNode.getBoundingClientRect();
          dragGhost.style.transition = 'all 0.2s ease-out';
          dragGhost.style.left = finalRect.left + 'px';
          dragGhost.style.top = finalRect.top + 'px';
          dragGhost.style.opacity = '0';
          dragGhost.style.transform = 'scale(1)';

          const _ghost = dragGhost;
          setTimeout(() => { if (_ghost && _ghost.parentNode) _ghost.parentNode.removeChild(_ghost); }, 200);
          dragGhost = null;
        }

        commitDOMOrderToState(parentFolderId);

        const container = dragStartParent === 'folder' ? elFolderItemsGrid : elGrid;
        if (container) {
          container.querySelectorAll('.shortcut-item').forEach(el => {
            el.style.transition = '';
            el.style.transform = '';
          });
        }
      }

      cleanupCustomDragGhost();
    });

    document.addEventListener('pointercancel', cleanupCustomDragGhost);
    window.addEventListener('blur', cleanupCustomDragGhost);
  }

  /**
   * Commit the visual DOM order into state.items
   */
  function commitDOMOrderToState(parentFolderId) {
    if (parentFolderId) {
      const folder = state.items.find(i => i.id === parentFolderId);
      if (folder && folder.children) {
        const domIds = Array.from(elFolderItemsGrid.children).map(c => c.dataset.id);
        const map = new Map(folder.children.map(i => [i.id, i]));
        folder.children = domIds.map(id => map.get(id)).filter(Boolean);
        saveState();
      }
    } else {
      const domIds = Array.from(elGrid.children).map(c => c.dataset.id);
      if (domIds.length === 0) return;
      const map = new Map(state.items.map(i => [i.id, i]));
      state.items = domIds.map(id => map.get(id)).filter(Boolean);
      saveState();
    }
  }

  /**
   * Move item into folder
   */
  function moveItemIntoFolder(sourceId, sourceFolderId, targetFolderId) {
    if (sourceId === targetFolderId) return;
    let sourceItem = null;

    if (sourceFolderId) {
      const srcFolder = state.items.find(i => i.id === sourceFolderId);
      if (srcFolder && srcFolder.children) {
        const idx = srcFolder.children.findIndex(c => c.id === sourceId);
        if (idx !== -1) {
          sourceItem = srcFolder.children.splice(idx, 1)[0];
        }
      }
    } else {
      const idx = state.items.findIndex(i => i.id === sourceId);
      if (idx !== -1) {
        sourceItem = state.items.splice(idx, 1)[0];
      }
    }

    if (!sourceItem) return;

    const targetFolder = state.items.find(i => i.id === targetFolderId);
    if (targetFolder && targetFolder.type === 'folder') {
      if (!targetFolder.children) targetFolder.children = [];
      targetFolder.children.push(sourceItem);

      if (sourceItem.bookmarkId && targetFolder.bookmarkId && browserAPI && browserAPI.bookmarks && browserAPI.bookmarks.move) {
        browserAPI.bookmarks.move(sourceItem.bookmarkId, { parentId: targetFolder.bookmarkId }).catch(() => {});
      }
    }

    saveState();
    renderGrid();
    if (state.activeFolderId) renderFolderView();
  }

  let activeFolderOriginEl = null;
  let isFolderViewAnimating = false;

  /**
   * Folder Drill-Down View with Apple iOS / macOS Grow & Shrink Animation
   */
  function openFolderView(folderId, originEl = null) {
    const folder = state.items.find(i => i.id === folderId);
    if (!folder) return;

    if (!originEl) {
      originEl = elGrid.querySelector(`.shortcut-item[data-id="${folderId}"] .shortcut-card`) ||
                 elGrid.querySelector(`.shortcut-item[data-id="${folderId}"]`);
    }
    activeFolderOriginEl = originEl;

    state.activeFolderId = folderId;
    elFolderViewTitle.textContent = folder.title || t('folderDefaultTitle');

    const isThemeLight = elApp ? elApp.classList.contains('safari-theme-light') : false;
    const defaultFolderColor = isThemeLight ? 'rgba(246, 246, 248, 0.94)' : '#3a3a3e';
    const folderColor = (state.settings && state.settings.folderColor && state.settings.folderColor !== '#3a3a3e') ? state.settings.folderColor : (isThemeLight ? defaultFolderColor : '#3a3a3e');
    const isLiquidFolder = folderColor === 'liquid-glass';
    const isFolderLight = isLiquidFolder ? isThemeLight : isColorLight(folderColor, isThemeLight);
    const windowEl = elFolderViewModal.querySelector('.folder-view-window');
    if (windowEl) {
      windowEl.classList.toggle('is-light', isFolderLight);
      windowEl.classList.toggle('is-dark', !isFolderLight);
      windowEl.classList.toggle('is-liquid-glass', isLiquidFolder);
    }

    renderFolderView();
    elFolderViewModal.style.display = 'flex';

    if (state.settings.folderAnimation !== false && originEl && windowEl) {
      isFolderViewAnimating = true;
      const originRect = originEl.getBoundingClientRect();
      const winRect = windowEl.getBoundingClientRect();

      const ox = originRect.left + originRect.width / 2;
      const oy = originRect.top + originRect.height / 2;
      const wx = winRect.left + winRect.width / 2;
      const wy = winRect.top + winRect.height / 2;

      const dx = ox - wx;
      const dy = oy - wy;
      const scaleX = Math.max(0.08, originRect.width / Math.max(1, winRect.width));
      const scaleY = Math.max(0.08, originRect.height / Math.max(1, winRect.height));

      // Backdrop animation
      elFolderViewModal.animate([
        { opacity: 0 },
        { opacity: 1 }
      ], {
        duration: 320,
        easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
        fill: 'both'
      });

      // Window grow from folder card
      const openAnim = windowEl.animate([
        {
          transform: `translate(${dx}px, ${dy}px) scale(${scaleX}, ${scaleY})`,
          opacity: 0,
          borderRadius: '32px'
        },
        {
          transform: 'translate(0px, 0px) scale(1, 1)',
          opacity: 1,
          borderRadius: '22px'
        }
      ], {
        duration: 340,
        easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
        fill: 'both'
      });

      openAnim.onfinish = () => {
        isFolderViewAnimating = false;
        if (originEl) originEl.style.opacity = '0';
        requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
      };
    } else {
      isFolderViewAnimating = false;
      if (originEl) originEl.style.opacity = '0';
      requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
    }
  }

  function closeFolderView() {
    if (isFolderViewAnimating) return;
    if (!elFolderViewModal || elFolderViewModal.style.display === 'none') return;

    const windowEl = elFolderViewModal.querySelector('.folder-view-window');
    let originEl = activeFolderOriginEl;

    if (!originEl || !originEl.isConnected) {
      if (state.activeFolderId) {
        originEl = elGrid.querySelector(`.shortcut-item[data-id="${state.activeFolderId}"] .shortcut-card`) ||
                   elGrid.querySelector(`.shortcut-item[data-id="${state.activeFolderId}"]`);
      }
    }

    if (originEl) originEl.style.opacity = '1';

    if (state.settings.folderAnimation !== false && originEl && windowEl) {
      isFolderViewAnimating = true;
      const originRect = originEl.getBoundingClientRect();
      const winRect = windowEl.getBoundingClientRect();

      const ox = originRect.left + originRect.width / 2;
      const oy = originRect.top + originRect.height / 2;
      const wx = winRect.left + winRect.width / 2;
      const wy = winRect.top + winRect.height / 2;

      const dx = ox - wx;
      const dy = oy - wy;
      const scaleX = Math.max(0.08, originRect.width / Math.max(1, winRect.width));
      const scaleY = Math.max(0.08, originRect.height / Math.max(1, winRect.height));

      // Backdrop fade out
      elFolderViewModal.animate([
        { opacity: 1 },
        { opacity: 0 }
      ], {
        duration: 250,
        easing: 'cubic-bezier(0.25, 1, 0.5, 1)',
        fill: 'forwards'
      });

      // Window shrinks back into the folder card
      const closeAnim = windowEl.animate([
        {
          transform: 'translate(0px, 0px) scale(1, 1)',
          opacity: 1,
          borderRadius: '22px'
        },
        {
          transform: `translate(${dx}px, ${dy}px) scale(${scaleX}, ${scaleY})`,
          opacity: 0,
          borderRadius: '32px'
        }
      ], {
        duration: 260,
        easing: 'cubic-bezier(0.25, 1, 0.5, 1)',
        fill: 'forwards'
      });

      closeAnim.onfinish = () => {
        if (originEl) originEl.style.opacity = '';
        state.activeFolderId = null;
        activeFolderOriginEl = null;
        isFolderViewAnimating = false;
        elFolderViewModal.style.display = 'none';
        renderGrid(); // update mini preview
        requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
      };
    } else {
      if (originEl) originEl.style.opacity = '';
      state.activeFolderId = null;
      activeFolderOriginEl = null;
      isFolderViewAnimating = false;
      elFolderViewModal.style.display = 'none';
      renderGrid();
      requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
    }
  }

  function renderFolderView() {
    elFolderItemsGrid.innerHTML = '';
    const folder = state.items.find(i => i.id === state.activeFolderId);
    if (!folder) {
      closeFolderView();
      return;
    }

    const children = folder.children || [];
    if (children.length === 0) {
      elFolderEmptyNotice.style.display = 'block';
    } else {
      elFolderEmptyNotice.style.display = 'none';
      children.forEach((child, idx) => {
        const childEl = renderItemElement(child, idx, folder.id);
        elFolderItemsGrid.appendChild(childEl);
      });
    }
    requestAnimationFrame(() => LiquidGlassEngine.updateLenses());
  }

  /**
   * Add / Edit Shortcut Modal Handlers
   */
  function openAddShortcutModal(folderId = null) {
    editingShortcutId = null;
    isNameAutoGenerated = true;
    elShortcutModalTitle.textContent = t('modalAddShortcutTitle');
    elShortcutNameInput.value = '';
    elShortcutUrlInput.value = '';

    populateFolderSelect(folderId);
    updatePreviewCard('', '');

    elShortcutModal.style.display = 'flex';
    elShortcutUrlInput.focus();
  }

  function openEditShortcutModal(item, parentFolderId = null) {
    editingShortcutId = item.id;
    isNameAutoGenerated = false;
    elShortcutModalTitle.textContent = t('modalEditShortcutTitle');
    elShortcutNameInput.value = item.title || '';
    elShortcutUrlInput.value = item.url || '';

    populateFolderSelect(parentFolderId);
    updatePreviewCard(item.title, item.url);

    elShortcutModal.style.display = 'flex';
    elShortcutNameInput.focus();
  }

  function closeShortcutModal() {
    elShortcutModal.style.display = 'none';
    editingShortcutId = null;
    isNameAutoGenerated = true;
  }

  function populateFolderSelect(selectedFolderId = null) {
    elShortcutFolderSelect.innerHTML = `<option value="">${t('folderRootOption')}</option>`;
    state.items.filter(i => i.type === 'folder').forEach(folder => {
      const opt = document.createElement('option');
      opt.value = folder.id;
      opt.textContent = '📁 ' + folder.title;
      if (selectedFolderId && selectedFolderId === folder.id) {
        opt.selected = true;
      }
      elShortcutFolderSelect.appendChild(opt);
    });
  }

  function updatePreviewCard(title, url) {
    const domain = extractDomain(url || '');
    const cleanTitle = title || deriveNameFromDomain(domain) || domain || 'Nombre';
    elPreviewTitle.textContent = cleanTitle;

    elShortcutPreviewCard.innerHTML = '';
    elShortcutPreviewCard.style.backgroundColor = '';

    const brand = getKnownBrand(domain);
    const iconStyle = state.settings.iconStyle || 'uniform';
    if (brand && BRAND_SVGS[brand]) {
      elShortcutPreviewCard.innerHTML = BRAND_SVGS[brand];
      if (iconStyle === 'fullbleed') {
        elShortcutPreviewCard.classList.add('full-bleed');
        elShortcutPreviewCard.classList.remove('icon-uniform');
      } else {
        elShortcutPreviewCard.classList.add('icon-uniform');
        elShortcutPreviewCard.classList.remove('full-bleed');
      }
    } else if (domain) {
      if (iconStyle !== 'fullbleed') {
        elShortcutPreviewCard.classList.add('icon-uniform');
      } else {
        elShortcutPreviewCard.classList.remove('full-bleed');
      }
      const img = document.createElement('img');
      img.className = 'shortcut-icon-img';
      img.src = getFaviconUrl(domain);
      img.onerror = () => {
        elShortcutPreviewCard.innerHTML = '';
        elShortcutPreviewCard.style.backgroundColor = getColorForString(domain);
        const span = document.createElement('span');
        span.className = 'monogram-text';
        span.textContent = cleanTitle.charAt(0).toUpperCase();
        elShortcutPreviewCard.appendChild(span);
      };
      elShortcutPreviewCard.appendChild(img);
    } else {
      const span = document.createElement('span');
      span.className = 'monogram-text';
      span.textContent = 'S';
      elShortcutPreviewCard.appendChild(span);
    }
  }

  function handleSaveShortcut(e) {
    e.preventDefault();
    const rawUrl = elShortcutUrlInput.value.trim();
    if (!rawUrl) return;

    const url = normalizeUrl(rawUrl);
    const domain = extractDomain(url);
    const title = elShortcutNameInput.value.trim() || deriveNameFromDomain(domain) || domain;
    const targetFolderId = elShortcutFolderSelect.value;

    if (editingShortcutId) {
      let currentFolder = null;
      let existingItem = null;

      const rootIdx = state.items.findIndex(i => i.id === editingShortcutId);
      if (rootIdx !== -1) {
        existingItem = state.items[rootIdx];
      } else {
        for (const f of state.items.filter(i => i.type === 'folder')) {
          const childIdx = (f.children || []).findIndex(c => c.id === editingShortcutId);
          if (childIdx !== -1) {
            currentFolder = f;
            existingItem = f.children[childIdx];
            break;
          }
        }
      }

      if (existingItem) {
        existingItem.title = title;
        existingItem.url = url;
        existingItem.domain = domain;
        existingItem.color = getColorForString(domain);

        const currentFolderId = currentFolder ? currentFolder.id : '';
        if (currentFolderId !== targetFolderId) {
          if (currentFolder) {
            currentFolder.children = currentFolder.children.filter(c => c.id !== editingShortcutId);
          } else {
            state.items = state.items.filter(i => i.id !== editingShortcutId);
          }
          if (targetFolderId) {
            const newF = state.items.find(i => i.id === targetFolderId);
            if (newF) {
              if (!newF.children) newF.children = [];
              newF.children.push(existingItem);
            }
          } else {
            state.items.push(existingItem);
          }
        }

        if (existingItem.bookmarkId && browserAPI.bookmarks) {
          browserAPI.bookmarks.update(existingItem.bookmarkId, { title: title, url: url }).catch(() => {});
        }
      }
    } else {
      const newItem = createShortcutItem(title, url);

      if (targetFolderId) {
        const folder = state.items.find(i => i.id === targetFolderId);
        if (folder) {
          if (!folder.children) folder.children = [];
          folder.children.push(newItem);
        }
      } else {
        state.items.push(newItem);
      }

      if (browserAPI.bookmarks) {
        const urlKey = getThumbKey(url);
        if (urlKey) internalCreatingShortcutUrls.add(urlKey);

        const createData = { title: title, url: url };
        if (targetFolderId) {
          const folder = state.items.find(i => i.id === targetFolderId);
          if (folder && folder.bookmarkId) {
            createData.parentId = folder.bookmarkId;
          }
        }
        browserAPI.bookmarks.create(createData).then(node => {
          newItem.bookmarkId = node.id;
          saveState();
        }).catch(() => {}).finally(() => {
          if (urlKey) {
            setTimeout(() => {
              internalCreatingShortcutUrls.delete(urlKey);
            }, 1000);
          }
        });
      }
    }

    if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
      queueCapture(url, true, false, title);
    }

    saveState();
    closeShortcutModal();
    renderGrid();
    if (state.activeFolderId) renderFolderView();
  }

  /**
   * Add Folder Modal Handlers
   */
  function openAddFolderModal(folderItem = null) {
    editingFolderId = folderItem ? folderItem.id : null;
    if (elFolderModalTitle) {
      elFolderModalTitle.textContent = folderItem ? t('modalEditFolderTitle') : t('modalAddFolderTitle');
    }
    elFolderNameInput.value = folderItem ? folderItem.title : '';
    elFolderModal.style.display = 'flex';
    elFolderNameInput.focus();
  }

  function closeFolderModal() {
    elFolderModal.style.display = 'none';
    editingFolderId = null;
  }

  function handleSaveFolder(e) {
    e.preventDefault();
    const name = elFolderNameInput.value.trim() || t('folderDefaultTitle');

    if (editingFolderId) {
      const folder = state.items.find(i => i.id === editingFolderId);
      if (folder) {
        folder.title = name;
        if (folder.bookmarkId && browserAPI.bookmarks) {
          browserAPI.bookmarks.update(folder.bookmarkId, { title: name }).catch(() => {});
        }
      }
    } else {
      const newFolder = {
        id: 'folder_' + Date.now(),
        type: 'folder',
        title: name,
        children: []
      };
      state.items.push(newFolder);

      if (browserAPI.bookmarks) {
        internalCreatingFolderTitles.add(name);
        browserAPI.bookmarks.create({
          title: name
        }).then(node => {
          newFolder.bookmarkId = node.id;
          saveState();
        }).catch(() => {}).finally(() => {
          setTimeout(() => {
            internalCreatingFolderTitles.delete(name);
          }, 1000);
        });
      }
    }

    saveState();
    closeFolderModal();
    renderGrid();
    if (state.activeFolderId) renderFolderView();
  }

  /**
   * Delete item or folder
   */
  function deleteItem(item, parentFolderId = null) {
    if (parentFolderId) {
      const folder = state.items.find(i => i.id === parentFolderId);
      if (folder && folder.children) {
        folder.children = folder.children.filter(c => c.id !== item.id);
      }
    } else {
      state.items = state.items.filter(i => i.id !== item.id);
    }

    if (item.bookmarkId && browserAPI.bookmarks) {
      if (item.type === 'folder') {
        browserAPI.bookmarks.removeTree(item.bookmarkId).catch(() => {});
      } else {
        browserAPI.bookmarks.remove(item.bookmarkId).catch(() => {});
      }
    }

    saveState();
    renderGrid();
    if (state.activeFolderId) renderFolderView();
  }

  /**
   * Settings Subpanel Navigation Logic
   */
  function openSettingsSubpanel(panelId) {
    const panels = document.querySelectorAll('.settings-slide-panel');
    panels.forEach(p => {
      p.classList.remove('is-active', 'is-active-reverse');
    });
    const target = document.getElementById(panelId);
    if (target) {
      target.classList.add('is-active');
    }
  }

  function returnToMainSettings() {
    const panels = document.querySelectorAll('.settings-slide-panel');
    panels.forEach(p => {
      p.classList.remove('is-active', 'is-active-reverse');
    });
    if (elSettingsPanelMain) {
      elSettingsPanelMain.classList.add('is-active-reverse');
    }
  }

  let isSettingsClosing = false;
  function openSettingsModal() {
    applySettings();
    const panels = document.querySelectorAll('.settings-slide-panel');
    panels.forEach(p => {
      p.classList.remove('is-active', 'is-active-reverse');
    });
    if (elSettingsPanelMain) {
      elSettingsPanelMain.classList.add('is-active');
    }
    elSettingsModal.style.display = 'flex';
    const card = elSettingsModal.querySelector('.modal-card');
    if (card) {
      card.animate([
        { transform: 'translateX(100%)', opacity: 0.8 },
        { transform: 'translateX(0)', opacity: 1 }
      ], {
        duration: 220,
        easing: 'cubic-bezier(0.16, 1, 0.3, 1)'
      });
    }
    requestAnimationFrame(() => LiquidGlassEngine.render());
  }

  function closeSettingsModal() {
    if (isSettingsClosing) return;
    if (!elSettingsModal || elSettingsModal.style.display === 'none') return;
    const card = elSettingsModal.querySelector('.modal-card');
    if (card) {
      isSettingsClosing = true;
      const anim = card.animate([
        { transform: 'translateX(0)', opacity: 1 },
        { transform: 'translateX(100%)', opacity: 0.8 }
      ], {
        duration: 180,
        easing: 'cubic-bezier(0.25, 1, 0.5, 1)'
      });
      anim.onfinish = () => {
        isSettingsClosing = false;
        elSettingsModal.style.display = 'none';
        returnToMainSettings();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      };
    } else {
      elSettingsModal.style.display = 'none';
      returnToMainSettings();
      requestAnimationFrame(() => LiquidGlassEngine.render());
    }
  }

  function adjustSize(delta) {
    if (state.settings.viewMode === 'thumb') {
      let width = (state.settings.thumbWidth !== undefined ? state.settings.thumbWidth : 220) + (delta * 3);
      width = Math.round(Math.max(140, Math.min(480, width)));
      const height = Math.round(width * 0.6);
      state.settings.thumbWidth = width;
      state.settings.thumbHeight = height;
      if (elDisplaySize) elDisplaySize.textContent = width + 'px';
      document.documentElement.style.setProperty('--thumb-width', width + 'px');
      document.documentElement.style.setProperty('--thumb-height', height + 'px');
    } else {
      let size = (state.settings.cardSize !== undefined ? state.settings.cardSize : 74) + delta;
      size = Math.max(36, Math.min(120, size));
      state.settings.cardSize = size;
      if (elDisplaySize) elDisplaySize.textContent = size + 'px';
      document.documentElement.style.setProperty('--card-size', size + 'px');
    }
    saveState();
    requestAnimationFrame(() => LiquidGlassEngine.render());
  }

  function adjustGap(delta) {
    let gap = (state.settings.cardGap !== undefined ? state.settings.cardGap : 16) + delta;
    gap = Math.max(0, Math.min(48, gap));
    state.settings.cardGap = gap;
    if (elDisplayGap) elDisplayGap.textContent = gap + 'px';
    document.documentElement.style.setProperty('--card-gap-x', gap + 'px');
    document.documentElement.style.setProperty('--card-gap-y', Math.max(6, gap + 6) + 'px');
    saveState();
    requestAnimationFrame(() => LiquidGlassEngine.render());
  }

  /**
   * Context Menu Handlers
   */
  function showContextMenu(x, y, item, parentFolderId, sectionType = 'favorites') {
    hideBgContextMenu();
    contextTarget.item = item;
    contextTarget.folderId = parentFolderId;
    contextTarget.sectionType = sectionType;

    const openLeft = x > window.innerWidth - 380;
    elContextMenu.classList.toggle('open-left', openLeft);
    elContextMenu.style.display = 'flex';
    elContextMenu.style.left = `${Math.min(x, window.innerWidth - 200)}px`;
    elContextMenu.style.top = `${Math.min(y, window.innerHeight - 240)}px`;

    if (sectionType === 'closedTabs' || sectionType === 'history') {
      if (elCtxOpenNewTab) elCtxOpenNewTab.style.display = 'block';
      if (elCtxOpenNewWindow) elCtxOpenNewWindow.style.display = 'block';
      if (elCtxSepThumb) elCtxSepThumb.style.display = 'none';
      if (elCtxCustomThumbnail) elCtxCustomThumbnail.style.display = 'none';
      if (elCtxRemoveCustomThumbnail) elCtxRemoveCustomThumbnail.style.display = 'none';
      if (elCtxSepFav) elCtxSepFav.style.display = 'block';
      if (elCtxAddToFavorites) elCtxAddToFavorites.style.display = 'flex';
      if (elCtxSepEdit) elCtxSepEdit.style.display = 'none';
      if (elCtxEdit) elCtxEdit.style.display = 'none';
      if (elCtxMoveFolder) elCtxMoveFolder.style.display = 'none';
      if (elCtxSepDelete) elCtxSepDelete.style.display = 'none';
      if (elCtxDelete) elCtxDelete.style.display = 'none';
    } else {
      if (elCtxAddToFavorites) elCtxAddToFavorites.style.display = 'none';

      if (item.type === 'folder') {
        if (elCtxOpenNewTab) elCtxOpenNewTab.style.display = 'none';
        if (elCtxOpenNewWindow) elCtxOpenNewWindow.style.display = 'none';
        if (elCtxSepThumb) elCtxSepThumb.style.display = 'none';
        if (elCtxCustomThumbnail) elCtxCustomThumbnail.style.display = 'none';
        if (elCtxRemoveCustomThumbnail) elCtxRemoveCustomThumbnail.style.display = 'none';
        if (elCtxSepFav) elCtxSepFav.style.display = 'none';
        if (elCtxSepEdit) elCtxSepEdit.style.display = 'none';
        if (elCtxEdit) elCtxEdit.style.display = 'block';
        if (elCtxMoveFolder) elCtxMoveFolder.style.display = 'none';
        if (elCtxSepDelete) elCtxSepDelete.style.display = 'block';
        if (elCtxDelete) elCtxDelete.style.display = 'block';
      } else {
        const isThumbView = (state.settings.viewMode === 'thumb');
        const hasCustomThumb = !!(item && item.customThumbnail);
        if (elCtxOpenNewTab) elCtxOpenNewTab.style.display = 'block';
        if (elCtxOpenNewWindow) elCtxOpenNewWindow.style.display = 'block';
        if (elCtxSepThumb) elCtxSepThumb.style.display = isThumbView ? 'block' : 'none';
        if (elCtxCustomThumbnail) elCtxCustomThumbnail.style.display = isThumbView ? 'flex' : 'none';
        if (elCtxRemoveCustomThumbnail) elCtxRemoveCustomThumbnail.style.display = (isThumbView && hasCustomThumb) ? 'flex' : 'none';
        if (elCtxSepFav) elCtxSepFav.style.display = 'none';
        if (elCtxSepEdit) elCtxSepEdit.style.display = 'block';
        if (elCtxEdit) elCtxEdit.style.display = 'block';
        if (elCtxMoveFolder) elCtxMoveFolder.style.display = 'block';
        if (elCtxSepDelete) elCtxSepDelete.style.display = 'block';
        if (elCtxDelete) elCtxDelete.style.display = 'block';
      }
    }
  }

  function hideContextMenu() {
    elContextMenu.style.display = 'none';
    contextTarget.item = null;
    contextTarget.folderId = null;
    hideBgContextMenu();
    hideTabContextMenu();
  }

  function showBgContextMenu(x, y) {
    hideContextMenu();
    hideTabContextMenu();
    if (!elBgContextMenu) return;

    // Synchronize section checkmarks
    ensureSectionsSettings();
    const sec = state.settings.sections;
    if (elBgCheckClosedTabs) {
      elBgCheckClosedTabs.classList.toggle('is-active', sec.closedTabs.enabled !== false);
    }
    if (elBgCheckHistory) {
      elBgCheckHistory.classList.toggle('is-active', sec.history.enabled !== false);
    }
    if (elBgCheckSearch) {
      elBgCheckSearch.classList.toggle('is-active', state.settings.showSearchBar !== false);
    }

    const openLeft = x > window.innerWidth - 380;
    elBgContextMenu.classList.toggle('open-left', openLeft);
    elBgContextMenu.style.display = 'flex';
    elBgContextMenu.style.left = `${Math.min(x, window.innerWidth - 220)}px`;
    elBgContextMenu.style.top = `${Math.min(y, window.innerHeight - 240)}px`;
  }

  function hideBgContextMenu() {
    if (elBgContextMenu) {
      elBgContextMenu.style.display = 'none';
    }
  }

  let contextTargetTabSectionId = null;

  function showTabContextMenu(x, y, sectionId) {
    hideContextMenu();
    hideBgContextMenu();
    contextTargetTabSectionId = sectionId;

    if (!elTabContextMenu) return;

    const canDelete = state.favoriteSections && state.favoriteSections.length > 1;
    if (elTabCtxDelete) elTabCtxDelete.style.display = canDelete ? 'flex' : 'none';
    if (elTabCtxSepDelete) elTabCtxSepDelete.style.display = canDelete ? 'block' : 'none';

    const openLeft = x > window.innerWidth - 220;
    elTabContextMenu.classList.toggle('open-left', openLeft);
    elTabContextMenu.style.display = 'flex';
    elTabContextMenu.style.left = `${Math.min(x, window.innerWidth - 200)}px`;
    elTabContextMenu.style.top = `${Math.min(y, window.innerHeight - 180)}px`;
  }

  function hideTabContextMenu() {
    if (elTabContextMenu) {
      elTabContextMenu.style.display = 'none';
    }
    contextTargetTabSectionId = null;
  }

  /**
   * Helper: Parse HTML Bookmark exports from other browsers (Chrome, Safari, Edge, etc.)
   */
  function parseBookmarkHtml(htmlString) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    const items = [];

    function processContainer(containerNode) {
      const list = [];
      const children = Array.from(containerNode.children);
      for (let i = 0; i < children.length; i++) {
        const el = children[i];
        if (el.tagName === 'DT') {
          const h3 = el.querySelector(':scope > h3');
          const dl = el.querySelector(':scope > dl');
          const a = el.querySelector(':scope > a');
          if (h3 && dl) {
            const folderTitle = h3.textContent.trim() || 'Carpeta';
            const folderChildren = processContainer(dl);
            if (folderChildren.length > 0) {
              list.push({
                id: 'folder_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
                type: 'folder',
                title: folderTitle,
                children: folderChildren
              });
            }
          } else if (a && a.href && !a.href.startsWith('javascript:')) {
            const title = a.textContent.trim() || extractDomain(a.href);
            list.push(createShortcutItem(title, a.href));
          }
        } else if (el.tagName === 'DL') {
          list.push(...processContainer(el));
        } else if (el.tagName === 'A' && el.href && !el.href.startsWith('javascript:')) {
          const title = el.textContent.trim() || extractDomain(el.href);
          list.push(createShortcutItem(title, el.href));
        }
      }
      return list;
    }

    const rootDl = doc.querySelector('dl');
    if (rootDl) {
      items.push(...processContainer(rootDl));
    } else {
      const links = doc.querySelectorAll('a[href]');
      links.forEach(a => {
        if (a.href && !a.href.startsWith('javascript:')) {
          items.push(createShortcutItem(a.textContent.trim() || extractDomain(a.href), a.href));
        }
      });
    }
    return items;
  }

  /**
   * Start Page Sections Management (Favoritos, Pestañas cerradas, Historial)
   */
  function ensureSectionsSettings() {
    if (!state.settings.sections) {
      state.settings.sections = {
        favorites: { enabled: true, collapsed: false, viewMode: state.settings.viewMode || 'grid' },
        closedTabs: { enabled: true, collapsed: false, viewMode: state.settings.viewMode || 'grid' },
        history: { enabled: true, collapsed: false, viewMode: state.settings.viewMode || 'grid' }
      };
    }
    const defaultMode = state.settings.viewMode || 'grid';
    ['favorites', 'closedTabs', 'history'].forEach(key => {
      if (!state.settings.sections[key]) {
        state.settings.sections[key] = { enabled: true, collapsed: false, viewMode: defaultMode };
      }
      if (!state.settings.sections[key].viewMode) {
        state.settings.sections[key].viewMode = defaultMode;
      }
    });
    // Favorites is always expanded
    state.settings.sections.favorites.collapsed = false;
  }

  function getSectionViewMode(sectionKey) {
    ensureSectionsSettings();
    return state.settings.sections?.[sectionKey]?.viewMode || state.settings.viewMode || 'grid';
  }

  function setSectionViewMode(sectionKey, mode) {
    if (!['grid', 'tile', 'thumb'].includes(mode)) return;
    ensureSectionsSettings();
    if (state.settings.sections[sectionKey]) {
      state.settings.sections[sectionKey].viewMode = mode;
      saveState();
      applySettings();
      if (sectionKey === 'favorites') {
        renderGrid();
      } else if (sectionKey === 'closedTabs') {
        if (lastClosedTabsSessions) {
          renderRecentlyClosedTabs(lastClosedTabsSessions);
        } else {
          loadRecentlyClosedTabs();
        }
      } else if (sectionKey === 'history') {
        if (lastHistoryResults) {
          renderBrowsingHistory(lastHistoryResults);
        } else {
          loadBrowsingHistory();
        }
      }
      if (mode === 'thumb') {
        checkAndExtractMissingThumbnails();
      }
    }
  }

  function setupSectionViewModeDropdowns() {
    const wraps = document.querySelectorAll('.section-view-mode-wrap');
    wraps.forEach(wrap => {
      const btn = wrap.querySelector('.section-view-mode-btn');
      const menu = wrap.querySelector('.section-view-mode-menu');
      const sectionKey = wrap.dataset.section;
      if (!btn || !menu || !sectionKey) return;

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const isOpen = wrap.classList.contains('open');

        // Close all other section menus and main menu
        document.querySelectorAll('.section-view-mode-wrap.open').forEach(w => {
          if (w !== wrap) {
            w.classList.remove('open');
            const m = w.querySelector('.section-view-mode-menu');
            if (m) m.style.display = 'none';
          }
        });
        toggleViewModeDropdown(false);

        if (!isOpen) {
          wrap.classList.add('open');
          menu.style.display = 'flex';
        } else {
          wrap.classList.remove('open');
          menu.style.display = 'none';
        }
      });

      menu.querySelectorAll('.section-view-menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const mode = item.dataset.mode;
          setSectionViewMode(sectionKey, mode);
          wrap.classList.remove('open');
          menu.style.display = 'none';
        });
      });
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.section-view-mode-wrap')) {
        document.querySelectorAll('.section-view-mode-wrap.open').forEach(w => {
          w.classList.remove('open');
          const m = w.querySelector('.section-view-mode-menu');
          if (m) m.style.display = 'none';
        });
      }
    });
  }

  function updateSectionViewModeUI() {
    document.querySelectorAll('.section-view-mode-wrap').forEach(wrap => {
      const sectionKey = wrap.dataset.section;
      if (!sectionKey) return;
      const currentMode = getSectionViewMode(sectionKey);
      const iconSpan = wrap.querySelector('.section-view-mode-icon');
      if (iconSpan && VIEW_MODE_CONFIG[currentMode]) {
        iconSpan.innerHTML = VIEW_MODE_CONFIG[currentMode].svg;
      }
      wrap.querySelectorAll('.section-view-menu-item').forEach(item => {
        item.classList.toggle('active', item.dataset.mode === currentMode);
      });
    });
  }

  function updateSectionsUI() {
    ensureSectionsSettings();
    const sec = state.settings.sections;

    // Visibility
    if (elSectionFavorites) elSectionFavorites.classList.toggle('is-hidden', sec.favorites.enabled === false);
    if (elSectionClosedTabs) elSectionClosedTabs.classList.toggle('is-hidden', sec.closedTabs.enabled === false);
    if (elSectionHistory) elSectionHistory.classList.toggle('is-hidden', sec.history.enabled === false);

    // Collapsed states (favorites is always expanded)
    if (elSectionFavorites) elSectionFavorites.classList.remove('is-collapsed');
    updateSectionCollapseUI('closedTabs', elSectionClosedTabs);
    updateSectionCollapseUI('history', elSectionHistory);

    // Settings checkboxes
    if (elSettingShowFavorites) elSettingShowFavorites.checked = (sec.favorites.enabled !== false);
    if (elSettingShowClosedTabs) elSettingShowClosedTabs.checked = (sec.closedTabs.enabled !== false);
    if (elSettingShowHistory) elSettingShowHistory.checked = (sec.history.enabled !== false);
  }

  function updateSectionCollapseUI(key, sectionEl) {
    if (!sectionEl) return;
    const isCollapsed = !!state.settings.sections?.[key]?.collapsed;
    sectionEl.classList.toggle('is-collapsed', isCollapsed);
  }

  function toggleSection(key) {
    ensureSectionsSettings();
    const sec = state.settings.sections[key];
    sec.collapsed = !sec.collapsed;
    updateSectionsUI();
    saveState();
  }

  /**
   * Create a standard squircle or thumbnail card element for closed tabs or history
   */
  function createSimpleCardElement(title, url, favIconUrl, clickHandler, sectionType = 'closedTabs') {
    const itemContainer = document.createElement('div');
    itemContainer.className = 'shortcut-item';
    itemContainer.title = `${title || 'Página'}\n${url || ''}`;
    if (url) itemContainer.dataset.url = url;

    // Quick Star Button (Hover & Starred State)
    const starBtn = document.createElement('button');
    starBtn.type = 'button';
    starBtn.className = 'quick-star-btn';
    const isStarred = isUrlInFavorites(url);
    if (isStarred) starBtn.classList.add('is-starred');
    starBtn.setAttribute('aria-label', isStarred ? 'En favoritos' : 'Añadir a favoritos');
    starBtn.title = isStarred ? 'En favoritos' : 'Añadir a favoritos';
    starBtn.innerHTML = getStarIconSvg(isStarred);

    starBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleFavoriteFromCard(url, title, favIconUrl, starBtn);
    });
    itemContainer.appendChild(starBtn);

    const card = document.createElement('div');
    card.className = 'shortcut-card';
    const mode = getSectionViewMode(sectionType);
    const sameColor = !!state.settings.bookmarkSameColorAsFolder;
    const isFolderLiquid = (state.settings.folderColor === 'liquid-glass');
    const isLiquidBookmark = sameColor
      ? isFolderLiquid
      : ((state.settings.bookmarkColor === 'liquid-glass') || (isFolderLiquid && (state.settings.bookmarkColor === 'default' || !state.settings.bookmarkColor)));
    
    if (isLiquidBookmark) {
      card.classList.add('is-liquid-glass');
      if (mode === 'tile') {
        itemContainer.classList.add('is-liquid-glass');
      }
    }

    const domain = extractDomain(url || '');
    const cleanTitle = title || deriveNameFromDomain(domain) || domain || 'Página';
    const brand = getKnownBrand(domain);

    if (mode === 'thumb') {
      renderThumbnailCardInner(card, url, cleanTitle, domain, brand, favIconUrl);
    } else {
      const iconStyle = state.settings.iconStyle || 'uniform';
      if (brand && BRAND_SVGS[brand]) {
        card.innerHTML = BRAND_SVGS[brand];
        if (iconStyle === 'fullbleed') {
          card.classList.add('full-bleed');
        } else {
          card.classList.add('icon-uniform');
        }
      } else {
        if (iconStyle !== 'fullbleed') {
          card.classList.add('icon-uniform');
        }
        const iconUrl = favIconUrl || getFaviconUrl(domain);
        const img = document.createElement('img');
        img.className = 'shortcut-icon-img';
        img.src = iconUrl;
        img.alt = '';
        img.onerror = () => {
          card.innerHTML = '';
          const color = getColorForString(domain || cleanTitle);
          if (!isLiquidBookmark && !card.classList.contains('is-liquid-glass')) {
            card.style.backgroundColor = color;
          }
          const span = document.createElement('span');
          span.className = 'monogram-text';
          span.textContent = cleanTitle.trim().charAt(0).toUpperCase();
          card.appendChild(span);
        };
        card.appendChild(img);
      }
    }

    const infoWrap = document.createElement('div');
    infoWrap.className = 'shortcut-info';

    if (mode === 'thumb') {
      const fav = document.createElement('img');
      fav.className = 'shortcut-info-favicon';
      fav.src = favIconUrl || getFaviconUrl(domain);
      fav.alt = '';
      infoWrap.appendChild(fav);
    }

    const label = document.createElement('div');
    label.className = 'shortcut-label';
    label.textContent = cleanTitle;

    const urlEl = document.createElement('div');
    urlEl.className = 'shortcut-url';
    urlEl.textContent = url ? url.replace(/^https?:\/\//i, '').replace(/\/$/, '') : (domain || '');

    infoWrap.appendChild(label);
    infoWrap.appendChild(urlEl);

    itemContainer.appendChild(card);
    itemContainer.appendChild(infoWrap);

    // Store lowercase search index for instant filtering
    itemContainer.dataset.search = `${title || ''} ${cleanTitle} ${url || ''} ${domain}`.toLowerCase();

    itemContainer.addEventListener('click', clickHandler);

    // Middle click opens new tab
    itemContainer.addEventListener('auxclick', (e) => {
      if (e.button === 1 && url) {
        window.open(url, '_blank');
      }
    });

    // Right-click context menu
    itemContainer.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const pseudoItem = {
        type: 'url',
        title: cleanTitle,
        url: url,
        domain: domain,
        favIconUrl: favIconUrl
      };
      showContextMenu(e.clientX, e.clientY, pseudoItem, null, sectionType);
    });

    return itemContainer;
  }

  /**
   * Focus Search Bar (supports Ctrl+F / Cmd+F even if search bar is hidden)
   */
  function focusSearchBar() {
    if (!elQuickFilterInput) return;

    // If search bar is currently hidden via settings, reveal it temporarily
    if (elApp && elApp.classList.contains('hide-search-bar')) {
      elApp.classList.remove('hide-search-bar');
      elApp.classList.add('search-bar-temp-revealed');
    }

    closeSettingsModal();
    closeFolderModal();
    closeShortcutModal();

    elQuickFilterInput.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    setTimeout(() => {
      elQuickFilterInput.focus();
      elQuickFilterInput.select();
    }, 40);
  }

  /**
   * Quick Live Filter across all sections
   */
  function handleQuickFilter(query) {
    currentSearchQuery = (query || '').trim().toLowerCase();
    const hasQuery = Boolean(currentSearchQuery);
    if (elBtnClearSearch) {
      elBtnClearSearch.style.display = hasQuery ? 'flex' : 'none';
    }
    const elSearchDivider = document.getElementById('search-actions-divider');
    if (elSearchDivider) {
      elSearchDivider.style.display = hasQuery ? 'block' : 'none';
    }

    renderGrid();
    filterSectionGrid(elClosedTabsGrid, currentSearchQuery);
    filterSectionGrid(elHistoryGrid, currentSearchQuery);
  }

  function filterSectionGrid(gridEl, query) {
    if (!gridEl) return;
    const parentSection = gridEl.closest('.start-page-section');
    const secKey = (gridEl === elClosedTabsGrid) ? 'closedTabs' : 'history';

    // If the section is disabled in user settings, ensure it stays hidden
    if (state.settings.sections?.[secKey]?.enabled === false) {
      if (parentSection) {
        parentSection.classList.add('is-hidden');
        parentSection.classList.remove('search-no-match');
      }
      return;
    }

    const items = gridEl.querySelectorAll('.shortcut-item');
    let matchCount = 0;

    items.forEach(item => {
      if (!query) {
        item.classList.remove('is-filtered-out');
        item.removeAttribute('hidden');
        item.style.removeProperty('display');
        matchCount++;
        return;
      }

      const searchText = item.dataset.search || (
        (item.querySelector('.shortcut-label')?.textContent || '') + ' ' +
        (item.querySelector('.shortcut-url')?.textContent || '') + ' ' +
        (item.title || '')
      ).toLowerCase();

      const matches = searchText.includes(query);

      item.classList.toggle('is-filtered-out', !matches);
      if (!matches) {
        item.setAttribute('hidden', '');
        item.style.setProperty('display', 'none', 'important');
      } else {
        item.removeAttribute('hidden');
        item.style.removeProperty('display');
        matchCount++;
      }
    });

    if (parentSection) {
      if (query) {
        if (matchCount === 0) {
          parentSection.classList.add('search-no-match');
        } else {
          parentSection.classList.remove('search-no-match');
          parentSection.classList.remove('is-collapsed');
        }
      } else {
        parentSection.classList.remove('search-no-match');
        updateSectionCollapseUI(secKey, parentSection);
      }
    }
  }

  /**
   * Helper: Filter out internal, extension and blank/new tab pages from closed tabs and history
   */
  function isIgnoredTab(url, title) {
    if (!url || typeof url !== 'string') return true;
    const trimmedUrl = url.trim().toLowerCase();
    if (
      trimmedUrl.startsWith('about:') ||
      trimmedUrl.startsWith('chrome:') ||
      trimmedUrl.startsWith('moz-extension:') ||
      trimmedUrl.startsWith('chrome-extension:') ||
      trimmedUrl.startsWith('edge:') ||
      trimmedUrl.startsWith('view-source:') ||
      trimmedUrl.startsWith('data:') ||
      trimmedUrl.startsWith('blob:') ||
      trimmedUrl.startsWith('javascript:') ||
      trimmedUrl.includes('newtab.html')
    ) {
      return true;
    }

    if (!trimmedUrl.startsWith('http://') && !trimmedUrl.startsWith('https://') && !trimmedUrl.startsWith('file://')) {
      return true;
    }

    return false;
  }

  /**
   * Recently Closed Tabs
   */
  async function loadRecentlyClosedTabs() {
    if (!elClosedTabsGrid) return;
    if (!browserAPI.sessions || !browserAPI.sessions.getRecentlyClosed) {
      if (elClosedTabsEmpty) elClosedTabsEmpty.style.display = 'block';
      return;
    }

    try {
      let sessions = [];
      try {
        sessions = await browserAPI.sessions.getRecentlyClosed({ maxResults: 25 });
      } catch (e1) {
        sessions = await browserAPI.sessions.getRecentlyClosed();
      }
      renderRecentlyClosedTabs(sessions);
    } catch (err) {
      console.warn('Error fetching closed tabs:', err);
      if (elClosedTabsEmpty) elClosedTabsEmpty.style.display = 'block';
    }
  }

  function renderRecentlyClosedTabs(sessions) {
    lastClosedTabsSessions = sessions;
    elClosedTabsGrid.innerHTML = '';
    const tabsList = [];
    const seenUrls = new Set();

    for (const sess of (sessions || [])) {
      if (sess.tab && sess.tab.url) {
        if (!isIgnoredTab(sess.tab.url, sess.tab.title)) {
          if (!seenUrls.has(sess.tab.url)) {
            seenUrls.add(sess.tab.url);
            tabsList.push({
              sessionId: sess.tab.sessionId,
              url: sess.tab.url,
              title: sess.tab.title || extractDomain(sess.tab.url),
              favIconUrl: sess.tab.favIconUrl
            });
          }
        }
      } else if (sess.window && sess.window.tabs) {
        for (const tab of sess.window.tabs) {
          if (tab.url && !isIgnoredTab(tab.url, tab.title)) {
            if (!seenUrls.has(tab.url)) {
              seenUrls.add(tab.url);
              tabsList.push({
                sessionId: tab.sessionId || sess.window.sessionId,
                url: tab.url,
                title: tab.title || extractDomain(tab.url),
                favIconUrl: tab.favIconUrl
              });
            }
          }
        }
      }
      if (tabsList.length >= 24) break;
    }

    if (tabsList.length === 0) {
      if (elClosedTabsEmpty) elClosedTabsEmpty.style.display = 'block';
      return;
    } else {
      if (elClosedTabsEmpty) elClosedTabsEmpty.style.display = 'none';
    }

    tabsList.forEach(tab => {
      const cardEl = createSimpleCardElement(tab.title, tab.url, tab.favIconUrl, (e) => {
        if (tab.sessionId && browserAPI.sessions && browserAPI.sessions.restore) {
          browserAPI.sessions.restore(tab.sessionId).catch(() => {
            openBookmark(tab.url, true);
          });
        } else {
          openBookmark(tab.url, true);
        }
        setTimeout(loadRecentlyClosedTabs, 600);
      }, 'closedTabs');
      elClosedTabsGrid.appendChild(cardEl);
    });

    if (currentSearchQuery) {
      filterSectionGrid(elClosedTabsGrid, currentSearchQuery);
    }
    requestAnimationFrame(() => LiquidGlassEngine.render());
  }

  /**
   * Browsing History
   */
  async function loadBrowsingHistory() {
    if (!elHistoryGrid) return;
    if (!browserAPI.history || !browserAPI.history.search) {
      if (elHistoryEmpty) elHistoryEmpty.style.display = 'block';
      return;
    }

    try {
      const results = await browserAPI.history.search({
        text: '',
        maxResults: 50,
        startTime: 0
      });
      renderBrowsingHistory(results);
    } catch (err) {
      console.warn('Error fetching browsing history:', err);
      if (elHistoryEmpty) elHistoryEmpty.style.display = 'block';
    }
  }

  function renderBrowsingHistory(results) {
    lastHistoryResults = results;
    elHistoryGrid.innerHTML = '';
    const seenUrls = new Set();
    const validItems = [];

    for (const item of (results || [])) {
      if (!item.url || isIgnoredTab(item.url, item.title)) continue;
      if (seenUrls.has(item.url)) continue;
      seenUrls.add(item.url);
      validItems.push(item);
      if (validItems.length >= 24) break;
    }

    if (validItems.length === 0) {
      if (elHistoryEmpty) elHistoryEmpty.style.display = 'block';
      return;
    } else {
      if (elHistoryEmpty) elHistoryEmpty.style.display = 'none';
    }

    validItems.forEach(item => {
      const cardEl = createSimpleCardElement(item.title, item.url, null, (e) => {
        openBookmark(item.url, e.metaKey || e.ctrlKey);
      }, 'history');
      elHistoryGrid.appendChild(cardEl);
    });

    if (currentSearchQuery) {
      filterSectionGrid(elHistoryGrid, currentSearchQuery);
    }
    requestAnimationFrame(() => LiquidGlassEngine.render());
  }

  /**
   * Wire Event Listeners
   */
  function setupEventListeners() {
    // Liquid Glass dynamic specular reflection & lens refraction tracking (based on WebGL liquid glass shader)
    document.addEventListener('mousemove', (e) => {
      const target = e.target.closest && e.target.closest(
        '.is-liquid-glass, ' +
        '.has-liquid-glass-folders .shortcut-card.folder-card, ' +
        '.has-liquid-glass-bookmarks .shortcut-card:not(.folder-card), ' +
        '#folder-settings-preview.is-liquid-glass, ' +
        '#bookmark-settings-preview.is-liquid-glass, ' +
        '.folder-view-window.is-liquid-glass, ' +
        '.color-liquid-glass-option, ' +
        '.has-liquid-glass .floating-settings-btn'
      );
      if (target) {
        const rect = target.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          const x = Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100)));
          const y = Math.max(0, Math.min(100, Math.round(((e.clientY - rect.top) / rect.height) * 100)));
          target.style.setProperty('--liquid-x', `${x}%`);
          target.style.setProperty('--liquid-y', `${y}%`);
        }
      }
    }, { passive: true });

    document.addEventListener('mouseout', (e) => {
      const target = e.target.closest && e.target.closest(
        '.is-liquid-glass, ' +
        '.has-liquid-glass-folders .shortcut-card.folder-card, ' +
        '.has-liquid-glass-bookmarks .shortcut-card:not(.folder-card), ' +
        '#folder-settings-preview.is-liquid-glass, ' +
        '#bookmark-settings-preview.is-liquid-glass, ' +
        '.folder-view-window.is-liquid-glass, ' +
        '.color-liquid-glass-option, ' +
        '.has-liquid-glass .floating-settings-btn'
      );
      if (target && (!e.relatedTarget || !target.contains(e.relatedTarget))) {
        target.style.removeProperty('--liquid-x');
        target.style.removeProperty('--liquid-y');
      }
    }, { passive: true });

    // Quick Add Buttons
    if (elBtnAddShortcut) elBtnAddShortcut.addEventListener('click', () => openAddShortcutModal(state.activeFolderId));
    if (elBtnAddFolder) elBtnAddFolder.addEventListener('click', () => openAddFolderModal());
    if (elBtnEmptyAdd) elBtnEmptyAdd.addEventListener('click', () => openAddShortcutModal());

    // Listen for background thumbnail updates (e.g. from passive tab visits or background captures)
    if (browserAPI.runtime && browserAPI.runtime.onMessage) {
      browserAPI.runtime.onMessage.addListener((msg) => {
        if (msg && msg.action === 'thumbnailUpdated' && msg.url && msg.dataUrl) {
          const key = getThumbKey(msg.url);
          if (key) {
            let cachedSrc = msg.dataUrl;
            const blob = dataUrlToBlob(msg.dataUrl);
            if (blob) {
              const oldSrc = thumbCache.get(key);
              if (oldSrc && typeof oldSrc === 'string' && oldSrc.startsWith('blob:')) {
                try { URL.revokeObjectURL(oldSrc); } catch (e) {}
              }
              try {
                cachedSrc = URL.createObjectURL(blob);
              } catch (e) {
                cachedSrc = msg.dataUrl;
              }
            }
            thumbCache.set(key, cachedSrc);
            fallbackThumbKeys.delete(key);
            updateCardThumbnails(msg.url, cachedSrc);
          }
        }
      });
    }

    // Start Page Top Bar: Quick Search Filter
    if (elQuickFilterInput) {
      elQuickFilterInput.addEventListener('input', (e) => {
        handleQuickFilter(e.target.value);
      });
      elQuickFilterInput.addEventListener('blur', () => {
        if (elApp && elApp.classList.contains('search-bar-temp-revealed') && !elQuickFilterInput.value.trim()) {
          elApp.classList.remove('search-bar-temp-revealed');
          elApp.classList.add('hide-search-bar');
        }
      });
    }
    if (elBtnClearSearch) {
      elBtnClearSearch.addEventListener('click', () => {
        if (elQuickFilterInput) elQuickFilterInput.value = '';
        handleQuickFilter('');
        if (elQuickFilterInput) elQuickFilterInput.focus();
      });
    }

    // View Mode Dropdown Trigger
    if (elViewModeDropdownBtn) {
      elViewModeDropdownBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = elViewModeMenu && elViewModeMenu.style.display !== 'none';
        toggleViewModeDropdown(!isOpen);
      });
    }

    // View Mode Menu Options
    if (elBtnViewGrid) {
      elBtnViewGrid.addEventListener('click', (e) => {
        e.stopPropagation();
        setViewMode('grid');
        toggleViewModeDropdown(false);
      });
    }
    if (elBtnViewTile) {
      elBtnViewTile.addEventListener('click', (e) => {
        e.stopPropagation();
        setViewMode('tile');
        toggleViewModeDropdown(false);
      });
    }
    if (elBtnViewThumb) {
      elBtnViewThumb.addEventListener('click', (e) => {
        e.stopPropagation();
        setViewMode('thumb');
        toggleViewModeDropdown(false);
      });
    }

    // Close view mode dropdown on click outside or Escape
    document.addEventListener('click', (e) => {
      if (elViewModeDropdownWrap && !elViewModeDropdownWrap.contains(e.target)) {
        toggleViewModeDropdown(false);
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        toggleViewModeDropdown(false);
      }
    });

    // Floating Section View Mode Dropdowns
    setupSectionViewModeDropdowns();



    // Icon Style Setting (Uniform vs Full-bleed)
    if (elSettingIconStyle) {
      elSettingIconStyle.addEventListener('change', (e) => {
        state.settings.iconStyle = e.target.value || 'uniform';
        saveState();
        renderGrid();
        loadRecentlyClosedTabs();
        loadBrowsingHistory();
      });
    }

    // Settings Modal
    if (elBtnOpenSettings) {
      elBtnOpenSettings.addEventListener('click', () => {
        if (elSettingsModal && elSettingsModal.style.display !== 'none') {
          closeSettingsModal();
        } else {
          openSettingsModal();
        }
      });
    }
    if (elBtnCloseSettings) elBtnCloseSettings.addEventListener('click', closeSettingsModal);
    if (elBtnSaveSettings) elBtnSaveSettings.addEventListener('click', closeSettingsModal);

    // Steppers: Size & Spacing
    if (elBtnSizeMinus) elBtnSizeMinus.addEventListener('click', () => adjustSize(-4));
    if (elBtnSizePlus) elBtnSizePlus.addEventListener('click', () => adjustSize(4));
    if (elBtnGapMinus) elBtnGapMinus.addEventListener('click', () => adjustGap(-4));
    if (elBtnGapPlus) elBtnGapPlus.addEventListener('click', () => adjustGap(4));

    // Section Collapse Toggles
    if (elBtnToggleClosedTabs) elBtnToggleClosedTabs.addEventListener('click', () => toggleSection('closedTabs'));
    if (elBtnToggleHistory) elBtnToggleHistory.addEventListener('click', () => toggleSection('history'));

    // Section Visibility Switches in Settings
    if (elSettingShowFavorites) {
      elSettingShowFavorites.addEventListener('change', (e) => {
        ensureSectionsSettings();
        state.settings.sections.favorites.enabled = e.target.checked;
        updateSectionsUI();
        saveState();
      });
    }
    if (elSettingShowClosedTabs) {
      elSettingShowClosedTabs.addEventListener('change', (e) => {
        ensureSectionsSettings();
        state.settings.sections.closedTabs.enabled = e.target.checked;
        updateSectionsUI();
        saveState();
        if (e.target.checked) loadRecentlyClosedTabs();
      });
    }
    if (elSettingShowHistory) {
      elSettingShowHistory.addEventListener('change', (e) => {
        ensureSectionsSettings();
        state.settings.sections.history.enabled = e.target.checked;
        updateSectionsUI();
        saveState();
        if (e.target.checked) loadBrowsingHistory();
      });
    }

    // Auto-refresh when tab gains focus or on session/history events
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        if (state.settings.sections?.closedTabs?.enabled !== false) loadRecentlyClosedTabs();
        if (state.settings.sections?.history?.enabled !== false) loadBrowsingHistory();
      }
    });

    if (browserAPI.sessions && browserAPI.sessions.onChanged) {
      browserAPI.sessions.onChanged.addListener(() => {
        if (state.settings.sections?.closedTabs?.enabled !== false) {
          loadRecentlyClosedTabs();
        }
      });
    }
    if (browserAPI.history && browserAPI.history.onVisited) {
      browserAPI.history.onVisited.addListener(() => {
        if (state.settings.sections?.history?.enabled !== false) {
          loadBrowsingHistory();
        }
      });
    }

    // Passive capture when user browses to bookmarked favorites
    if (browserAPI.tabs && browserAPI.tabs.onUpdated) {
      browserAPI.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        if (changeInfo.status === 'complete' && tab.url && !tab.url.startsWith('about:') && !tab.url.startsWith('chrome:')) {
          if (isUrlInFavorites(tab.url)) {
            setTimeout(async () => {
              try {
                if (!browserAPI.tabs.captureTab) return;
                const rawDataUrl = await browserAPI.tabs.captureTab(tabId, { format: 'jpeg', quality: 85 });
                if (rawDataUrl) {
                  const optimized = await downscaleImage(rawDataUrl, 480, 270);
                  await saveThumbnail(tab.url, optimized);
                }
              } catch (e) {}
            }, 800);
          }
        }
      });
    }

    // Section title edit (if present)
    if (elSettingTitleInput) {
      elSettingTitleInput.addEventListener('input', (e) => {
        state.settings.title = e.target.value.trim() || 'Favoritos';
        const activeSec = getActiveFavoriteSection();
        if (activeSec) {
          activeSec.title = state.settings.title;
        }
        if (elSectionTitle) elSectionTitle.textContent = state.settings.title;
        renderFavoriteSectionsBar();
        saveState();
      });
    }

    // Theme Selector: Selecting ANY visual theme (Safari Dark, OLED, Sonoma Glass, Safari Claro, Color) REMOVES the wallpaper immediately!
    document.querySelectorAll('.theme-option').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const theme = btn.dataset.theme;
        state.settings.theme = theme;
        state.settings.customWallpaper = 'none';
        state.settings.wallpaperInitialized = true;
        if (theme === 'custom' && elInputCustomBgColor && e.target !== elInputCustomBgColor) {
          elInputCustomBgColor.click();
        }
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
    });

    // Custom Background Color Picker
    if (elInputCustomBgColor) {
      const applyCustomBg = (color) => {
        state.settings.theme = 'custom';
        state.settings.customBgColor = color;
        state.settings.customWallpaper = 'none';
        state.settings.wallpaperInitialized = true;
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      };

      elInputCustomBgColor.addEventListener('input', (e) => {
        applyCustomBg(e.target.value);
      });
      elInputCustomBgColor.addEventListener('change', (e) => {
        applyCustomBg(e.target.value);
      });
    }

    // Show Search Bar Toggle
    if (elSettingShowSearch) {
      elSettingShowSearch.addEventListener('change', (e) => {
        state.settings.showSearchBar = e.target.checked;
        applySettings();
        saveState();
      });
    }

    // Centered Search Bar Toggle
    if (elSettingCenterSearch) {
      elSettingCenterSearch.addEventListener('change', (e) => {
        state.settings.searchBarCenter = e.target.checked;
        applySettings();
        saveState();
      });
    }

    // Expand Screen Toggle
    if (elSettingExpandScreen) {
      elSettingExpandScreen.addEventListener('change', (e) => {
        state.settings.expandScreen = e.target.checked;
        applySettings();
        saveState();
      });
    }

    // Panel Labels Size Dropdown
    if (elSettingPanelLabels) {
      elSettingPanelLabels.addEventListener('change', (e) => {
        state.settings.panelLabelSize = e.target.value;
        applySettings();
        saveState();
      });
    }

    // Liquid Glass Settings Controls
    if (!state.settings.liquidGlass) {
      state.settings.liquidGlass = {
        refraction: 0.08,
        blur: 0.8,
        bevel: 0.35,
        useMouseLight: false
      };
    }

    if (elSettingLiquidRefraction) {
      elSettingLiquidRefraction.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        if (!state.settings.liquidGlass) state.settings.liquidGlass = {};
        state.settings.liquidGlass.refraction = val;
        if (elDisplayLiquidRefraction) elDisplayLiquidRefraction.textContent = val.toFixed(2);
        LiquidGlassEngine.updateConfig({ refraction: val });
        LiquidGlassEngine.render();
        saveState();
      });
    }

    if (elSettingLiquidBlur) {
      elSettingLiquidBlur.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        if (!state.settings.liquidGlass) state.settings.liquidGlass = {};
        state.settings.liquidGlass.blur = val;
        if (elDisplayLiquidBlur) elDisplayLiquidBlur.textContent = val.toFixed(1);
        LiquidGlassEngine.updateConfig({ blur: val });
        LiquidGlassEngine.render();
        saveState();
      });
    }

    if (elSettingLiquidBevel) {
      elSettingLiquidBevel.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        if (!state.settings.liquidGlass) state.settings.liquidGlass = {};
        state.settings.liquidGlass.bevel = val;
        if (elDisplayLiquidBevel) elDisplayLiquidBevel.textContent = val.toFixed(2);
        LiquidGlassEngine.updateConfig({ bevel: val });
        LiquidGlassEngine.render();
        saveState();
      });
    }

    if (elSettingLiquidMouseLight) {
      elSettingLiquidMouseLight.addEventListener('change', (e) => {
        const val = e.target.checked;
        if (!state.settings.liquidGlass) state.settings.liquidGlass = {};
        state.settings.liquidGlass.useMouseLight = val;
        LiquidGlassEngine.updateConfig({ useMouseLight: val });
        LiquidGlassEngine.render();
        saveState();
      });
    }

    if (elBtnResetLiquid) {
      elBtnResetLiquid.addEventListener('click', () => {
        const defaultLg = {
          refraction: 0.08,
          blur: 0.8,
          bevel: 0.35,
          useMouseLight: false
        };
        state.settings.liquidGlass = { ...defaultLg };
        LiquidGlassEngine.updateConfig(defaultLg);
        LiquidGlassEngine.render();
        if (elSettingLiquidRefraction) elSettingLiquidRefraction.value = defaultLg.refraction;
        if (elDisplayLiquidRefraction) elDisplayLiquidRefraction.textContent = defaultLg.refraction.toFixed(2);
        if (elSettingLiquidBlur) elSettingLiquidBlur.value = defaultLg.blur;
        if (elDisplayLiquidBlur) elDisplayLiquidBlur.textContent = defaultLg.blur.toFixed(1);
        if (elSettingLiquidBevel) elSettingLiquidBevel.value = defaultLg.bevel;
        if (elDisplayLiquidBevel) elDisplayLiquidBevel.textContent = defaultLg.bevel.toFixed(2);
        if (elSettingLiquidMouseLight) elSettingLiquidMouseLight.checked = defaultLg.useMouseLight;
        saveState();
      });
    }

    // Categorized Settings Sliding Subpanel Navigation
    document.querySelectorAll('.settings-nav-row[data-subpanel]').forEach(row => {
      row.addEventListener('click', () => {
        openSettingsSubpanel(row.dataset.subpanel);
      });
      row.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openSettingsSubpanel(row.dataset.subpanel);
        }
      });
    });

    document.querySelectorAll('.settings-back-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        returnToMainSettings();
      });
    });

    // Language Selection in Language Subpanel
    document.querySelectorAll('.settings-language-option').forEach(opt => {
      const selectLanguage = () => {
        const nextLang = opt.dataset.lang;
        if (nextLang && nextLang !== state.settings.language) {
          state.settings.language = nextLang;
          applyTranslations(nextLang);
          applySettings();
          saveState();
          renderGrid();
          loadRecentlyClosedTabs();
          loadBrowsingHistory();
        }
      };

      opt.addEventListener('click', selectLanguage);
      opt.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          selectLanguage();
        }
      });
    });

    // Folder Color Palette & Custom Picker
    if (elFolderColorPalette) {
      elFolderColorPalette.querySelectorAll('.folder-color-option').forEach(opt => {
        opt.addEventListener('click', () => {
          const color = opt.dataset.color;
          state.settings.folderColor = color;
          if (state.settings.bookmarkSameColorAsFolder || (color === 'liquid-glass' && (state.settings.bookmarkColor === 'default' || !state.settings.bookmarkColor))) {
            state.settings.bookmarkColor = color;
          }
          applySettings();
          saveState();
          renderGrid();
          if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
          else loadRecentlyClosedTabs();
          if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
          else loadBrowsingHistory();
          requestAnimationFrame(() => LiquidGlassEngine.render());
        });
      });
    }
    if (elFolderCustomColorInput) {
      elFolderCustomColorInput.addEventListener('input', (e) => {
        const color = e.target.value;
        state.settings.folderColor = color;
        if (state.settings.bookmarkSameColorAsFolder) {
          state.settings.bookmarkColor = color;
        }
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
    }

    // Folder Animation Toggle
    if (elSettingFolderAnimation) {
      elSettingFolderAnimation.addEventListener('change', (e) => {
        state.settings.folderAnimation = e.target.checked;
        saveState();
      });
    }

    // Bookmark Same Color as Folder Toggle
    if (elSettingBookmarkSameColor) {
      elSettingBookmarkSameColor.addEventListener('change', (e) => {
        const isChecked = e.target.checked;
        state.settings.bookmarkSameColorAsFolder = isChecked;
        if (isChecked) {
          const currentFolderColor = state.settings.folderColor || '#3a3a3e';
          state.settings.bookmarkColor = currentFolderColor;
        }
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
    }

    // Bookmark Color Palette & Custom Picker
    if (elBookmarkColorPalette) {
      elBookmarkColorPalette.querySelectorAll('.folder-color-option').forEach(opt => {
        opt.addEventListener('click', () => {
          const color = opt.dataset.color;
          state.settings.bookmarkColor = color;
          state.settings.bookmarkSameColorAsFolder = false;
          applySettings();
          saveState();
          renderGrid();
          if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
          else loadRecentlyClosedTabs();
          if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
          else loadBrowsingHistory();
          if (state.activeFolderId) renderFolderView();
          requestAnimationFrame(() => LiquidGlassEngine.render());
        });
      });
    }
    if (elBookmarkCustomColorInput) {
      elBookmarkCustomColorInput.addEventListener('input', (e) => {
        const color = e.target.value;
        state.settings.bookmarkColor = color;
        state.settings.bookmarkSameColorAsFolder = false;
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        if (state.activeFolderId) renderFolderView();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
    }

    // Custom Wallpaper & Presets Gallery
    if (elWpPresetGalaxy) {
      elWpPresetGalaxy.addEventListener('click', () => {
        state.settings.customWallpaper = 'wallpapers/galaxy.jpg';
        state.settings.wallpaperInitialized = true;
        applySettings();
        saveState();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
      elWpPresetGalaxy.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          elWpPresetGalaxy.click();
        }
      });
    }

    if (elWpPresetAurora) {
      elWpPresetAurora.addEventListener('click', () => {
        state.settings.customWallpaper = 'wallpapers/aurora.jpg';
        state.settings.wallpaperInitialized = true;
        applySettings();
        saveState();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
      elWpPresetAurora.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          elWpPresetAurora.click();
        }
      });
    }

    if (elWpPresetCustom) {
      elWpPresetCustom.addEventListener('click', () => {
        if (elWpPresetCustom.dataset.customWp) {
          state.settings.customWallpaper = elWpPresetCustom.dataset.customWp;
          state.settings.wallpaperInitialized = true;
          applySettings();
          saveState();
          requestAnimationFrame(() => LiquidGlassEngine.render());
        } else if (elInputWallpaperFile) {
          elInputWallpaperFile.click();
        }
      });
      elWpPresetCustom.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          elWpPresetCustom.click();
        }
      });
    }

    if (elBtnUploadWallpaper && elInputWallpaperFile) {
      elBtnUploadWallpaper.addEventListener('click', () => {
        elInputWallpaperFile.click();
      });
      elInputWallpaperFile.addEventListener('change', (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
          const dataUrl = event.target.result;
          state.settings.customWallpaper = dataUrl;
          state.settings.wallpaperInitialized = true;
          if (elWpPresetCustom) {
            elWpPresetCustom.dataset.customWp = dataUrl;
            elWpPresetCustom.style.display = 'flex';
          }
          if (elWpPresetCustomImg) {
            elWpPresetCustomImg.style.backgroundImage = 'url(' + dataUrl + ')';
          }
          applySettings();
          saveState();
          requestAnimationFrame(() => LiquidGlassEngine.render());
        };
        reader.readAsDataURL(file);
        elInputWallpaperFile.value = '';
      });
    }
    if (elBtnRemoveWallpaper) {
      elBtnRemoveWallpaper.addEventListener('click', () => {
        state.settings.customWallpaper = 'none';
        state.settings.wallpaperInitialized = true;
        state.settings.theme = 'oled';
        applySettings();
        saveState();
        renderGrid();
        if (lastClosedTabsSessions) renderRecentlyClosedTabs(lastClosedTabsSessions);
        else loadRecentlyClosedTabs();
        if (lastHistoryResults) renderBrowsingHistory(lastHistoryResults);
        else loadBrowsingHistory();
        requestAnimationFrame(() => LiquidGlassEngine.render());
      });
    }

    // Reimport all bookmarks action
    if (elBtnResyncBookmarks) {
      elBtnResyncBookmarks.addEventListener('click', async () => {
        if (confirm(t('confirmReimportFirefox'))) {
          await importFromFirefoxBookmarks();
          renderGrid();
          closeSettingsModal();
        }
      });
    }

    // Import bookmarks from HTML file (Chrome, Safari, Edge, etc.)
    if (elBtnImportBrowserFile && elInputImportFile) {
      elBtnImportBrowserFile.addEventListener('click', () => {
        elInputImportFile.click();
      });

      elInputImportFile.addEventListener('change', (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
          const htmlContent = event.target.result;
          const importedItems = parseBookmarkHtml(htmlContent);
          if (importedItems.length > 0) {
            state.items = state.items.concat(importedItems);
            saveState();
            renderGrid();
            closeSettingsModal();
            showToast(t('toastAddedFavorite', { title: `${importedItems.length}` }));
          }
        };
        reader.readAsText(file);
        elInputImportFile.value = '';
      });
    }

    // Clear Page action ("Limpiar página")
    if (elBtnClearPage) {
      elBtnClearPage.addEventListener('click', () => {
        if (confirm(t('confirmClearPage'))) {
          state.items = [];
          saveState();
          renderGrid();
          closeSettingsModal();
        }
      });
    }

    // Shortcut Modal
    if (elBtnCloseShortcut) elBtnCloseShortcut.addEventListener('click', closeShortcutModal);
    if (elBtnCancelShortcut) elBtnCancelShortcut.addEventListener('click', closeShortcutModal);
    if (elShortcutForm) elShortcutForm.addEventListener('submit', handleSaveShortcut);

    // Dynamic auto-naming & preview on input change
    if (elShortcutUrlInput) {
      elShortcutUrlInput.addEventListener('input', () => {
        const urlVal = elShortcutUrlInput.value.trim();
        const domain = extractDomain(urlVal);
        if (isNameAutoGenerated || !elShortcutNameInput.value.trim()) {
          const suggested = deriveNameFromDomain(domain);
          if (suggested && elShortcutNameInput) elShortcutNameInput.value = suggested;
        }
        updatePreviewCard(elShortcutNameInput ? elShortcutNameInput.value : '', urlVal);
      });
    }

    if (elShortcutNameInput) {
      elShortcutNameInput.addEventListener('input', () => {
        isNameAutoGenerated = false;
        updatePreviewCard(elShortcutNameInput.value, elShortcutUrlInput ? elShortcutUrlInput.value : '');
      });
    }

    // Folder Modal
    if (elBtnCloseFolderModal) elBtnCloseFolderModal.addEventListener('click', closeFolderModal);
    if (elBtnCancelFolder) elBtnCancelFolder.addEventListener('click', closeFolderModal);
    if (elFolderForm) elFolderForm.addEventListener('submit', handleSaveFolder);

    // Folder View Modal
    if (elBtnCloseFolderView) elBtnCloseFolderView.addEventListener('click', closeFolderView);
    if (elBtnFolderAddShortcut) {
      elBtnFolderAddShortcut.addEventListener('click', () => {
        openAddShortcutModal(state.activeFolderId);
      });
    }

    // Dismiss Modals when clicking on backdrop outside container
    if (elSettingsModal) {
      elSettingsModal.addEventListener('click', (e) => {
        if (e.target === elSettingsModal) closeSettingsModal();
      });
    }
    if (elFolderViewModal) {
      elFolderViewModal.addEventListener('click', (e) => {
        if (e.target === elFolderViewModal) closeFolderView();
      });
    }
    if (elShortcutModal) {
      elShortcutModal.addEventListener('click', (e) => {
        if (e.target === elShortcutModal) closeShortcutModal();
      });
    }
    if (elFolderModal) {
      elFolderModal.addEventListener('click', (e) => {
        if (e.target === elFolderModal) closeFolderModal();
      });
    }

    // Context Menu Items
    if (elCtxOpenNewTab) {
      elCtxOpenNewTab.addEventListener('click', () => {
        if (contextTarget.item && contextTarget.item.url) {
          openBookmark(contextTarget.item.url, true);
        }
        hideContextMenu();
      });
    }

    if (elCtxOpenNewWindow) {
      elCtxOpenNewWindow.addEventListener('click', () => {
        if (contextTarget.item && contextTarget.item.url) {
          openBookmarkInNewWindow(contextTarget.item.url);
        }
        hideContextMenu();
      });
    }

    if (elCtxAddToFavorites) {
      elCtxAddToFavorites.addEventListener('click', () => {
        const item = contextTarget.item;
        hideContextMenu();
        if (!item || !item.url) return;
        addUrlToFavorites(item.url, item.title, item.favIconUrl);
      });
    }

    if (elCtxCustomThumbnail && elInputCustomThumb) {
      elCtxCustomThumbnail.addEventListener('click', () => {
        const item = contextTarget.item;
        hideContextMenu();
        if (!item || !item.url) return;
        elInputCustomThumb.onchange = async (e) => {
          const file = e.target.files && e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = async (ev) => {
            const raw = ev.target.result;
            const optimized = await downscaleImage(raw, 480, 270);
            item.customThumbnail = optimized;
            saveState();
            if (state.activeFolderId) {
              renderFolderView();
            } else {
              renderGrid();
            }
            showToast(t('toastCustomThumbSaved', { title: item.title || item.domain }));
          };
          reader.readAsDataURL(file);
          elInputCustomThumb.value = '';
        };
        elInputCustomThumb.click();
      });
    }

    if (elCtxRemoveCustomThumbnail) {
      elCtxRemoveCustomThumbnail.addEventListener('click', () => {
        const item = contextTarget.item;
        hideContextMenu();
        if (!item) return;
        delete item.customThumbnail;
        saveState();
        if (state.activeFolderId) {
          renderFolderView();
        } else {
          renderGrid();
        }
        showToast(t('toastCustomThumbRemoved'));
      });
    }

    if (elCtxEdit) {
      elCtxEdit.addEventListener('click', () => {
        const item = contextTarget.item;
        const folderId = contextTarget.folderId;
        hideContextMenu();
        if (!item) return;

        if (item.type === 'folder') {
          openAddFolderModal(item);
        } else {
          openEditShortcutModal(item, folderId);
        }
      });
    }

    if (elCtxMoveFolder) {
      elCtxMoveFolder.addEventListener('click', () => {
        const item = contextTarget.item;
        const folderId = contextTarget.folderId;
        hideContextMenu();
        if (!item || item.type === 'folder') return;
        openEditShortcutModal(item, folderId);
      });
    }

    if (elCtxDelete) {
      elCtxDelete.addEventListener('click', () => {
        const item = contextTarget.item;
        const folderId = contextTarget.folderId;
        hideContextMenu();
        if (!item) return;

        if (confirm(t('confirmDeleteItem', { title: item.title }))) {
          deleteItem(item, folderId);
        }
      });
    }

    // Background context menu click -> New Shortcut & New Folder
    if (elBgCtxNewShortcut) {
      elBgCtxNewShortcut.addEventListener('click', () => {
        hideBgContextMenu();
        openAddShortcutModal(state.activeFolderId);
      });
    }

    if (elBgCtxNewFolder) {
      elBgCtxNewFolder.addEventListener('click', () => {
        hideBgContextMenu();
        openAddFolderModal();
      });
    }



    // Background context menu click -> open settings modal
    if (elBgCtxSettings) {
      elBgCtxSettings.addEventListener('click', () => {
        hideBgContextMenu();
        openSettingsModal();
      });
    }

    // Background context menu click -> toggle closed tabs
    if (elBgCtxToggleClosedTabs) {
      elBgCtxToggleClosedTabs.addEventListener('click', () => {
        ensureSectionsSettings();
        state.settings.sections.closedTabs.enabled = !state.settings.sections.closedTabs.enabled;
        updateSectionsUI();
        saveState();
        if (state.settings.sections.closedTabs.enabled) loadRecentlyClosedTabs();
        hideBgContextMenu();
      });
    }

    // Background context menu click -> toggle history
    if (elBgCtxToggleHistory) {
      elBgCtxToggleHistory.addEventListener('click', () => {
        ensureSectionsSettings();
        state.settings.sections.history.enabled = !state.settings.sections.history.enabled;
        updateSectionsUI();
        saveState();
        if (state.settings.sections.history.enabled) loadBrowsingHistory();
        hideBgContextMenu();
      });
    }

    // Background context menu click -> toggle search bar
    if (elBgCtxToggleSearch) {
      elBgCtxToggleSearch.addEventListener('click', () => {
        state.settings.showSearchBar = (state.settings.showSearchBar === false) ? true : false;
        applySettings();
        saveState();
        hideBgContextMenu();
      });
    }

    // Buy Me a Coffee button feedback toast
    if (elBtnBuyCoffee) {
      elBtnBuyCoffee.addEventListener('click', () => {
        showToast(t('toastCoffeeThanks'));
      });
    }

    // Favorite Sections: Add Section Button
    if (elBtnAddSection) {
      elBtnAddSection.addEventListener('click', () => {
        addNewFavoriteSection();
      });
    }

    // Tab Context Menu Items
    if (elTabCtxRename) {
      elTabCtxRename.addEventListener('click', () => {
        const secId = contextTargetTabSectionId;
        hideTabContextMenu();
        if (secId) {
          const tabEl = elFavoritesTabBar?.querySelector(`.fav-section-tab[data-section-id="${secId}"]`);
          if (tabEl) startInlineRename(secId, tabEl);
        }
      });
    }

    if (elTabCtxNewSection) {
      elTabCtxNewSection.addEventListener('click', () => {
        hideTabContextMenu();
        addNewFavoriteSection();
      });
    }

    if (elTabCtxDelete) {
      elTabCtxDelete.addEventListener('click', () => {
        const secId = contextTargetTabSectionId;
        hideTabContextMenu();
        if (secId) {
          deleteFavoriteSection(secId);
        }
      });
    }

    // Background Right-Click: show popup with Ajustes
    window.addEventListener('contextmenu', (e) => {
      // If clicking inside a shortcut item, tab, modal card, or existing menu, ignore here
      if (e.target.closest('.shortcut-item') || e.target.closest('.fav-section-tab') || e.target.closest('.btn-add-section') || e.target.closest('.modal-card') || e.target.closest('.context-menu')) {
        return;
      }
      e.preventDefault();
      showBgContextMenu(e.clientX, e.clientY);
    });

    // Initialize Universal Pointer Events Drag and Drop Engine
    setupPointerDragAndDrop();

    // Global click to dismiss context menus
    window.addEventListener('click', (e) => {
      if (!elContextMenu.contains(e.target) && (!elBgContextMenu || !elBgContextMenu.contains(e.target)) && (!elTabContextMenu || !elTabContextMenu.contains(e.target))) {
        hideContextMenu();
        hideBgContextMenu();
        hideTabContextMenu();
      }
    });

    // Global keydown: Shortcuts for zoom, Ctrl+F Search, and Escape (with capture: true to intercept before browser zoom)
    window.addEventListener('keydown', (e) => {
      // Control + F / Command + F: Focus Search Bar (even if hidden in settings)
      if ((e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F' || e.code === 'KeyF')) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        focusSearchBar();
        return;
      }

      // Control + and Control - (also Command on macOS) to resize ONLY folders & marcadores
      if (e.ctrlKey || e.metaKey) {
        const isZoomIn = (
          e.key === '+' || e.key === '=' || e.key === 'Add' ||
          e.code === 'Equal' || e.code === 'NumpadAdd' || e.code === 'BracketLeft'
        );
        const isZoomOut = (
          e.key === '-' || e.key === '_' || e.key === 'Subtract' ||
          e.code === 'Minus' || e.code === 'NumpadSubtract' || e.code === 'Slash'
        );
        const isZoomReset = (
          e.key === '0' || e.code === 'Digit0' || e.code === 'Numpad0'
        );

        if (isZoomIn) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          adjustSize(4);
          if (browserAPI.tabs && browserAPI.tabs.setZoom) browserAPI.tabs.setZoom(1).catch(() => {});
          return;
        }
        if (isZoomOut) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          adjustSize(-4);
          if (browserAPI.tabs && browserAPI.tabs.setZoom) browserAPI.tabs.setZoom(1).catch(() => {});
          return;
        }
        if (isZoomReset) {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          if (state.settings.viewMode === 'thumb') {
            state.settings.thumbWidth = 220;
            state.settings.thumbHeight = 132;
            if (elDisplaySize) elDisplaySize.textContent = '220px';
            document.documentElement.style.setProperty('--thumb-width', '220px');
            document.documentElement.style.setProperty('--thumb-height', '132px');
          } else {
            state.settings.cardSize = 74;
            if (elDisplaySize) elDisplaySize.textContent = '74px';
            document.documentElement.style.setProperty('--card-size', '74px');
          }
          saveState();
          if (browserAPI.tabs && browserAPI.tabs.setZoom) browserAPI.tabs.setZoom(1).catch(() => {});
          return;
        }
      }

      if (e.key === 'Escape') {
        if (currentSearchQuery) {
          if (elQuickFilterInput) elQuickFilterInput.value = '';
          handleQuickFilter('');
        }
        if (elApp && elApp.classList.contains('search-bar-temp-revealed')) {
          elApp.classList.remove('search-bar-temp-revealed');
          elApp.classList.add('hide-search-bar');
          if (elQuickFilterInput) elQuickFilterInput.blur();
        }
        hideContextMenu();
        hideBgContextMenu();
        hideTabContextMenu();
        closeSettingsModal();
        closeShortcutModal();
        closeFolderModal();
        closeFolderView();
      }
    }, { capture: true });
  }

  // Run on startup
  init();
})();
